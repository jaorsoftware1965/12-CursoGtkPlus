/*

Curso de Programación con Gtk+
Autor:JAOR
Derechos Reservados: JaorSoftware
www.jaorsoftware.com

Clase 29 - RadioButtons

En esta clase veremos otro objeto común en las Interfaces Gráficas
que son conocidos como RadioButtons.

Un RadioButton es una etiqueta que tiene un círculo a su izquierda
el cual puede ser seleccionado en forma única con respecto a otros
RadioButtons; es decir; que solo puede ser seleccionado uno de ellos.

Cuando se selecciona uno, todos los demás quedan sin seleccionar.

*/

// Incluimos la Librería
#include <gtk/gtk.h>

// Función Principal
int main_29 (int argc,char *argv[])
{
   // Declaración de las Variables
   GtkWidget *window,    // Ventana Principal
             *vbox,      // Contenedor BOX
             *radio1,    // Los RadioButtons
             *radio2,
             *radio3,
             *radio4,
             *radio5,
             *radio6;

   // Iniciamos la Librería
   gtk_init (&argc, &argv);

   // Creamos la Ventana
   window = gtk_window_new (GTK_WINDOW_TOPLEVEL);

   // Establecemos el Título de la Ventana
   gtk_window_set_title (GTK_WINDOW (window), "Clase 29 - Radio Buttons");

   // Establecemos el borde de la Ventana
   gtk_container_set_border_width (GTK_CONTAINER (window), 10);

   /* Crea los RadioButtons */
   radio1 = gtk_radio_button_new_with_label (NULL, "Visual Basic");
   radio2 = gtk_radio_button_new_with_label_from_widget (GTK_RADIO_BUTTON (radio1),"Visual C Sharp");
   radio3 = gtk_radio_button_new_with_label_from_widget (GTK_RADIO_BUTTON (radio1),"Java");
   radio4 = gtk_radio_button_new_with_label_from_widget (GTK_RADIO_BUTTON (radio3),"C++");

   // Radio Independientes
   radio5 = gtk_radio_button_new_with_label (NULL, "Php");
   radio6 = gtk_radio_button_new_with_label_from_widget(GTK_RADIO_BUTTON (radio5), "Asp");

   // Creamos el Contenedor BOX
   vbox = gtk_vbox_new (FALSE,7);

   // Colocamos los RadioButtons en el BOX
   gtk_box_pack_start(GTK_BOX( vbox ), radio1, FALSE, FALSE, 0 );
   gtk_box_pack_start(GTK_BOX( vbox ), radio2, FALSE, FALSE, 0 );
   gtk_box_pack_start(GTK_BOX( vbox ), radio3, FALSE, FALSE, 0 );
   gtk_box_pack_start(GTK_BOX( vbox ), radio4, FALSE, FALSE, 0 );
   gtk_box_pack_start(GTK_BOX( vbox ), radio5, FALSE, FALSE, 0 );
   gtk_box_pack_start(GTK_BOX( vbox ), radio6, FALSE, FALSE, 0 );

   // Agrega el Contenedor a la Ventana
   gtk_container_add (GTK_CONTAINER (window), vbox);

   // Muestra todos los objetos de la Ventana
   gtk_widget_show_all (window);

   // Inicializa el Ciclo
   gtk_main ();

   // Finaliza Retornando 0
   return 0;

}
