#include <algorithm>
#include <iostream>
#include <string>

using namespace std;

string replace(string source,
               string fromStr,
               string toStr,
               int    offset,
               bool bExacto)
{
  int total = 0;
  string::size_type pos = offset;
  string auxSource      = source;
  string auxtoStr       = toStr;

  if (bExacto)
  {
     // Ciclo para buscar y reemplazar
     while ( ( (pos = source.find(fromStr, pos)) < string::npos) )
     {
          source.replace(pos, fromStr.length(), toStr);
          pos+=toStr.size();
     }
     return source;

  }

  else
  {

     // Convierte a mayúscuas
     std::transform(source.begin(), source.end(),source.begin(), ::toupper);
     std::transform(fromStr.begin(), fromStr.end(),fromStr.begin(), ::toupper);
     std::transform(toStr.begin(), toStr.end(),toStr.begin(), ::toupper);

     // Ciclo para buscar y reemplazar
     while ( ( (pos = source.find(fromStr, pos)) < string::npos) )
     {
          source.replace(pos, fromStr.length(), toStr);
          auxSource.replace(pos, fromStr.length(), auxtoStr);
          pos+=toStr.size();
     }
     return auxSource;

  }

}

int main()
{
  string original = "Me voy a dormir, que todos sabemos que dormir es bueno y dormir ayuda a regenerar neuronas. ¡Ay! A partir de las 12 de la noche es hora de dormir.";

  cout << "Cadena original: "<<original<<endl;

  cout << "Cadena resultante: "<<replace(original, "DORMIR", "dormira", 0,false)<<endl;

  return 0;
}
