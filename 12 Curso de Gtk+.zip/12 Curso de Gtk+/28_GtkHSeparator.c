/*

Curso de Programación con Gtk+
Autor:JAOR
Derechos Reservados: JaorSoftware
www.jaorsoftware.com

Clase 28 - GtkHSeparator

El GtkHSeparator es un objeto que dibuja una línea Horizontal, la cual
es utilizada para adornar y separar información.

La Función para crear un objeto de este tipo es la siguiente:
gtk_hseparator_new()

Veremos tambien en esta clase, una función que se utiliza con las
etiquetas, y que sirve para indicar si la información que contiene
la etiqueta, se distribuye en mas de una línea, cuando el objeto
que la contiene se reduce. La función es:

gtk_label_set_line_wrap


*/

// Incluye la Librería
#include <gtk/gtk.h>

// Función Principal
int main_28(int argc, char *argv[]) {

  // Declaración de Variables
  GtkWidget *window;      // La Ventana Principal
  GtkWidget *label1;      // La Primer Etiqueta
  GtkWidget *label2;      // La Segunda Etiqueta
  GtkWidget *hseparator;  // El Separador
  GtkWidget *vbox;        // El VBOX

  // Iniciamos la Librería
  gtk_init(&argc, &argv);

  // Creamos la Ventana
  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);

  // Posicionamos la Ventana
  gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);

  // Establecemos su tamaño
  gtk_window_set_default_size(GTK_WINDOW(window), 100, 300);

  // Establecemos el Título de la Ventana
  gtk_window_set_title(GTK_WINDOW(window), "Clase 28_GtkHSeparator");

  // Establece el Borde de la Ventana
  gtk_container_set_border_width(GTK_CONTAINER(window), 10);

  // Crea la Primera Etiqueta
  label1 = gtk_label_new("En un lugar del Internet del cual no puedo acordarme \
  tenía un Canal en Youtube un Ingenioso Progamador llamado ...");

  // Establece que la Etiqueta Cambie de Línea si rebasa el ancho del Widget
  gtk_label_set_line_wrap(GTK_LABEL(label1), TRUE);

  // Crea la Segunda Etiqueta
  label2 = gtk_label_new("En un lugar del Internet del cual no puedo acordarme \
  tenía un Canal en Youtube un Ingenioso Progamador llamado ...");

  // Establece que la Etiqueta Cambie de Línea si rebasa el ancho del Widget
  gtk_label_set_line_wrap(GTK_LABEL(label2), TRUE);

  // Crea la Caja Contenedora
  vbox = gtk_vbox_new(FALSE, 10);

  // Agrega el Contenedor a la Ventana
  gtk_container_add(GTK_CONTAINER(window), vbox);

  // Crea el Separador
  hseparator = gtk_hseparator_new();

  // Agrega los Elementos al Separador
  gtk_box_pack_start(GTK_BOX(vbox), label1, FALSE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(vbox), hseparator, FALSE, TRUE, 10);
  gtk_box_pack_start(GTK_BOX(vbox), label2, FALSE, TRUE, 0);

  // Conecta la Señal de destrucción de la ventana a la función gtk_main_quit de la librería
  g_signal_connect_swapped(G_OBJECT(window), "destroy",G_CALLBACK(gtk_main_quit), G_OBJECT(window));

  // Muestra todos los objetos
  gtk_widget_show_all(window);

  // Ciclo Principal
  gtk_main();

  // Finaliza Retornando 0
  return 0;

}
