/*

Curso de Programación con Gtk+
Autor:JAOR
Derechos Reservados: JaorSoftware
www.jaorsoftware.com

Clase 30 - GtkEntry

El objeto GtkEntry de la librería es el clásico textbox de otros
lenguajes de Programación.

Para crearlo se utiliza la función:

gtk_entry_new

la cual se asigna a una variable de tipo widget.

*/

// Incluimos la libreria
#include <gtk/gtk.h>

// Función Principal
int main_30(int argc, char *argv[])
{

  // Declaración de Variables
  GtkWidget *window;      // Ventana Principal
  GtkWidget *table;       // Tabla Contenedora
  GtkWidget *lblNombre;   // Etiquetas
  GtkWidget *lblEdad;
  GtkWidget *lblPeso;
  GtkWidget *entNombre;   // Entradas
  GtkWidget *entEdad;
  GtkWidget *entPeso;

  // Inicializa la Librería
  gtk_init(&argc, &argv);

  // Crea la Nueva Ventana
  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);

  // Posiciona la Ventana
  gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);

  // Título de la Ventana
  gtk_window_set_title(GTK_WINDOW(window), "Clase 30 - GtkEntry");

  // Establece el Borde
  gtk_container_set_border_width(GTK_CONTAINER(window), 10);

  // Define la Tabla Contenedora
  table = gtk_table_new(3, 2, FALSE);

  // Agrega la Tabla a la Ventana Contenedora
  gtk_container_add(GTK_CONTAINER(window), table);

  // Crea las Etiquetas
  lblNombre = gtk_label_new("Nombre:");
  lblEdad   = gtk_label_new("Edad:");
  lblPeso   = gtk_label_new("Peso:");

  // Agrega las Etiquetas a la Tabla
  gtk_table_attach(GTK_TABLE(table), lblNombre, 0, 1, 0, 1,GTK_FILL | GTK_SHRINK, GTK_FILL | GTK_SHRINK, 5, 5);
  gtk_table_attach(GTK_TABLE(table), lblEdad  , 0, 1, 1, 2,GTK_FILL | GTK_SHRINK, GTK_FILL | GTK_SHRINK, 5, 5);
  gtk_table_attach(GTK_TABLE(table), lblPeso  , 0, 1, 2, 3,GTK_FILL | GTK_SHRINK, GTK_FILL | GTK_SHRINK, 5, 5);

  // Crea las Entradas
  entNombre = gtk_entry_new();
  entEdad   = gtk_entry_new();
  entPeso   = gtk_entry_new();

  // Agrega las Entradas a la Tabla
  gtk_table_attach(GTK_TABLE(table), entNombre, 1, 2, 0, 1,GTK_FILL | GTK_SHRINK, GTK_FILL | GTK_SHRINK, 5, 5);
  gtk_table_attach(GTK_TABLE(table), entEdad  , 1, 2, 1, 2,GTK_FILL | GTK_SHRINK, GTK_FILL | GTK_SHRINK, 5, 5);
  gtk_table_attach(GTK_TABLE(table), entPeso  , 1, 2, 2, 3,GTK_FILL | GTK_SHRINK, GTK_FILL | GTK_SHRINK, 5, 5);

  // Muestra las ventanas
  gtk_widget_show_all(window);

  // Conecta la Señal de Cierre de la Ventana
  g_signal_connect(window, "destroy",G_CALLBACK(gtk_main_quit), NULL);

  // Ejecuta el Ciclo Principal
  gtk_main();

  // Finaliza Retornando 0
  return 0;

}
