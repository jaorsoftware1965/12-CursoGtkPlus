/*

Autor    : JAOR
Curso    : Library Gtk+
Clase 51 : TreeView IV

En esta clase veremos como establecer que una celda
sea editable y como controlar el cambio en la edición.

*/

// Incluimos la Libreria
#include <gtk/gtk.h>

// Definimos enumerado para constantes
enum
{
    COL_COMPRAR = 0,  // Columna de Comprar
    COL_CANTIDAD,     // Columna de Cantidad
    COL_PRODUCTO,     // Columna de Producto
    COL_MAXIMO        // Número Máximo de Columnas
};

// Constantes para los Niveles Producto
enum
{
    CATEGORIA,  // Nivel de Categoria
    PRODUCTO      // Nivel de Hijo
};

// Definimos Estructura para Productos
typedef struct
{
    gint     iProductoCategoria;
    gboolean bProductoComprar;
    gint     iProductoCantidad;
    gchar   *sProductoNombre;
} Comestibles;


// Definimos la lista de Productos
Comestibles ListaCompras[] =
{
   // Nivel   , Comprar, Cantidad, Producto
    { CATEGORIA, TRUE   , 0, "Baño" },
    { PRODUCTO , TRUE   , 1, "Papel" },
    { PRODUCTO , TRUE   , 3, "Jabón" },
    { CATEGORIA, TRUE   , 0, "Alimentos" },
    { PRODUCTO , TRUE   , 2, "Pan" },
    { PRODUCTO , FALSE  , 1, "Sopa" },
    { PRODUCTO , TRUE   , 1, "Leche" },
    { PRODUCTO , FALSE  , 3, "Papas" },
    { PRODUCTO , TRUE   , 4, "Refresco" },
    { CATEGORIA, FALSE  , 0, NULL }
};

// Función para Controlar el Cambio en la Celda
// Aplica el Cambio si no es vacío
static void FnTreeViewCeldaEditada(GtkCellRendererText *renderer,      // La Celda
                                                      gchar *path,     // El path de la celda
                                                      gchar *new_text, // El Texto
                                                GtkTreeView *treeview) // El TreeView
{
   // Definición de Variables
   GtkTreeIter iter;
   GtkTreeModel *model;

   // Verifica que es el Path
   g_print("El Path:  %s \n",path);

   // Despliega lo que trae capturado
   g_print("Lo Capturado:  %s \n",new_text);

   // Verifica el Texto Capturado
   if (g_ascii_strcasecmp (new_text, "") != 0)
   {
       // Obtiene el Modelo
       model = gtk_tree_view_get_model (treeview);

       // Obtiene el Item para Modificarlo
       if (gtk_tree_model_get_iter_from_string (model, &iter, path))

          // Aplica el Cambio
          gtk_tree_store_set (GTK_TREE_STORE (model), &iter, COL_PRODUCTO, new_text, -1);
   }
}

// Añade las 3 columnas a el GtkTreeView que serán desplegadas como texto
void FnTreeViewInicializa(GtkWidget *treeview)
{
    // Declaración de las Variables
    GtkCellRenderer   *renderer;
    GtkTreeViewColumn *column;

    // Crea la celda y Crea la columna y la agrega
    renderer = gtk_cell_renderer_text_new ();

    column = gtk_tree_view_column_new_with_attributes ("Comprar", renderer, "text", COL_COMPRAR, NULL);
    gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);

    // Crea la Celda y Crea la columna y la agrega
    renderer = gtk_cell_renderer_text_new ();
    column = gtk_tree_view_column_new_with_attributes("Cantidad", renderer, "text", COL_CANTIDAD, NULL);
    gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);

    // Crea la Celda y Crea la columna y la agrega
    renderer = gtk_cell_renderer_text_new ();
    g_object_set (renderer, "editable", TRUE, "editable-set", TRUE, NULL);

    // Controla la Señal de Editado
    g_signal_connect (G_OBJECT (renderer), "edited",G_CALLBACK (FnTreeViewCeldaEditada),(gpointer) treeview);

    column = gtk_tree_view_column_new_with_attributes("Producto", renderer, "text", COL_PRODUCTO, NULL);
    gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);

}


// Función Principal
int main (int argc,char *argv[])
{
    // Define las Variables
    GtkWidget *window,       // Ventana Principal
              *treeview,     // El TreeView
              *scrolled_win; // El Scroll
    GtkTreeStore *store;     // El Modelo de Datos
    GtkTreeIter iter, child; // Los Item
    guint iCuenta1 = 0, iCuenta2;  // Contadores

    // Inicializa la librería
    gtk_init (&argc, &argv);

    // Crea la Ventana Principal y la Configura
    window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title (GTK_WINDOW (window), "Clase 51 - TreeView IV");
    gtk_container_set_border_width (GTK_CONTAINER (window), 10);
    gtk_widget_set_size_request (window, 275, 300);

    // Crea el TreeView, lo Inicializa
    treeview = gtk_tree_view_new ();
    FnTreeViewInicializa(treeview);

    // Crea el Modelo de Datos con sus columnas y agrega los datos
    store = gtk_tree_store_new (COL_MAXIMO, G_TYPE_BOOLEAN, G_TYPE_INT, G_TYPE_STRING);

    // Ciclo para colocar los datos
    while (ListaCompras[iCuenta1].sProductoNombre != NULL)
    {
        // Ciclo por Categoria
        if (ListaCompras[iCuenta1].iProductoCategoria == CATEGORIA)
        {
            // El Contador a partir de i + 1
            iCuenta2 = iCuenta1 + 1;

            // Calcula cuantos productos serán comprados en la Clase
            while (ListaCompras[iCuenta2].sProductoNombre != NULL &&
                   ListaCompras[iCuenta2].iProductoCategoria != CATEGORIA)
            {
                // Verifica si debe comprarse el Producto
                if (ListaCompras[iCuenta2].bProductoComprar)
                   ListaCompras[iCuenta1].iProductoCantidad +=
                   ListaCompras[iCuenta2].iProductoCantidad;

                // Incrementa el Contador
                iCuenta2++;
            }

            // Añade el Producto como Clase
            gtk_tree_store_append (store, &iter, NULL);
            gtk_tree_store_set (store, &iter, COL_COMPRAR,
                                              ListaCompras[iCuenta1].bProductoComprar,
                                              COL_CANTIDAD,
                                              ListaCompras[iCuenta1].iProductoCantidad,
                                              COL_PRODUCTO,
                                              ListaCompras[iCuenta1].sProductoNombre, -1);
        }
        // Añade el Producto como Hijo de la Clase
        else
        {
            // Añade el Producto
            gtk_tree_store_append (store, &child, &iter);
            gtk_tree_store_set (store, &child, COL_COMPRAR,
                                               ListaCompras[iCuenta1].bProductoComprar,
                                               COL_CANTIDAD,
                                               ListaCompras[iCuenta1].iProductoCantidad,
                                               COL_PRODUCTO,
                                               ListaCompras[iCuenta1].sProductoNombre, -1);
        }
        // Incrementamos el COntador
        iCuenta1++;
    }

    // Deposita el Modelo
    gtk_tree_view_set_model (GTK_TREE_VIEW (treeview), GTK_TREE_MODEL (store));

    // Hace que se expandan todos los elementos que tengan hijos
    gtk_tree_view_expand_all (GTK_TREE_VIEW (treeview));

    // Desreferencia el Modelo para que sea eliminado con el treeview
    g_object_unref (store);

    // Crea el Scroll y establece sus políticas para las barras de desplazamiento
    scrolled_win = gtk_scrolled_window_new (NULL, NULL);
    gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolled_win),
                                    GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);

    // Añade el Treeview al Scroll
    gtk_container_add (GTK_CONTAINER (scrolled_win), treeview);

    // Añade el Scroll a la Ventana Principal
    gtk_container_add (GTK_CONTAINER (window), scrolled_win);

    // Muestra todos los objetos
    gtk_widget_show_all (window);

    // Inicializa el Ciclo Principal
    gtk_main ();

    // Finaliza con 0
    return 0;

}

