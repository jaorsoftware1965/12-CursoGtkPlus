/*
Curso de Programación con Gtk+
Autor:JAOR

Clase 66 Anexo 03 Eliminando Maximizar Minimizar

*/
// Se incluye la librería
#include <gtk/gtk.h>

/* Create a dialog, which cannot be resized by the user. */

void create_dialog(GtkWidget *button, gpointer window) {
    GtkWidget *dialog, *label, *content_area;

    /* New label for dialog content */
    label = gtk_label_new("This is a dialog!");

    /* Make a new dialog with an 'OK' button */
    dialog = gtk_dialog_new_with_buttons("This is a dialog, which (shouldn't | can't) be resized!", window, GTK_DIALOG_DESTROY_WITH_PARENT, GTK_STOCK_OK, GTK_RESPONSE_NONE, NULL);

    /* Add label to dialog */
    content_area = gtk_dialog_get_content_area(GTK_DIALOG(dialog));
    gtk_container_add(GTK_CONTAINER(content_area), label);

    /* Destroy dialog properly */
    g_signal_connect(dialog, "response", G_CALLBACK(gtk_widget_destroy), dialog);

    /* Set dialog to not resize. */
    gtk_window_set_resizable(GTK_WINDOW(dialog), FALSE);

    gtk_widget_show_all(dialog);
}

/* Create a window, while in a function! */

void create_window(GtkWidget *button, gpointer window) {
    GtkWidget *new_window, *label;

    /*New label for dialog content */
    label = gtk_label_new("This is a window, created in a function!");

    /* Create new window */
    new_window = gtk_window_new(GTK_WINDOW_TOPLEVEL);

    /* Add label to window */
    gtk_container_add(GTK_CONTAINER(new_window), label);

    gtk_widget_show_all(new_window);
}

/* Boring implementation bits */
gint main(gint argc, char **argv) {

    /* Initialise GTK+ */
    gtk_init(&argc, &argv);

    GtkWidget *main_win, *dialog_button, *window_button, *button_container;

    /* Create a button, one for each function. */
    dialog_button = gtk_button_new_with_label("Create dialog!");
    window_button = gtk_button_new_with_label("Create window!");

    /* Pack buttons into a box. */
    button_container = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
    gtk_box_pack_start(GTK_BOX(button_container), dialog_button, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(button_container), window_button, FALSE, FALSE, 0);

    /* Connect signals to button callback functions */
    g_signal_connect(dialog_button, "clicked", G_CALLBACK(create_dialog), main_win);
    g_signal_connect(window_button, "clicked", G_CALLBACK(create_window), main_win);

    /* Create a new window, show it, and run GTK+ */
    main_win = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    g_signal_connect(main_win, "destroy", G_CALLBACK(gtk_main_quit), NULL);
    gtk_container_add(GTK_CONTAINER(main_win), button_container);
    gtk_widget_show_all(main_win);
    gtk_main();
    return 0;
}
