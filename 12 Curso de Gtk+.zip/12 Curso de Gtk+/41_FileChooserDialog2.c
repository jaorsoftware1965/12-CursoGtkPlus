/*

Autor:JAOR
Derechos Reservados: JaorSoftware

Curso de Librería Gtk+
Clase 41 - FileChooserDialog

*/

#include <gtk/gtk.h>
static void button_clicked (GtkButton *button,GtkWindow *window)
{
    // Variable para el Diálogo
    GtkWidget *dialog;

    // Variable para el Nombre del Archivo
    gchar *filename;

    /* Crea el diálogo para crear la Carpeta */
    dialog = gtk_file_chooser_dialog_new (
                "Crear un Directorio ...", NULL,
                GTK_FILE_CHOOSER_ACTION_CREATE_FOLDER,
                GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
                GTK_STOCK_OK, GTK_RESPONSE_OK,
                NULL);

    // Ejecuta el Diálogo y Obtiene el Resultado
    gint result = gtk_dialog_run (GTK_DIALOG (dialog));

    // Verifica acción del Usuario
    if (result == GTK_RESPONSE_OK)
    {
        // Obtenemos el Nombre del Directorio
        filename = gtk_file_chooser_get_filename (GTK_FILE_CHOOSER (dialog));

        // Imprimimos
        g_print ("Creating directory: %s\n", filename);
    }

    // Destruye el Diálogo
    gtk_widget_destroy (dialog);
}

// Función Principal
int main (int argc, char *argv[])
{

    // Variables para los objetos
    GtkWidget *window, *button;

    // Inicializa la librería
    gtk_init (&argc, &argv);

    // Crea la ventana con sus características
    window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title (GTK_WINDOW (window), "Clase 41 - FileChooserDialog 2");
    gtk_container_set_border_width (GTK_CONTAINER (window), 10);
    gtk_widget_set_size_request (window, 300, 100);

    // Crea el Botón
    button = gtk_button_new_with_label ("Crear una Carpeta");

    // Conecta la señal del botón a la función CallBack
    g_signal_connect (G_OBJECT (button), "clicked",G_CALLBACK (button_clicked),(gpointer) window);

    // Control de al Salida del Programa
    g_signal_connect(G_OBJECT(window), "destroy",G_CALLBACK(gtk_main_quit), NULL);

    // Agrega el botón a la ventana
    gtk_container_add (GTK_CONTAINER (window), button);

    // Muestra los Widgets
    gtk_widget_show_all (window);

    // Ejecuta el Loop Principal
    gtk_main ();

    // Finaliza la Aplicación con 0
    return 0;

}
