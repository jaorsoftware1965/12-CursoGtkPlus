#include <gtk/gtk.h>

GtkWidget *window, *button;
GtkStyle  *defStyle;
GdkColor Color = {0, 0xffff, 0x0000, 0x0000};

/* prototypes */

gint WindowClicked (GtkWidget *widget, gpointer *data);
int main(int argc, char *argv[]);

int main_99(int argc, char *argv[]) {

  gtk_init(&argc, &argv);

  defStyle = gtk_widget_get_default_style ();
  // Se comentó porque marcó error cuando eliminé versión2.0
  //gdk_color_alloc (gdk_colormap_get_system(), &Color);

  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_widget_show (window);
  //gtk_widget_set_usize(window, 300, 200);
  gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);
  gtk_container_set_border_width(GTK_CONTAINER(window), 50);

  button = gtk_button_new_with_label("bouton");
  gtk_container_add (GTK_CONTAINER(window), button);
  gtk_widget_show (button);
  //gtk_signal_connect(GTK_OBJECT(button), "clicked",
//  GTK_SIGNAL_FUNC(WindowClicked), NULL);

  gtk_main();
  return 0;
}

gint WindowClicked (GtkWidget *widget, gpointer *data)
{
  GtkStyle *windowstyle;

  windowstyle = gtk_style_copy (defStyle);

  if (Color.red ==  0xffff) {
    Color.red = 0x0000;
    Color.blue = 0xffff;
  }
  else {
    Color.red = 0xffff;
    Color.blue = 0x0000;
  }

  windowstyle->bg[GTK_STATE_NORMAL] = Color;
  defStyle = gtk_style_copy (windowstyle);
  gtk_widget_set_style (window, windowstyle);

  return (FALSE);
}
