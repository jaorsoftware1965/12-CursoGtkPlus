/*

Curso de Programación con Gtk+
Autor:JAOR
Derechos Reservados: JaorSoftware
www.jaorsoftware.com
www.jaorsoftware.cc.cu

Clase 04_Controlando la Ventana

En esta clase veremos como Controlar el Evento de Minimizar y
Maximizar la Ventana.

Capturaremos la Señal del Evento, y desplegaremos un mensaje
correspondiente a lo que sucede con la ventana.

Veremos tambien como Maximizar la Ventana, como Minimizarla;
y como centrarla en la Pantalla.

Instrucción para Compilar desde la Terminal
gcc -o 04_Controlando_Ventana 04_Controlando_Ventana.c `pkg-config --libs --cflags gtk+-2.0`

*/
// Se incluye la librería
#include <gtk/gtk.h>

// Detiene el Ciclo Principal iniciado por gtk_main cuando la ventana es destruida
static void SbMainExit(GtkWidget *window, gpointer data)
{
    // Mensaje de que la ventana se ha destruido
    printf("Destroy Signal \n");

    // Llama a la función de la Librería que sale del Ciclo Main
    gtk_main_quit ();
}

// Función para controlar el Cierre de una Ventana
// Si se retorna FALSE se cerrará y posteriormente se destruirá la ventana
// Si se retorna TRUE, se cancela el cierre.
// Esta función puede utilizarse para confirmar el cierre de una Ventana
// y Salir de una Aplicación
static gboolean FngBoolDeleteEvent(GtkWidget *window, GdkEvent *event)
{
    printf("Delete Event\n");
    //if (event->type == GDK_DELETE)
    //   return TRUE;
    //else

    // Valor de Retorno
    return FALSE;
}

// Función para Controlar el Cambio de Estado
static gboolean FngBoolWindowStateEvent(GtkWidget *window, GdkEventWindowState *event)
{
    // Mensaje del Evento
    printf("Window State Event \n");

    // Verifica que evento se ejecutó
    if (event->new_window_state & GDK_WINDOW_STATE_ICONIFIED)
    {
       // Desplegamos el Mensaje
       printf("Se Minimizó \n");

    }
    else
    {
       if (event->new_window_state & GDK_WINDOW_STATE_MAXIMIZED)
          printf("Se Maximizo \n");
    }

   // Retorna
   return FALSE;

}

// Función Principal
int main_04( int argc, char *argv[])
{

  // Objeto para el Widget
  GtkWidget *window;

  // Inicializa la Librería
  gtk_init (&argc, &argv);

  // Crea el Widget con el Objeto declarado
  window = gtk_window_new (GTK_WINDOW_TOPLEVEL);

  // Coloca el Título
  gtk_window_set_title (GTK_WINDOW (window), "04_Controlando la Ventana");

  // Controla la Señal "destroy" de la Ventana-Widget
  g_signal_connect (G_OBJECT (window), "destroy",G_CALLBACK (SbMainExit), NULL);

  // Controla la Señal del evento "delete_event" de la Ventana-Widget
  g_signal_connect (G_OBJECT (window), "delete_event", G_CALLBACK (FngBoolDeleteEvent), NULL);

  // Controla la Señal del evento "delete_event" de la Ventana-Widget
  g_signal_connect (G_OBJECT (window), "window_state_event", G_CALLBACK (FngBoolWindowStateEvent), NULL);

  // Ubicamos la Ventana
  gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);

  // Mostramos la Ventana con la función gtk_widget_show
  gtk_widget_show(window);

  // Maximizamos la Ventana
  //gtk_window_maximize(GTK_WINDOW(window));

  // Minimiza la Ventana
  gtk_window_iconify(GTK_WINDOW(window));

  // Ejecuta el Ciclo Principal de la Aplicación
  gtk_main ();

  // Finaliza la Aplicación
  return 0;
}

