/*

Autor:JAOR
Derechos Reservados: JaorSoftware
http://jaorsoftware.cu.cc/

Curso de Librería Gtk+
Clase 36 - Message Dialogs

En esta clase iniciaremos el capítulo de Mensajes de Diálogo
o Message Dialogs.

Los Message Dialog's, son ventanas a las que se les puede
establecer un Título; y que presentan mensajes de información
al usuario; en donde el usuario puede aceptar la información
o escoger opciones como Si y No.

Para crear un MessageDialog se utiliza la función
gtk_message_dialog_new.

*/

// Incluímos la Librería
#include <gtk/gtk.h>

void SbSistemaMensaje(GtkWidget *widget, gpointer window)
{
  // Variable para la Respuesta
  gint giRespuesta;

  // Variable para generar el MessageDialog
  GtkWidget *dialog;

  // Crea el MessageDialog
  dialog = gtk_message_dialog_new(GTK_WINDOW(window),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_ERROR,//GTK_MESSAGE_ERROR
            GTK_BUTTONS_OK,
            "Proceso Finalizado");

  // Establece el Título de la Ventana
  gtk_window_set_title(GTK_WINDOW(dialog), "JS Ver. 3.1");

  // Ejecuta el Diálogo y obtiene su respuesta
  giRespuesta=gtk_dialog_run(GTK_DIALOG(dialog));

  // Destruye el Diálogo
  gtk_widget_destroy(dialog);

  // Despliega la Respuesta
  g_print("La Respuesta:%d ",giRespuesta);

}


// Función para realizar una Pregunta
void SbSistemaPregunta(GtkWidget *widget, gpointer window)
{
  // Variable para la Respuesta
  gint giRespuesta;

  // Variable para el Diálogo
  GtkWidget *dialog;

  // Crea el Diálogo
  dialog = gtk_message_dialog_new(GTK_WINDOW(window),
            GTK_DIALOG_DESTROY_WITH_PARENT,
            GTK_MESSAGE_WARNING,//GTK_MESSAGE_WARNING
            GTK_BUTTONS_YES_NO,
            "¿ Desea Salir de la Aplicación ?");
  gtk_window_set_title(GTK_WINDOW(dialog), "JS - Salida del Sistema");

  // Ejecuta el Diálogo
  giRespuesta=gtk_dialog_run(GTK_DIALOG(dialog));

  // Destruye el Diálogo
  gtk_widget_destroy(dialog);

  // Despliega la Respuesta
  g_print("La Respuesta:%d ",giRespuesta);

}

// Función Principal
int main_36(int argc, char *argv[])
{

  // Declaración de Variables para los Objetos
  GtkWidget *window;
  GtkWidget *table;

  // Para los Botones
  GtkWidget *btnMensaje;
  GtkWidget *btnPregunta;

  // Inicializa la Librería
  gtk_init(&argc, &argv);

  // Crea la Ventana Principal con sus Características
  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);
  gtk_window_set_default_size(GTK_WINDOW(window), 200, 75);
  gtk_window_set_title(GTK_WINDOW(window), "Clase 36 - Message Dialogs");

  // Crea la Tabla Contenedora
  table = gtk_table_new(1, 2, TRUE);
  gtk_table_set_row_spacings(GTK_TABLE(table), 2);
  gtk_table_set_col_spacings(GTK_TABLE(table), 2);

  // Crea los Botones
  btnMensaje = gtk_button_new_with_label("Mensaje");
  btnPregunta = gtk_button_new_with_label("Pregunta");

  // Agrega los Botones a la Tabla
  gtk_table_attach(GTK_TABLE(table), btnMensaje, 0, 1, 0, 1,GTK_FILL, GTK_FILL, 3, 3);
  gtk_table_attach(GTK_TABLE(table), btnPregunta, 1, 2, 0, 1,GTK_FILL, GTK_FILL, 3, 3);

  // Agrega el Contenedor a la Ventana y Establece el Borde
  gtk_container_add(GTK_CONTAINER(window), table);
  gtk_container_set_border_width(GTK_CONTAINER(window), 15);

  // Establece la Señales
  g_signal_connect(G_OBJECT(btnMensaje), "clicked",G_CALLBACK(SbSistemaMensaje), (gpointer) window);
  g_signal_connect(G_OBJECT(btnPregunta), "clicked",G_CALLBACK(SbSistemaPregunta), (gpointer) window);

  // Destrucción de la Ventana Principal
  g_signal_connect(G_OBJECT(window), "destroy",G_CALLBACK(gtk_main_quit), G_OBJECT(window));

  // Muestra los Objetos
  gtk_widget_show_all(window);

  // Ciclo Principal
  gtk_main();

  // Salida Retornando 0
  return 0;

}
