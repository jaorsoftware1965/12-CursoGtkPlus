/*

Autor    : JAOR

*/

// Incluimos la librería
#include "browser.h"

// Función Principal
int main (int argc,char *argv[])
{
   // Declaración de Variables
   GtkWidget       *window;  // Ventana Principal

   // Inicializa la librería
   gtk_init (&argc, &argv);

   // Crea y configura la Ventana Principal
   window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
   gtk_window_set_title (GTK_WINDOW (window), "Clase 56 - TextView IV");
   gtk_container_set_border_width (GTK_CONTAINER (window), 10);

   // Muestra los objetos y Finaliza Retornando 0
   gtk_widget_show_all (window);
   gtk_main();
   return 0;
}
