/*

Curso de Programación con Gtk+
Autor:JAOR
Derechos Reservados: JaorSoftware
www.jaorsoftware.cc.cu

Clase 11_Contenedor GtkTable

En esta Clase continuaremos viendo los Contenedores.
Ahora veremos el Contenedor GtkTable, el cual lo que nos
permite es controlar el area del mismo, como si fuera
una matriz de renglones y columnas

Al igual que los contenedores anteriores, este objeto tambien
inicialmente es declarado como Widget; y posteriormente
la función que lo crea; es la que le da las características.

*/

// Incluimos la Librería
#include <gtk/gtk.h>

// Función Principal
int main_11(int argc, char *argv[])
{

  GtkWidget *wgtAplicacion;     // El Objeto de la Ventana Principal
  GtkWidget *gtktblContenedor;  // Contenedor GtkTable
  GtkWidget *butTecla1;         // Teclas
  GtkWidget *butTecla2;         // Teclas
  GtkWidget *butTecla3;         // Teclas
  GtkWidget *butTecla4;         // Teclas
  GtkWidget *butTecla5;         // Teclas
  GtkWidget *butTecla6;         // Teclas

  // Inicializa la Aplicación
  gtk_init(&argc, &argv);

  // Crea la Ventana Principal
  wgtAplicacion = gtk_window_new(GTK_WINDOW_TOPLEVEL);

  // Centra la Ventana
  gtk_window_set_position(GTK_WINDOW(wgtAplicacion), GTK_WIN_POS_CENTER);

  // Define su tamaño
  gtk_window_set_default_size(GTK_WINDOW(wgtAplicacion), 350, 350);

  // Establece el Título
  gtk_window_set_title(GTK_WINDOW(wgtAplicacion), "Clase 11_Contenedor GtkTable");

  // Establece un Borde
  gtk_container_set_border_width(GTK_CONTAINER(wgtAplicacion), 5);

  // Crea el Botón para las teclas
  butTecla1 = gtk_button_new_with_label("Botón1");

  // Crea el Botón para las teclas
  butTecla2 = gtk_button_new_with_label("Botón2");

  // Crea el Botón para las teclas
  butTecla3 = gtk_button_new_with_label("Botón3");

  // Crea el Botón para las teclas
  butTecla4 = gtk_button_new_with_label("Botón4");

  // Crea el Botón para las teclas
  butTecla5 = gtk_button_new_with_label("Botón5");

  // Crea el Botón para las teclas
  butTecla6 = gtk_button_new_with_label("Botón6");

  // Crea el Contenedor con 3 x 3 Areas de almacenamiento
  gtktblContenedor = gtk_table_new(3, 3, TRUE);

  // Indica el Espacio entre Rows y el Espacio entre Columnas
  gtk_table_set_row_spacings(GTK_TABLE(gtktblContenedor), 2);
  gtk_table_set_col_spacings(GTK_TABLE(gtktblContenedor), 2);

  // Agrega las Teclas

  // 0        1         2         3
  // ------------------------------   0
  // |        |         |         |
  // ------------------------------   1
  // |        |         |         |
  // ------------------------------   2
  // |        |         |         |
  // ------------------------------   3

  // Posicionando los Botones
  gtk_table_attach_defaults(GTK_TABLE(gtktblContenedor), butTecla1, 0, 1, 0, 1);
  gtk_table_attach_defaults(GTK_TABLE(gtktblContenedor), butTecla2, 1, 3, 0, 1);
  gtk_table_attach_defaults(GTK_TABLE(gtktblContenedor), butTecla3, 0, 1, 1, 3);
  gtk_table_attach_defaults(GTK_TABLE(gtktblContenedor), butTecla4, 1, 3, 1, 2);
  gtk_table_attach_defaults(GTK_TABLE(gtktblContenedor), butTecla5, 1, 3, 2, 3);

  // Añade el Contenedor a la Ventana Principal
  gtk_container_add(GTK_CONTAINER(wgtAplicacion), gtktblContenedor);

  // Captura la Señal para destruir el Objeto
  g_signal_connect_swapped(G_OBJECT(wgtAplicacion), "destroy",G_CALLBACK(gtk_main_quit), G_OBJECT(wgtAplicacion));

  // Muestra todos los objetos de la Aplicación
  gtk_widget_show_all(wgtAplicacion);

  // Ciclo Principal
  gtk_main();

  return 0;
}


