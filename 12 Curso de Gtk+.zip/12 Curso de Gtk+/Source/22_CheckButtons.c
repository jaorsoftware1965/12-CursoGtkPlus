/*
Curso de Programación con Gtk+
Autor:JAOR
Derechos Reservados: JaorSoftware
www.jaorsoftware.com

Clase 22 - CheckButtons

En esta clase veremos como crear y utilizar un checkbutton.
Un objeto checkbutton es una etiqueta la cual tiene un pequeño
cuadrado el cual se puede seleccionar o desseleccionar.

Para crearlo se utiliza la siguiente función:
gtk_check_button_new_with_label
a la cual se le pasa como parámetro la etiqueta que desplegará

Para activar el checkbutton se utiliza la función:
gtk_toggle_button_set_active
En la cual se indica en los parámetros, el checkbutton a
modificar y el valor de TRUE o FALSE para activar o desactivar
el checkbutton.

Tambien veremos como mostrar y ocultar el título de la
ventana principal; que en realidad lo que se hace es colocar
vacío el título

*/

// Incluimos la librería
#include <gtk/gtk.h>

// Función para mostrar u ocultar la ventana principal
void SbVentanaTituloOnOff(GtkWidget *widget,// El Widget del checkbutton
                          gpointer window)  // El Widget de la ventana principal
{
  // Verifica que el checkbutton esté activo
  if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(widget)))
  {
    // Coloca el Título de la Ventana
    gtk_window_set_title(window, "Clase 22 - GtkCheckButton");
  }
  else
  {
    // Coloca el Título Vacío de la Ventana
    gtk_window_set_title(window, "");
  }
}

// Función principal
int main_22(int argc, char** argv)
{

  GtkWidget *window;             // Widget de la Ventana Principal
  GtkWidget *chkVentanaTitulo;   // Widget del CheckButton

  // Inicializa la Librería
  gtk_init(&argc, &argv);

  // Genera una ventana nueva
  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);

  // Centra la Ventana
  gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);

  // Coloca un borde
  gtk_container_set_border_width(GTK_CONTAINER(window), 15);

  // Establece el tamaño de la ventana
  gtk_window_set_default_size(GTK_WINDOW(window), 330, 250);

  // Establece el Título de la Ventana
  gtk_window_set_title(GTK_WINDOW(window), "Clase 22 - GtkCheckButton");

  // Crea el CheckButton
  chkVentanaTitulo = gtk_check_button_new_with_label("Mostrar Título de la Ventana");

  // Activar el CheckButton
  gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(chkVentanaTitulo), TRUE);

  // Agregar el checkbutton al contenedor
  gtk_container_add(GTK_CONTAINER(window), chkVentanaTitulo);

  // Asociar el cierre de la Ventana
  g_signal_connect(window, "destroy",G_CALLBACK(gtk_main_quit), NULL);

  // Asociamos la función al evento click, pasando la ventana como parámetro
  g_signal_connect(chkVentanaTitulo, "clicked",G_CALLBACK(SbVentanaTituloOnOff), (gpointer) window);

  // Mostrar todos los objetos de la ventana
  gtk_widget_show_all(window);

  // Loop Principal
  gtk_main();

  // Salimos de la aplicación
  return 0;
}
