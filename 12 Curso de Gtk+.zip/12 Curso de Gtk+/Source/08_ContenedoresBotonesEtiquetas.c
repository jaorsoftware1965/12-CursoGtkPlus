/*
Curso de Programación con Gtk+
Autor:JAOR
Derechos Reservados: JaorSoftware
www.jaorsoftware.com
www.jaorsoftware.cc.cu

Clase 08_Contenedores Botones y Etiquetas

Para esta clase aprenderemos sobre los siguiente elementos y funciones.

GtkFixed.
Es una Clase Contenedor que permite posicionar los elementos en coordenadas
fijas.

gtk_fixed_new().
Es la función que crea un Contenedor GtkFixed.

gtk_fixed_put().
Es la función que agrega un Elemento al Contenedor

gtk_label_new()
Función para crear un Etiqueta

gtk_label_set_text()
Función para colocar un texto en la Etiqueta

GdkColor.
Clase para manejar objetos para el Color

gdk_color_parse.
Función para obtener un color.

gtk_widget_modify_bg.
Función para establecer un Color

*/


#include <gtk/gtk.h>

// Variable Global de Conteo
gint giContador = 0;

// Variable para construir un Mensaje
char buf[5];

// Función para Incrementar en 1 y colocar el resultado en la etiqueta
void sbSumarUno(GtkWidget *widget, gpointer label)
{
  // Incrementa la Variable Global de Conteo
  giContador++;

  // Convierte a Texto el valor del Contador
  sprintf(buf, "%d", giContador);

  // Coloca el Texto en la Etiqueta
  gtk_label_set_text(GTK_LABEL(label), buf);
}

void sbRestarUno(GtkWidget *widget, gpointer label)
{
  // Decrementa el Contador
  giContador--;

  // Convierte a Texto el valor del Contador
  sprintf(buf, "%d", giContador);

  // Coloca el Texto en la Etiqueta
  gtk_label_set_text(GTK_LABEL(label), buf);
}

// Función Principal
int main_08(int argc, char** argv)
{

  // Variables para Crear los Objetos
  GtkWidget *wgtAplicacion;  // Ventana Principal de la Aplicación
  GtkWidget *lblResultado;   // Etiqueta del Resultado
  GtkWidget *frmOperacion;   // El Marco Contenedor de los Objetos
  GtkWidget *btnSuma;        // El Botón de Suma
  GtkWidget *btnResta;       // El Botón de Resta

  // Inicializa la Librería
  gtk_init(&argc, &argv);

  // Crea la Ventana Principal
  wgtAplicacion = gtk_window_new(GTK_WINDOW_TOPLEVEL);

  // Centra la Ventana
  gtk_window_set_position(GTK_WINDOW(wgtAplicacion), GTK_WIN_POS_CENTER);

  // Establece su tamaño por default
  gtk_window_set_default_size(GTK_WINDOW(wgtAplicacion), 250, 180);

  // Coloca el Texto a la Ventana
  gtk_window_set_title(GTK_WINDOW(wgtAplicacion), "08_Contenedores Botones y Etiquetas");

  // Crea un Contenedor Frame(Marco)
  frmOperacion = gtk_fixed_new();

  // Agrega el frame a la Ventana
  gtk_container_add(GTK_CONTAINER(wgtAplicacion), frmOperacion);


  // Crea el Botón de la Suma
  btnSuma = gtk_button_new_with_label("+");
  gtk_widget_set_size_request(btnSuma, 80, 35);
  gtk_fixed_put(GTK_FIXED(frmOperacion), btnSuma, 50, 20);

  // Variable para el Color
  GdkColor color;

  // Establecemos el Color para el Botón de la Suma
  gdk_color_parse ("green", &color);

  // Selected hace referencia al Borde
  gtk_widget_modify_bg(btnSuma, GTK_STATE_ACTIVE, &color);

  // Crea el Botón para la Resta
  btnResta = gtk_button_new_with_label("-");
  gtk_widget_set_size_request(btnResta, 80, 35);
  gtk_fixed_put(GTK_FIXED(frmOperacion), btnResta, 50, 80);
  gdk_color_parse ("blue", &color);

  // Normal hace referencia al Cuerpo del Botón
  gtk_widget_modify_bg(btnResta, GTK_STATE_NORMAL, &color);

  // Crea la etiqueta del resultado
  lblResultado = gtk_label_new("0");
  gtk_fixed_put(GTK_FIXED(frmOperacion), lblResultado, 190, 58);

  // Mostramos todos los Objetos de la Ventana Principal
  gtk_widget_show_all(wgtAplicacion);

  // Conectamos la Señal de Destruir
  g_signal_connect(wgtAplicacion, "destroy",G_CALLBACK (gtk_main_quit), NULL);

  // Conectamos la Señal de Clicked del Botón de Sumar
  g_signal_connect(btnSuma, "clicked",G_CALLBACK(sbSumarUno), lblResultado);

  // Conectamos la Señal de Clicked del Botón de Sumar
  g_signal_connect(btnResta, "clicked",G_CALLBACK(sbRestarUno), lblResultado);

  // Loop Principal
  gtk_main();

  return 0;
}
