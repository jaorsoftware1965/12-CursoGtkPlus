/*

Curso de Programación con Gtk+
Autor:JAOR
Derechos Reservados: JaorSoftware
www.jaorsoftware.com
www.jaorsoftware.cc.cu

Clase 05_Controlando_Ventana_II

Para esta clase veremos como poder establecer el tamaño
de la Ventana y como asignar un Ícono a la aplicación
el cual se despliega en la barra de Aplicaciones en
ejecución.


FUNCION PARA EL TAMAÑO DE LA VENTANA.
void gtk_window_set_default_size (GtkWindow *window,
                                  gint width,
                                  gint height);

Para establecer el tamaño de una ventana,distinto al
valor por default, se hace uso de la función anterior.
Esta función recibe como parámetro, el widget y el ancho
y alto que se establecerá.

FUNCION PARA ESTABLECER EL ÍCONO
void gtk_window_set_icon (GtkWindow *window, GdkPixbuf *icon);

Para colocar el icono de la aplicación hacemos uso de la
anterior función.

Al igual que la anterior, recibe como parámetro un widget,
y un objeto del tipo GkdPixbuf; en el cual se indica la
imagen a colocar.


*/
// Se incluye la librería
#include <gtk/gtk.h>

// Funcion para controlar la Señal de Destrucción
static void SbMainExit(GtkWidget *window, gpointer data)
{
    // Mensaje de que la ventana se ha destruido
    printf("Destroy Signal \n");

    // Llama a la función de la Librería que sale del Ciclo Main
    gtk_main_quit ();
}

// Función para controlar el Cierre de una Ventana
static gboolean FngBoolDeleteEvent(GtkWidget *window, GdkEvent *event)
{
    // Mensaje
    printf("Delete Event\n");

    // Valor de Retorno
    return FALSE;
}


// Rutina para cargar la Imagen del Icono
GdkPixbuf *FnPixbufCreate(const gchar * filename)
{
   // Variable para abrir el Archivo Imagen
   GdkPixbuf *pixbuf;

   // Variable para error
   GError *error = NULL;

   // Crea la Referencia al Archivo Imagen
   pixbuf = gdk_pixbuf_new_from_file(filename, &error);

   // Verifica que no haya habido error
   if(!pixbuf)
   {
      // Despliega el Mensaje de error
      fprintf(stderr, "%s\n", error->message);
      g_error_free(error);
   }

   // Retorna el Objeto
   return pixbuf;
}

// Función Principal
int main_05( int argc, char *argv[])
{

    // Objeto para el Widget
  GtkWidget *window;

  // Inicializa la Librería
  gtk_init (&argc, &argv);

  // Crea el Widget con el Objeto declarado
  window = gtk_window_new (GTK_WINDOW_TOPLEVEL);

  // Coloca el Título
  gtk_window_set_title (GTK_WINDOW (window), "05_Controlando la Ventana II");

  // Estableciendo el Tamaño de la Ventana
  gtk_window_set_default_size(GTK_WINDOW(window), 450, 450);

  // Estableciendo el Ícono de la Aplicación
  gtk_window_set_icon(GTK_WINDOW(window), FnPixbufCreate("js2.jpg"));

  // Controla la Señal de Destrucción del Objeto
  g_signal_connect(G_OBJECT(window), "destroy",G_CALLBACK(SbMainExit), NULL);

  // Controla la Señal del evento "delete_event" de la Ventana-Widget
  g_signal_connect (G_OBJECT (window), "delete_event", G_CALLBACK (FngBoolDeleteEvent), NULL);

  // Muestra la Ventana
  gtk_widget_show(window);

  // Ejecuta el Ciclo Principal de la Aplicación
  gtk_main ();

  // Finaliza la Aplicación
  return 0;
}
