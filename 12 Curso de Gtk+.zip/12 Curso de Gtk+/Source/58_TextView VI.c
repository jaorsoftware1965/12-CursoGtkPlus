/*

Autor    : JAOR
Curso    : Library Gtk+
Clase 58 : TextView VI

En esta clase veremos como obtener la línea
y la columna en la cual se encuentra el cursor.


*/

// Se Incluye la Librería
#include <gtk/gtk.h>

// Función para actualizar la Barra de Estado
void SbBarraEstadoActualiza(GtkTextBuffer *buffer, GtkStatusbar  *statusbar)
{
  // Declaración de Variables
  gchar *msg;       // Mensaje
  gint row, col;    // Renglon y Columna
  GtkTextIter iter; // Item

  // Llama a función para obtener el Status Bar
  gtk_statusbar_pop(statusbar, 0);

  // Obtiene la Información de donde está el cursor
  gtk_text_buffer_get_iter_at_mark(buffer,&iter, gtk_text_buffer_get_insert(buffer));

  // Obtiene el Row y la Col
  row = gtk_text_iter_get_line(&iter);
  col = gtk_text_iter_get_line_offset(&iter);

  // Construye el Mensaje
  msg = g_strdup_printf("Col: %d Ln: %d", col+1, row+1);

  // Coloca la Información en el Status Bar
  gtk_statusbar_push(statusbar, 0, msg);

  // Libera la Memoria
  g_free(msg);

}

// Coloca la Marca
void SbEstableceMarcaCallBack(GtkTextBuffer *buffer,
                    const GtkTextIter *new_location,
                                  GtkTextMark *mark,
                                      gpointer data)
{
  // Actualiza el Status Bar
  SbBarraEstadoActualiza(buffer, GTK_STATUSBAR(data));
}


// Función Principal
int main(int argc, char *argv[])
{

  // Declaración de Variables
  GtkWidget *window;      // Ventana Principal
  GtkWidget *vbox;        // Contenedor Vertical
  GtkWidget *toolbar;     // Barra de Herramientas
  GtkWidget *view;        // TextView
  GtkWidget *statusbar;   // StatusBar
  GtkToolItem *exit;      // Botón en el Status Bar
  GtkTextBuffer *buffer;  // Buffer del TextView

  // Inicializa la librería
  gtk_init(&argc, &argv);

  // Crea la Ventana Principal y la Configura
  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);
  gtk_window_set_default_size(GTK_WINDOW(window), 350, 300);
  gtk_window_set_title(GTK_WINDOW(window), "Clase 58 - TextView VI");

  // Crea el Contenedor Vertical y lo agrega a la ventana principal
  vbox = gtk_vbox_new(FALSE, 0);
  gtk_container_add(GTK_CONTAINER(window), vbox);

  // Crea la Barra de Herraientas y establece el Estilo
  toolbar = gtk_toolbar_new();
  gtk_toolbar_set_style(GTK_TOOLBAR(toolbar), GTK_TOOLBAR_ICONS);

  // Crea un botón desde el Stock y lo agrega a la barra de herramientas
  exit = gtk_tool_button_new_from_stock(GTK_STOCK_QUIT);
  gtk_toolbar_insert(GTK_TOOLBAR(toolbar), exit, -1);

  // Agrega la Barra de Herramientas al Contenedor Vertical
  gtk_box_pack_start(GTK_BOX(vbox), toolbar, FALSE, FALSE, 5);

  // Crea el TextView y lo configura
  view = gtk_text_view_new();
  gtk_text_view_set_wrap_mode(GTK_TEXT_VIEW(view), GTK_WRAP_WORD);
  gtk_box_pack_start(GTK_BOX(vbox), view, TRUE, TRUE, 0);
  gtk_widget_grab_focus(view);

  // Obtiene la Información del Buffer
  buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(view));

  // Creamos el Estatus Bar
  statusbar = gtk_statusbar_new();
  gtk_box_pack_start(GTK_BOX(vbox), statusbar, FALSE, FALSE, 0);

  // Captura la señal del botón y del buffer del TextView
  g_signal_connect(G_OBJECT(exit), "clicked",G_CALLBACK(gtk_main_quit), NULL);
  g_signal_connect(buffer, "changed",G_CALLBACK(SbBarraEstadoActualiza), statusbar);

  // La señal mark_set se ejecuta cuando el cursor cambia de posición
  g_signal_connect(buffer, "mark_set",G_CALLBACK(SbEstableceMarcaCallBack), statusbar);
  g_signal_connect(G_OBJECT(window), "destroy",G_CALLBACK(gtk_main_quit), NULL);

  // Muestra todos los objtos
  gtk_widget_show_all(window);

  // Actualiza el StatusBar
  SbBarraEstadoActualiza(buffer, GTK_STATUSBAR(statusbar));

  // Ejecuta el Ciclo Principal
  gtk_main();

  // Finaliza y Retorna 0
  return 0;

}
