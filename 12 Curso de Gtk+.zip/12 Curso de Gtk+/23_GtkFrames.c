/*
Curso de Programación con Gtk+
Autor:JAOR
Derechos Reservados: JaorSoftware
www.jaorsoftware.com

Clase 23 - Frame

En esta clase, veremos otro objeto común en los Sistemas
Operativos gráficos y que es el Frame o Marco.

El Frame es un objeto delimitado por una linea y en el cual
es posible desplegar un título, para indicar la información
que contendrá.

La función que utilizaremos para crear un frame es la siguiente:

gtk_frame_new("Titulo del Frame")


Es posible que un frame, tenga diferentes estilos en la línea
que utiliza para delinearlo; y para indicar esto se utiliza
la función:

gtk_frame_set_shadow_type

En la aplicación de ejemplo, veremos que este ejemplo no está
funcionando correctamente, tal vez porque la función ya no se
encuentre actualizada para la versión 3.0 del frame.


*/

// Se incluye lalibrería
#include <gtk/gtk.h>

// Función Principal
int main_23(int argc, char *argv[]) {

  // Declaración de variables para los objetos
  GtkWidget *window;   // Declaración del Objeto para la ventana
  GtkWidget *table;    // Declaración del Objeto para la Tabla

  // Declaración de las variables para los frames
  GtkWidget *frame1;
  GtkWidget *frame2;
  GtkWidget *frame3;
  GtkWidget *frame4;

  // Inicializa la librería
  gtk_init(&argc, &argv);

  // Genera la Ventana
  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);

  // Establece la posición
  gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);

  // Establece el tamaño de la ventana
  gtk_window_set_default_size(GTK_WINDOW(window), 250, 250);

  // Establece el título de la ventana
  gtk_window_set_title(GTK_WINDOW(window), "Clase 23 - GtkFrame");

  // Establece el borde de la Ventana
  gtk_container_set_border_width(GTK_CONTAINER(window), 10);

  // Crea una tabla de 2 x 2
  table = gtk_table_new(2, 2, TRUE);

  // Establece los espaciones entre la columnas y renglones de la tabla
  gtk_table_set_row_spacings(GTK_TABLE(table), 10);
  gtk_table_set_col_spacings(GTK_TABLE(table), 10);

  // Agrega la tabla a la Ventana Principal
  gtk_container_add(GTK_CONTAINER(window), table);

  // Establece el tipo de sombra del Frame1 y lo crea
  frame1 = gtk_frame_new("Shadow In");
  gtk_frame_set_shadow_type(GTK_FRAME(frame1), GTK_SHADOW_IN);

  // Establece el tipo de sombra del Frame2 y lo crea
  frame2 = gtk_frame_new("Shadow Out");
  gtk_frame_set_shadow_type(GTK_FRAME(frame2), GTK_SHADOW_OUT);

  // Establece el tipo de sombra del Frame3 y lo crea
  frame3 = gtk_frame_new("Shadow Etched In");
  gtk_frame_set_shadow_type(GTK_FRAME(frame3), GTK_SHADOW_ETCHED_IN);

  // Establece el tipo de sombra del Frame4 y lo crea
  frame4 = gtk_frame_new("Shadow Etched Out");
  gtk_frame_set_shadow_type(GTK_FRAME(frame4), GTK_SHADOW_ETCHED_OUT);

  // Agrega los frames a la tabla
  gtk_table_attach_defaults(GTK_TABLE(table), frame1, 0, 1, 0, 1);
  gtk_table_attach_defaults(GTK_TABLE(table), frame2, 0, 1, 1, 2);
  gtk_table_attach_defaults(GTK_TABLE(table), frame3, 1, 2, 0, 1);
  gtk_table_attach_defaults(GTK_TABLE(table), frame4, 1, 2, 1, 2);

  // Establece la Conexion de la Señal de Cierre de la Ventana
  g_signal_connect(G_OBJECT(window), "destroy",G_CALLBACK(gtk_main_quit), G_OBJECT(window));

  // Muestra todos los objetos
  gtk_widget_show_all(window);

  // Ejecuta el Loop Principal
  gtk_main();

  // Finaliza la aplicación retornando 0
  return 0;

}

