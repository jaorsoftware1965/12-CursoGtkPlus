/*
Curso de Programación con Gtk+
Autor:JAOR
Derechos Reservados: JaorSoftware
www.jaorsoftware.cc.cu

Clase 10_Contenedor GtkHBox

En esta Clase veremos el Contenedor de la Clase GtkHBox.
Este contenedor es la contraparte del GtkVBox.

Este es un tipo de Contenedor que maneja Cajas alineadas en forma Horizontal;
formando 1 línea de cajas.

Veremos que al igual que con todos los objetos que hemos estudiado; este
objeto tambien inicialmente es declarado como Widget; y posteriormente
la función que lo crea; es la que le da las características.

*/

// Incluimos la Librería
#include <gtk/gtk.h>

// Función Principal
int main_10( int argc, char *argv[])
{

  GtkWidget *wgtAplicacion;   // El Objeto de la Ventana Principal
  GtkWidget *hboxContenedor;  // Contenedor HBox
  GtkWidget *btnNumero1;      // Botones
  GtkWidget *btnNumero2;
  GtkWidget *btnNumero3;
  GtkWidget *btnNumero4;
  GtkWidget *btnNumero5;

  // Inicializa la Aplicación
  gtk_init(&argc, &argv);

  // Crea la Ventana Principal
  wgtAplicacion = gtk_window_new(GTK_WINDOW_TOPLEVEL);

  // Centra la Ventana
  gtk_window_set_position(GTK_WINDOW(wgtAplicacion), GTK_WIN_POS_CENTER);

  // Define su tamaño
  gtk_window_set_default_size(GTK_WINDOW(wgtAplicacion), 350, 350);

  // Establece el Título
  gtk_window_set_title(GTK_WINDOW(wgtAplicacion), "Clase 10_Contenedor GtkHBox");

  // Establece un Borde
  gtk_container_set_border_width(GTK_CONTAINER(wgtAplicacion), 5);

  // Crea el Contenedor indicando que son homogeneos y un espacio de 1
  // GtkWidget *gtk_vbox_new (gboolean homogeneous, gint spacing);
  hboxContenedor = gtk_hbox_new(TRUE, 1);

  // Añade el Contenedor a la Ventana Principal
  gtk_container_add(GTK_CONTAINER(wgtAplicacion), hboxContenedor);

  // Crea los Botones
  btnNumero1 = gtk_button_new_with_label("Uno");
  btnNumero2 = gtk_button_new_with_label("Dos");
  btnNumero3 = gtk_button_new_with_label("Tres");
  btnNumero4 = gtk_button_new_with_label("Cuatro");
  btnNumero5 = gtk_button_new_with_label("Cinco");

  // Añade los Botones al Contenedor
  // void gtk_box_pack_start (GtkBox *box,GtkWidget *child,gboolean expand,gboolean fill,guint padding);
  gtk_box_pack_start(GTK_BOX(hboxContenedor), btnNumero1, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(hboxContenedor), btnNumero2, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(hboxContenedor), btnNumero3, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(hboxContenedor), btnNumero4, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(hboxContenedor), btnNumero5, TRUE, TRUE, 0);

  // Captura la Señal para destruir el Objeto
  g_signal_connect_swapped(G_OBJECT(wgtAplicacion), "destroy",G_CALLBACK(gtk_main_quit), G_OBJECT(wgtAplicacion));

  // Muestra todos los objetos de la Aplicación
  gtk_widget_show_all(wgtAplicacion);

  // Ciclo Principal
  gtk_main();

  return 0;
}

