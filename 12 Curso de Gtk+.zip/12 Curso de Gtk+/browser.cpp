/*

Autor    : JAOR

*/

// Incluimos la Librería
#include <gtk/gtk.h>

// Incluimos la librería
#include "browser.h"

// Función Principal
int main (int argc,char *argv[])
{
   // Declaración de Variables
   GtkWidget       *window;  // Ventana Principal

   // Inicializa la librería
   gtk_init (&argc, &argv);

   // Crea y configura la Ventana Principal
   window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
   gtk_window_set_title (GTK_WINDOW (window), "JAOR Web Browser 1.0");
   gtk_container_set_border_width (GTK_CONTAINER (window), 10);
   gtk_widget_set_size_request (window, 400, 300);

   // Muestra los objetos y Finaliza Retornando 0
   gtk_widget_show_all (window);
   gtk_main();
   return 0;
}
