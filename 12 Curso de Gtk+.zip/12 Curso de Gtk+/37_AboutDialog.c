/*

Autor:JAOR
Derechos Reservados: JaorSoftware
http://jaorsoftware.cu.cc/

Curso de Librería Gtk+
Clase 37 - About Dialog

En esta clase veremos lo que es un About Dialog.
Un AboutDialog es una ventana que se muestra en las aplicaciones
para desplegar información con respecto a la Aplicación
y a quien la ha desarrollado; entre otras cosas.

Alguien que ya tenga experiencia en programación en
otros lenguajes, podrá argumentar que los About
Dialog los crea el Programador a su gusto; que no
tienen porque ser un objeto especial; pero pues
resulta que para esta librería si lo es.

La librería a través de la función gtk_about_dialog_new
nos permite crear un About Dialog, con un diseño ya
predefinido; el cual nos agiliza y facilita el diseño
de esta ventana.

En caso de que el Diseño del About Dialog, que nos
presenta la librería; no se adapte a nuestro gusto
o necesidades; pues entonces la diseñaremos como
queramos.

En esta Clase veremos muchas otras cosas interesantes
y útiles de la librería.

*/

// Incluye la Librería
#include <gtk/gtk.h>

// Función Principal del Programa
int main (int argc,char *argv[])
{
    // Declaración de Constantes
    const gchar *authors[] =
    {
        "Don Gato",
        "y su Pandilla",
        NULL
    };
    const gchar *documenters[] =
    {
        "Juan Pérez",
        "Benito Bodoque",
        NULL
    };

    // Declaración de Variables
    GtkWidget *dialog;
    GdkPixbuf *logo;
    GError    *error = NULL;

    // Inicializa la Librería
    gtk_init (&argc, &argv);

    // Se crea el Nuevo Dialogo
    dialog = gtk_about_dialog_new ();

    /* Cargamos una imagen como Logo del About Dialog */
    logo = gdk_pixbuf_new_from_file ("jaorsoftware.jpg", &error);

    /* Verifica si hubo error en la Carga de la imagen */
    if (error == NULL)
       // Coloca la imagen en el About Dialog
       gtk_about_dialog_set_logo (GTK_ABOUT_DIALOG (dialog), logo);
    else
    {
        // Despliega el Tipo de Error en la Carga
        if (error->domain == GDK_PIXBUF_ERROR)
            g_print ("GdkPixbufError: %s\n", error->message);
        else if (error->domain == G_FILE_ERROR)
            g_print ("GFileError: %s\n", error->message);
        else
            g_print ("Un error : %d ha ocurrido!\n", error->domain);

        // Libera la Memoria
        g_error_free (error);
    }

    /* Coloca los Datos a ser Desplegados en el About Dialog */
    gtk_about_dialog_set_program_name(GTK_ABOUT_DIALOG (dialog), "Clase 37 - GtkAboutDialog");
    gtk_about_dialog_set_version (GTK_ABOUT_DIALOG (dialog), "1.0");
    gtk_about_dialog_set_copyright (GTK_ABOUT_DIALOG (dialog),"(C) 2015 JAORSOFTWARE");
    gtk_about_dialog_set_comments (GTK_ABOUT_DIALOG (dialog),"Acerca de GtkAboutDialog");

    /* Set the license text, which is usually loaded from a file. Also, set the
    * web site address and label. */
    gtk_about_dialog_set_license (GTK_ABOUT_DIALOG (dialog), "Información sobre Licencia");
    gtk_about_dialog_set_website (GTK_ABOUT_DIALOG (dialog), "http://jaorsoftware.cu.cc");
    gtk_about_dialog_set_website_label (GTK_ABOUT_DIALOG (dialog),"jaorsoftware");

    /* Coloca mas información que utiliza el About Dialog */
    gtk_about_dialog_set_authors (GTK_ABOUT_DIALOG (dialog), authors);
    gtk_about_dialog_set_documenters (GTK_ABOUT_DIALOG (dialog), documenters);
    gtk_about_dialog_set_translator_credits (GTK_ABOUT_DIALOG (dialog),"Google Translator\nBabylon Translator");

    // Ejecuta el Diálogo
    gtk_dialog_run (GTK_DIALOG (dialog));

    // Destruye el Diálogo
    gtk_widget_destroy (dialog);

    // Finaliza la Aplicación
    return 0;

}
