/*

Autor    : JAOR
Curso    : Library Gtk+
Clase 56 : TextView IV

En esta clase veremos como copiar, cortar y pegar
texto en un objeto TextView.

*/

// Incluimos la librería
#include <gtk/gtk.h>

// Predefinición de FUnciones
// Copia el Texto Seleccionado al ClipBoard y lo remueve del Buffer
static void SbTextoCortar (GtkButton *btnCortar,GtkTextView *textview)
{
   // Define una variable de tipo ClipBoard y obtiene lo que se encuentra seleccionado
   GtkClipboard *clipboard = gtk_clipboard_get (GDK_SELECTION_CLIPBOARD);

   // Define una variable buffer y obtiene el texto seleccionado
   GtkTextBuffer *buffer = gtk_text_view_get_buffer (textview);

   // Corta del Buffer el Texto
   gtk_text_buffer_cut_clipboard (buffer, clipboard, TRUE);
}

// Copia el Texto Seleccionado al ClipBoard
static void SbTextoCopiar (GtkButton *btnCopiar, GtkTextView *textview)
{
   // Define una variable de tipo ClipBoard y obtiene lo que se encuentra seleccionado
   GtkClipboard *clipboard = gtk_clipboard_get (GDK_SELECTION_CLIPBOARD);

   // Define una variable buffer y obtiene el texto seleccionado
   GtkTextBuffer *buffer = gtk_text_view_get_buffer (textview);

   // Copia en el Buffer
   gtk_text_buffer_copy_clipboard (buffer, clipboard);
}

// Inserta el Texto desde el Clipboard al Buffer
static void SbTextoPegar (GtkButton *btnPegar, GtkTextView *textview)
{
   // Define una variable de tipo ClipBoard y obtiene lo que se encuentra seleccionado
   GtkClipboard *clipboard = gtk_clipboard_get (GDK_SELECTION_CLIPBOARD);

   // Define una variable buffer y obtiene el texto seleccionado
   GtkTextBuffer *buffer = gtk_text_view_get_buffer (textview);

   // Copia en el Buffer
   gtk_text_buffer_paste_clipboard (buffer, clipboard, NULL, TRUE);
}

// Función Principal
int main (int argc,char *argv[])
{
   // Declaración de Variables
   GtkWidget       *window,  // Ventana Principal
             *scrolled_win,  // El Scroll
                 *textview,  // El TextView
                *btnCortar,  // El botón para Cortar
                *btnCopiar,  // El botón para copiar
                 *btnPegar,  // El botón para pegar
                     *hbox,  // El Contenedor Horizontal
                     *vbox;  // El Contenedor Vertical

   // Inicializa la librería
   gtk_init (&argc, &argv);

   // Crea y configura la Ventana Principal
   window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
   gtk_window_set_title (GTK_WINDOW (window), "Clase 56 - TextView IV");
   gtk_container_set_border_width (GTK_CONTAINER (window), 10);

   // Crea el Textview
   textview = gtk_text_view_new ();

   // Crea los 3 botones
   btnCortar = gtk_button_new_from_stock (GTK_STOCK_CUT);
   btnCopiar = gtk_button_new_from_stock (GTK_STOCK_COPY);
   btnPegar = gtk_button_new_from_stock (GTK_STOCK_PASTE);

   // Captura las Señales de los Botones
   g_signal_connect (G_OBJECT (btnCortar), "clicked",G_CALLBACK (SbTextoCortar),(gpointer) textview);
   g_signal_connect (G_OBJECT (btnCopiar), "clicked",G_CALLBACK (SbTextoCopiar),(gpointer) textview);
   g_signal_connect (G_OBJECT (btnPegar) , "clicked",G_CALLBACK (SbTextoPegar),(gpointer) textview);

   // Crea el Scroll y configura el tamaño
   scrolled_win = gtk_scrolled_window_new (NULL, NULL);
   gtk_widget_set_size_request (scrolled_win, 300, 200);

   // Agrega el Textview al Contenedor
   gtk_container_add (GTK_CONTAINER (scrolled_win), textview);

   // Crea los contenedores y agrega los objetos
   hbox = gtk_hbox_new (TRUE, 5);
   gtk_box_pack_start (GTK_BOX (hbox), btnCortar, TRUE, TRUE, 0);
   gtk_box_pack_start (GTK_BOX (hbox), btnCopiar, TRUE, TRUE, 0);
   gtk_box_pack_start (GTK_BOX (hbox), btnPegar, TRUE, TRUE, 0);
   vbox = gtk_vbox_new (FALSE, 5);
   gtk_box_pack_start (GTK_BOX (vbox), scrolled_win, TRUE, TRUE, 0);
   gtk_box_pack_start (GTK_BOX (vbox), hbox, FALSE, TRUE, 0);
   gtk_container_add (GTK_CONTAINER (window), vbox);

   // Muestra los objetos y Finaliza Retornando 0
   gtk_widget_show_all (window);
   gtk_main();
   return 0;
}

