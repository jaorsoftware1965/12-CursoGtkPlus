/*

Curso de Programación con Gtk+
Autor:JAOR
Derechos Reservados: JaorSoftware
www.jaorsoftware.com

Clase 27 - ToogleButton

En esta clase veremos otro objeto algo especial de la librería
y que es un ToogleButton.

Un ToogleButton es un botón que tiene 2 estados: presionado y
sin presionar.

Por lo general, un botón común de una interfaz
gráfica se presiona y se despresiona como un solo movimiento;
no tiene 2 estados; pero para este tipo de botón, si hay 2
estados.

*/

// Incluye a la librería
#include <gtk/gtk.h>

// Función CallBack para controlar el Evento del ButtonToogle
static void SbButtonToggled (GtkToggleButton*, GtkWidget*);


// Función Principal
int main_27(int argc,char *argv[])
{
   // Declaración de Variables con los objetos
   GtkWidget *window,    // Ventana Pricipal
             *vbox,      // Contenedor VBox
             *toggle1,   // ButtonToogle1
             *toggle2;   // ButtonToogle2

   // Inicialización de la Librería
   gtk_init (&argc, &argv);

   // Creamos la Ventana Principal
   window = gtk_window_new (GTK_WINDOW_TOPLEVEL);

   // Colocamos el Título de la Ventana
   gtk_window_set_title (GTK_WINDOW (window), "Clase 27 - Toggle Buttons");

   // Establece el Borde de la Ventana
   gtk_container_set_border_width (GTK_CONTAINER (window), 10);

   // Crea el Contenedor VBOX
   vbox = gtk_vbox_new (TRUE, 5);

   // Crea los 2 ToogleButton
   toggle1 = gtk_toggle_button_new_with_mnemonic ("_Desactiva el Otro!");
   toggle2 = gtk_toggle_button_new_with_mnemonic ("De_sactiva el Otro!");

   // Asocia la Señal "toogled" de los 2 botones a la Función SbButtonToggled
   g_signal_connect (G_OBJECT (toggle1), "toggled",G_CALLBACK (SbButtonToggled),(gpointer) toggle2);
   g_signal_connect (G_OBJECT (toggle2), "toggled",G_CALLBACK (SbButtonToggled),(gpointer) toggle1);

   // Asocia el evento destroy de la ventana principal */
   g_signal_connect( G_OBJECT( window ), "destroy", G_CALLBACK( gtk_main_quit ), NULL );

   // Agrega los Botones al VBOX
   gtk_box_pack_start(GTK_BOX (vbox), toggle1,TRUE,TRUE,1);
   gtk_box_pack_start(GTK_BOX (vbox), toggle2,TRUE,TRUE,1);

   // Agrega el Box Contenedor a la Ventana Principal
   gtk_container_add (GTK_CONTAINER (window), vbox);

   // Muestra los Widgets de la Ventana
   gtk_widget_show_all (window);

   // Inicia el Loop Principal
   gtk_main ();

   // Finaliza Retornando 0
   return 0;
}

/* Función para activar y desactivar los ButtonTooglet */
static void SbButtonToggled (GtkToggleButton *toggle, GtkWidget *other_toggle)
{
   // Verifica si el botón está activo
   if (gtk_toggle_button_get_active (toggle))
      // Deshabilita
      gtk_widget_set_sensitive (other_toggle, FALSE);
   else
      // Habilita
      gtk_widget_set_sensitive (other_toggle, TRUE);
}
