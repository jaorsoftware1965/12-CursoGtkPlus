/*

Autor    : JAOR
Company  : JaorSoftware
Curso    : Library Gtk+
Clase 46 : ListView II

En esta clase continuaremos el aprendizaje del ListView.
Ahora veremos como podemos agregar elementos y eliminar
elementos dinámicamente


*/

// Incluimos
#include <gtk/gtk.h>

// Declara la Variable que controla la lista, global
GtkWidget *list;

// Función para agregar un Item
void SbListaAgregaElemento(GtkWidget *widget, gpointer entry)
{

  // Variable para el Modelo de Datos
  GtkListStore *store;

  // Variable para el Item
  GtkTreeIter iter;

  // Variable para obtener el texto de entrada
  const gchar *str = gtk_entry_get_text(entry);

  // Obtiene el Modelo de Datos
  store = GTK_LIST_STORE(gtk_tree_view_get_model(GTK_TREE_VIEW(list)));

  // Añade el Item
  gtk_list_store_append(store, &iter);
  gtk_list_store_set(store, &iter, 0, str, -1);

  // Limpia la entrada
  gtk_entry_set_text(entry, "");

}


// Elimina un Elemento de la lista
void SbListaEliminaElemento(GtkWidget *widget, gpointer selection)
{

  // Variables para obtener los datos
  //GtkListStore *store;
  GtkTreeModel *model;
  GtkTreeIter  iter;

  // Obtiene el Modelo como List_Store
  //store = GTK_LIST_STORE(gtk_tree_view_get_model(GTK_TREE_VIEW(list)));

  // Obtiene el Modelo
  model = gtk_tree_view_get_model(GTK_TREE_VIEW(list));

  // Verifica que esté seleccionado alguno
  if (gtk_tree_selection_get_selected(GTK_TREE_SELECTION(selection),&model, &iter))
  {
     // Elimina el Elemento de la Lista
     gtk_list_store_remove(GTK_LIST_STORE(model), &iter);
  }
}

// Elimina todos los elementos de la Lista
void SbListaLimpia(GtkWidget *widget, gpointer selection) {

  GtkListStore *store;
  //GtkTreeModel *model;
  GtkTreeIter  iter;

  store = GTK_LIST_STORE(gtk_tree_view_get_model(GTK_TREE_VIEW(list)));
  //model = gtk_tree_view_get_model(GTK_TREE_VIEW(list));

  // Elimina todos los elementos de la Lista
  gtk_list_store_clear(store);
}

// Inicaliza la Lista
void SbListaInicializa(GtkWidget *list)
{

  // Variables para los datos
  GtkCellRenderer    *renderer;
  GtkTreeViewColumn  *column;
  GtkListStore       *store;

  // Crea una Celda
  renderer = gtk_cell_renderer_text_new();

  // Crea una Columna y la añade
  column = gtk_tree_view_column_new_with_attributes("Elementos",renderer, "text", 0, NULL);
  gtk_tree_view_append_column(GTK_TREE_VIEW(list), column);
  store = gtk_list_store_new(1, G_TYPE_STRING);

  // Establece el Modelo
  gtk_tree_view_set_model(GTK_TREE_VIEW(list), GTK_TREE_MODEL(store));
  g_object_unref(store);
}


// Función Principal
int main(int argc, char *argv[]) {

  // Declaración de Variables
  GtkWidget *window;   // Ventana Principal
  GtkWidget *sw;       // Scroll

  GtkWidget *remove;   // Botón para Eliminar
  GtkWidget *add;      // Botón para Agregar
  GtkWidget *removeAll;// Botón para Eliminar Todos
  GtkWidget *entry;    // Entrada de Texto

  GtkWidget *vbox;  // Contenedor
  GtkWidget *hbox;  // Contenedor

  GtkTreeSelection *selection;   // Para Controlar la Selección

  // Inicializa la Librería
  gtk_init(&argc, &argv);

  // Define la Ventana Inicial
  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title(GTK_WINDOW(window), "Clase 46 - Listview2");
  gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);
  gtk_container_set_border_width(GTK_CONTAINER (window), 10);
  gtk_widget_set_size_request(window, 370, 270);

  // Crea un objeto para controlar el Scroll del List
  sw = gtk_scrolled_window_new(NULL, NULL);

  // Crea la Lista
  list = gtk_tree_view_new();

  // Agrega la Lista al Scroll
  gtk_container_add(GTK_CONTAINER(sw), list);

  // Define el Scroll, automático para vertical y horizontal
  gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(sw),GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);

  // Establece el Tipo de Sombra del Scroll
  gtk_scrolled_window_set_shadow_type(GTK_SCROLLED_WINDOW(sw),GTK_SHADOW_ETCHED_IN);

  // Oculta los Encabezados de las Columnas
  gtk_tree_view_set_headers_visible(GTK_TREE_VIEW(list), FALSE);

  // Crea el Contenedor Vertical y agrega el Scroll
  vbox = gtk_vbox_new(FALSE, 0);
  gtk_box_pack_start(GTK_BOX(vbox), sw, TRUE, TRUE, 5);

  // Crea el Contenedor Horizontal
  hbox = gtk_hbox_new(FALSE, 5);

  // Crea los 3 botones y la entrada
  add = gtk_button_new_with_label("Insertar");
  remove = gtk_button_new_with_label("Eliminar");
  removeAll = gtk_button_new_with_label("Eliminar Todos");
  entry = gtk_entry_new();

  // Establece el tamaño del Widget de Entrada
  gtk_widget_set_size_request(entry, 120, -1);

  // Añade los Elementos a el Contenedor
  gtk_box_pack_start(GTK_BOX(hbox), add, FALSE, TRUE, 3);
  gtk_box_pack_start(GTK_BOX(hbox), entry, FALSE, TRUE, 3);
  gtk_box_pack_start(GTK_BOX(hbox), remove, FALSE, TRUE, 3);
  gtk_box_pack_start(GTK_BOX(hbox), removeAll, FALSE, TRUE, 3);
  gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, TRUE, 3);

  // Añade el Contenedor a la Ventana Principal
  gtk_container_add(GTK_CONTAINER(window), vbox);

  // Inicializa la Lista
  SbListaInicializa(list);

  // Obtiene el Objeto Selección
  selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(list));

  // Establece las Señales de Clicked para cada botón y coloca sus Funciones CallBack
  g_signal_connect(G_OBJECT(add), "clicked",G_CALLBACK(SbListaAgregaElemento), entry);
  g_signal_connect(G_OBJECT(remove), "clicked",G_CALLBACK(SbListaEliminaElemento), selection);
  g_signal_connect(G_OBJECT(removeAll), "clicked",G_CALLBACK(SbListaLimpia), selection);
  g_signal_connect(G_OBJECT(window), "destroy",G_CALLBACK(gtk_main_quit), NULL);

  // Muestra todos los objetos de la Ventana
  gtk_widget_show_all(window);

  // Inicializa al Ciclo Principal
  gtk_main();

  // Finaliza Retornando 0
  return 0;

}
