/*

Autor:JAOR
Derechos Reservados: JaorSoftware

Curso de Librería Gtk+
Clase 42 - FileChooserDialog 3

*/

#include <gtk/gtk.h>
static void button_clicked (GtkButton *button,GtkWindow *window)
{
    // Variable para el Diálogo
    GtkWidget *dialog;

    // Lista de Cadenas
    GSList *filenames;

    /* Crea el diálogo para crear la Carpeta */
    dialog = gtk_file_chooser_dialog_new (
                "Selecciona Varios Archivos...",
                window,
                GTK_FILE_CHOOSER_ACTION_OPEN,
                GTK_STOCK_CANCEL, GTK_RESPONSE_CANCEL,
                GTK_STOCK_OPEN, GTK_RESPONSE_ACCEPT,
                NULL);

    /* Habilita el Seleccionar mas de un Archivo */
    gtk_file_chooser_set_select_multiple (GTK_FILE_CHOOSER (dialog), TRUE);

    // Ejecuta el Diálogo y Obtiene el Resultado
    gint result = gtk_dialog_run (GTK_DIALOG (dialog));

    // Verifica acción del Usuario
    if (result == GTK_RESPONSE_ACCEPT)
    {
        // Obtiene el Nombre del Archivo
        filenames = gtk_file_chooser_get_filenames (GTK_FILE_CHOOSER (dialog));

        // Verifica que haya leido
        while (filenames != NULL)
        {
            // Obtiene cada uno de los archivos
            gchar *file = (gchar*) filenames->data;
            g_print ("%s seleccionado \n", file);
            filenames = filenames->next;
        }
    }

    // Destruye el Diálogo
    gtk_widget_destroy (dialog);
}

// Función Principal
int main (int argc, char *argv[])
{

    // Variables para los objetos
    GtkWidget *window, *button;

    // Inicializa la librería
    gtk_init (&argc, &argv);

    // Crea la ventana con sus características
    window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title (GTK_WINDOW (window), "Clase 42 - FileChooserDialog 3");
    gtk_container_set_border_width (GTK_CONTAINER (window), 10);
    gtk_widget_set_size_request (window, 300, 100);

    // Crea el Botón
    button = gtk_button_new_with_label ("Seleccionar Archivos ...");

    // Conecta la señal del botón a la función CallBack
    g_signal_connect (G_OBJECT (button), "clicked",G_CALLBACK (button_clicked),(gpointer) window);

    // Control de al Salida del Programa
    g_signal_connect(G_OBJECT(window), "destroy",G_CALLBACK(gtk_main_quit), NULL);

    // Agrega el botón a la ventana
    gtk_container_add (GTK_CONTAINER (window), button);

    // Muestra los Widgets
    gtk_widget_show_all (window);

    // Ejecuta el Loop Principal
    gtk_main ();

    // Finaliza la Aplicación con 0
    return 0;

}
