/*

Curso de Programación con Gtk+
Autor:JAOR
Derechos Reservados: JaorSoftware
www.jaorsoftware.com

Clase 23 - Sliders

El Slider es un objeto que en forma gráfica permite mostrar
el avance o retroceso de un proceso, y muestra un valor en
el cual se distingue el avance del mismo.

La función para crear el Slider es la siguiente:
gtk_hscale_new_with_range (inicial,final,intervalo);
gtk_vscale_new_with_range (inicial,final,intervalo);

La primera para crear el slider Horizontal y el
segundo para crear el Slider Vertical

Al crear el Slider, se debe indicar el valor inicial, el valor
final y el valor en que se desplazará el slider.


*/

#include <gtk/gtk.h>
void SbSliderValorCambio(GtkRange *range, gpointer label) {

   // Obtiene el valor del Slider
   gdouble val = gtk_range_get_value(range);

   // Declara una variable de cadena a la cual le asigna el valor
   gchar *str = g_strdup_printf("%.f", val);

   // Establece la cadena en el label
   gtk_label_set_text(GTK_LABEL(label), str);

   // Libera la variable de cadena
   g_free(str);
}


// Función principal
int main_24(int argc, char *argv[])
{

  // Declaración de Variables para los objetos
  GtkWidget *window;  // Variable para la Ventana
  GtkWidget *hscale;  // Variable para el Slider
  GtkWidget *label;   // Variable para la etiqueta
  GtkWidget *table;   // Variable para la tabla


  // Inicializa la Librería
  gtk_init(&argc, &argv);

  // Crea la Ventana Principal
  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);

  // Centra la Ventana
  gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);

  // Establece el tamaño por default
  gtk_window_set_default_size(GTK_WINDOW(window), 300, 250);

  // Establece el borde de la ventana
  gtk_container_set_border_width(GTK_CONTAINER(window), 10);

  // Coloca el Título de la Clase
  gtk_window_set_title(GTK_WINDOW(window), "Clase 24 - Range");

  // Crea una tabla de 1 renglon x 2 columnas
  table = gtk_table_new(1, 2, TRUE);

  // Establece los espacios entre la columnas y renglones de la tabla
  gtk_table_set_row_spacings(GTK_TABLE(table), 10);
  gtk_table_set_col_spacings(GTK_TABLE(table), 10);

  // Agrega la tabla a la Ventana Principal
  gtk_container_add(GTK_CONTAINER(window), table);

  // Crea el Slider
  hscale = gtk_hscale_new_with_range(0, 100, 1);
  gtk_scale_set_draw_value(GTK_SCALE(hscale), FALSE);

  // Crea la Etiqueta que controlará el despliegue del valor
  label = gtk_label_new("0");

  // Agregamos el Range y el Label a la tabla
  gtk_table_attach_defaults(GTK_TABLE(table), hscale, 0, 1, 0, 1);
  gtk_table_attach_defaults(GTK_TABLE(table), label, 1, 2, 0, 1);

  // Establece la función destroy para el cierre de la ventana
  g_signal_connect(window, "destroy",G_CALLBACK(gtk_main_quit), NULL);

  // Establece la función que controla el evento de cambio de valor
  g_signal_connect(hscale, "value-changed", G_CALLBACK(SbSliderValorCambio), label);

  // Muestra todos los objetos de la ventana
  gtk_widget_show_all(window);

  // Establece la función principal
  gtk_main();

  // Retorna 0 para finalizar
  return 0;

}
