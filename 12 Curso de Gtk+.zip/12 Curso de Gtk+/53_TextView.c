/*

Autor    : JAOR
Curso    : Library Gtk+
Clase 53 : TextView

Con esta clase iniciamos el análisis y aprendizaje de otro
control muy importante y que es el GtkTextView.

El TextView es un objeto que nos permite entrada de texto
como en un editor tradicional.

*/

// Incluimos la librería
#include <gtk/gtk.h>

// Función Principal
int main (int argc,char *argv[])
{

   // Definición de Variables
   GtkWidget *window,
             *scrolled_win,
             *textview;

   // Variable para el Buffer de Texto
   GtkTextBuffer *buffer;

   // Inicializa la librería
   gtk_init (&argc, &argv);

   // Crea y Configura la Ventana
   window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
   gtk_window_set_title (GTK_WINDOW (window), "Clase 53 - GtkTextView");
   gtk_container_set_border_width (GTK_CONTAINER (window), 10);
   gtk_widget_set_size_request (window, 250, 150);

   // Crea el objeto TextView
   textview = gtk_text_view_new ();

   // Crea el objeto para el buffer del TextView
   buffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (textview));

   // Coloca texto en el buffer
   gtk_text_buffer_set_text (buffer, "Texto insertado en el GtkTextView ...", -1);

   // Crea el Scroll
   scrolled_win = gtk_scrolled_window_new (NULL, NULL);

   // Añade el TextView al Scroll y el Scroll a la Ventana
   gtk_container_add (GTK_CONTAINER (scrolled_win), textview);
   gtk_container_add (GTK_CONTAINER (window), scrolled_win);

   // Muestra todos los objetos de la Ventana
   gtk_widget_show_all (window);

   // Ejecuta el Ciclo Principal
   gtk_main();

   // Finaliza y Retorna 0
   return 0;
}
