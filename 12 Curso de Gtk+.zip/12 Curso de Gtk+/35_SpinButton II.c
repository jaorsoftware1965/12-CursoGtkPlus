/*

Autor:JAOR
Derechos Reservados: JaorSoftware
http://jaorsoftware.cu.cc/

Curso de Librería Gtk+
Clase 35 - SpinButton II

En esta clase veremos como controlar con una función CallBack
el cambio de valores de un SpinButton.

La Señales que veremos son "change-value" la cual se activa al
momento previo a que el valor va a cambiar y "value-changed"
se activa cuando el valor ya cambió.

Tambien veremos la función gtk_spin_button_set_value, la cual
nos permite colocar un valor específico y tambien gtk_spin_button_get_value
que es la que nos permite obtener el valor.

*/

// Incluímos la Librería
#include <gtk/gtk.h>

// Funcion para Controlar el Cambio del SpinButton
void SbControlSpinButton(GtkWidget *widget)
{

    // Variable para obtener el valor
    gdouble valor;

    // Obtengo el Valor
    valor = gtk_spin_button_get_value(widget);

    // Despliega Mensaje
    g_printf("El Valor del SpinButton ha cambiado %f \n",valor);

    // Verificamos que sea 1 para cambiarlo
    if (valor==1)
    {
       // Despliega Mensaje
       g_printf("Modificamos el Valor \n",valor);

       // Colocamos un Valor
       gtk_spin_button_set_value(widget,7);

    }

}

// Función Principal
int main_35(int argc, char *argv[])
{
    // Definición de Variables
    GtkWidget *window,
              *spin_int,
              *spin_float,
              *vbox;

    // Variables para Valores
    GtkAdjustment *integer, *float_pt;

    // Iniciamos la Librería
    gtk_init (&argc, &argv);

    // Crea la Ventana Principal
    window = gtk_window_new (GTK_WINDOW_TOPLEVEL);

    // Coloca el Título de la Ventana
    gtk_window_set_title (GTK_WINDOW (window), "Clase 35 - Spin Buttons II");

    // Establece el Borde de la Ventana
    gtk_container_set_border_width (GTK_CONTAINER (window), 10);

    // Establece el tamaño de la Ventana
    gtk_widget_set_size_request (window, 250, 100);

    // Crea 2 adjustments.
    // El Primero entre 0 y 10 iniciando en el 5 y con incrementos de 1; y
    // de 2 utilizando el Page del Teclado
    // El Segundo definido entre 0 and 1, iniciando en 0.5 y con
    // incrementos de 0.1. a través del teclado
    integer = GTK_ADJUSTMENT (gtk_adjustment_new  (5.0, 0.0, 12.0, 1.0, 3.0, 2.0));
    float_pt = GTK_ADJUSTMENT (gtk_adjustment_new (0.5, 0.0, 2.0, 0.1, 0.5, 0.3));

    /* Creamos los SpinButton con los adjustement*/
    //                               inicio, fin, intervalo
    spin_int = gtk_spin_button_new(integer, 1.0, 2);

    // Podemos utilizar esta función y establecer el rango
    spin_float = gtk_spin_button_new (float_pt, 0.1, 1);

    // Creamos el Contenedor
    vbox = gtk_vbox_new (FALSE, 5);

    // Agregamos los objetos al Contenedor
    gtk_box_pack_start(GTK_BOX (vbox), spin_int,FALSE,FALSE,1);
    gtk_box_pack_start(GTK_BOX (vbox), spin_float,FALSE,FALSE,1);

    // Agregamos el Contenedor a la Ventana Principal
    gtk_container_add (GTK_CONTAINER (window), vbox);

     // Asocia el evento destroy de la ventana principal */
    g_signal_connect( G_OBJECT( window ), "destroy", G_CALLBACK( gtk_main_quit ), NULL );


    // Asociamos la función al evento click, pasando la ventana como parámetro
    //g_signal_connect(spin_int, "change-value",G_CALLBACK(SbControlSpinButton), NULL);

    // Asociamos la función al evento click, pasando la ventana como parámetro
    g_signal_connect(spin_int, "value-changed",G_CALLBACK(SbControlSpinButton), NULL);

    // Mostramos todos los objetos
    gtk_widget_show_all (window);

    // Iniciamos el Ciclo Principal
    gtk_main ();

    // Finalizamos Retornando 0
    return 0;

}

