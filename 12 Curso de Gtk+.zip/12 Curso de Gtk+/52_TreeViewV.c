/*

Autor    : JAOR
Curso    : Library Gtk+
Clase 52 : TreeView V

En esta clase veremos como establecer los colores
a las celdas de un TreeView y también como establecer
que una función específica controle los cambios de
las celdas de una columna del TreeView.

*/

// Incluimos la librería
#include <gtk/gtk.h>

// Constantes para las Columnas
enum
{
   COLOR = 0, // Columna del Color (Única)
   COLUMNS    // Columnas del TreeView
};

// Constante para los Valores de los Colores
const gchar *clr[6] = { "00", "33", "66", "99", "CC", "FF" };

// Función para controlar cambio celda
static void SbCellDataChange(GtkTreeViewColumn *column,
                            GtkCellRenderer *renderer,
                            GtkTreeModel *model,
                            GtkTreeIter *iter,
                            gpointer data)
{
   // Variable para obtener el Texto
   gchar *text;

   // Obtiene el Color de acuerdo a la Cadena del contenido de la Celda
   gtk_tree_model_get (model, iter, COLOR, &text, -1);

   // Establece el Color como Fondo de la Celda
   g_object_set (renderer, "foreground"    , "#FFFFFF",
                           "foreground-set", TRUE,
                           "background"    , text,
                           "background-set", TRUE,
                           "text"          , text,
                           NULL);

   // Desplegamos el Valor del Texto que es el Color
   g_print("%s-",text);

   // Libera el Texto objenido
   g_free (text);

}

// Función para Inicializar el TreeView
static void FnTreeViewInicializa(GtkWidget *treeview)
{
   // Variables para la Celda y la Columna
   GtkCellRenderer *renderer;
   GtkTreeViewColumn *column;

   // Crea la Celda y la Columna
   renderer = gtk_cell_renderer_text_new ();
   column = gtk_tree_view_column_new_with_attributes("Colores", renderer, "text", COLOR, NULL);

   // Agrega la Columna al TreeView
   gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);

   // Establece la función que controlará los cambios en la celda
   gtk_tree_view_column_set_cell_data_func (column, renderer,SbCellDataChange, NULL, NULL);
}


// Función Principal
int main (int argc,char *argv[])
{

   // Declaración de Variables
   GtkWidget *window,       // Ventana Principal
             *treeview,     // TreeView
             *scrolled_win; // Scroll

   GtkListStore *store;     // Modelo de Datos
   GtkTreeIter iter;        // Item
   guint i, j, k;           // Contadores

   // Inicializa la librería
   gtk_init (&argc, &argv);

   // Da formato a la Ventana Principal
   window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
   gtk_window_set_title (GTK_WINDOW (window), "Clase 52 - TreeView V");
   gtk_container_set_border_width (GTK_CONTAINER (window), 10);
   gtk_widget_set_size_request (window, 250, 175);

   // Crea e Inicializa el TreeView
   treeview = gtk_tree_view_new ();
   FnTreeViewInicializa(treeview);

   // Modelo para los datos
   store = gtk_list_store_new (COLUMNS, G_TYPE_STRING);

   // Ciclo para construir la Cadena que indica el Color
   for (i = 0; i < 6; i++)
       for (j = 0; j < 6; j++)
             for (k = 0; k < 6; k++)
             {
                 // Crea la cadena del Color
                 gchar *color = g_strconcat ("#", clr[i], clr[j], clr[k], NULL);

                 // Añade la Celda
                 gtk_list_store_append (store, &iter);

                 // Coloca los datos y establece el texto que contiene el Color
                 gtk_list_store_set (store, &iter, COLOR, color, -1);

                 // Libera la Variable del Color
                 g_free (color);
             }

    // Establecemos el Modelo e Indicamos la liberación con el TreeView de los datos
    gtk_tree_view_set_model (GTK_TREE_VIEW (treeview), GTK_TREE_MODEL (store));
    g_object_unref (store);

    // Establecemos el Objeto del Scroll y sus características
    scrolled_win = gtk_scrolled_window_new (NULL, NULL);
    gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolled_win),
                                    GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);

    // Añade el TreeView al Scroll y el Scroll a la ventana principal
    gtk_container_add (GTK_CONTAINER (scrolled_win), treeview);
    gtk_container_add (GTK_CONTAINER (window), scrolled_win);

    // Mostramos todos los objetos
    gtk_widget_show_all (window);

    // Ejecutamos el Ciclo Principal y Finalizamos con 0
    gtk_main ();
    return 0;

}
