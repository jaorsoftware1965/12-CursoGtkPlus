/*

Autor    : JAOR
Company  : JaorSoftware
Curso    : Library Gtk+
Clase 50 : TreeView III


En esta clase veremos como actualizar información y como
eliminar un elemento de un TreeView.

*/

// Incluye la librería
#include <gtk/gtk.h>

enum {
  COLUMNA_NUM = 0,
  COLUMNA_MAX = 1
};


// Función para Cuando cambia la Selección
void FnTreeViewEliminar(GtkButton *button,GtkWidget *widget)
{

  // Declaración de Variables
  GtkTreeIter iter;    // Item
  GtkTreeModel *model; // Modelo de Datos

  // Verifica que esté seleccionado un Elemento
  if (gtk_tree_selection_get_selected(GTK_TREE_SELECTION(widget), &model, &iter))
  {

    // Función para Eliminar un Elemento
    gtk_tree_store_remove (GTK_TREE_STORE(model),&iter);

  }


}

// Función para Actualizar
void FnTreeViewActualizar(GtkButton *button,GtkWidget *widget)
{

  // Declaración de Variables
  GtkTreeIter iter;    // Item
  GtkTreeModel *model; // Modelo de Datos

  // Verifica que esté seleccionado un Elemento
  if (gtk_tree_selection_get_selected(GTK_TREE_SELECTION(widget), &model, &iter))
  {

    // Función para Modificar un Elemento
    gtk_tree_store_set (GTK_TREE_STORE (model), &iter, 0, "Modificado", -1);

  }

}


// Función que crea el TreeView
GtkTreeModel *FnCreateTreeView(void)
{

  // Variables
  GtkTreeStore *treestore;     // Para colocar los datos
  GtkTreeIter toplevel, child; // Para items

  // Crea un nuevo elemento
  treestore = gtk_tree_store_new(COLUMNA_MAX,G_TYPE_STRING);

  // Agrega un elemento vacío
  gtk_tree_store_append(treestore, &toplevel, NULL);

  // Coloca el Dato en el elemento
  gtk_tree_store_set(treestore, &toplevel,COLUMNA_NUM, "Web",-1);

  // Añade el un hijo al toplevel
  gtk_tree_store_append(treestore, &child, &toplevel);

  // Establece el Valor del Child
  gtk_tree_store_set(treestore, &child,COLUMNA_NUM, "Python",-1);

  // Agrega como hijo del toplevel
  gtk_tree_store_append(treestore, &child, &toplevel);
  // Establece otro valor y lo agrega
  gtk_tree_store_set(treestore, &child,COLUMNA_NUM, "Perl",-1);

  // Agrega otro elemento
  gtk_tree_store_append(treestore, &child, &toplevel);
  // Establece otro valor
  gtk_tree_store_set(treestore, &child,COLUMNA_NUM, "PHP",-1);

  // Lo Agrega
  gtk_tree_store_append(treestore, &toplevel, NULL);

  // Establece otro primer nivel y lo añade
  gtk_tree_store_set(treestore, &toplevel,COLUMNA_NUM, "Desktop",-1);

  // Establece otro valor y lo agrega
  gtk_tree_store_append(treestore, &child, &toplevel);

  // Agrega un Hijo
  gtk_tree_store_set(treestore, &child,COLUMNA_NUM, "C",-1);

  // Establece otro valor y lo agrega
  gtk_tree_store_append(treestore, &child, &toplevel);
  gtk_tree_store_set(treestore, &child,COLUMNA_NUM, "C++",-1);

  // Establece otro valor y lo agrega
  gtk_tree_store_append(treestore, &child, &toplevel);
  gtk_tree_store_set(treestore, &child,COLUMNA_NUM, "Java",-1);


  // Retorna el TreeView
  return GTK_TREE_MODEL(treestore);

}


// Función para crear la Vista y el Modelo
GtkWidget *FnCreaVistaModelo(void)
{

  // Declara las variables a utilizar
  GtkTreeViewColumn *col;    // Variable para Columna
  GtkCellRenderer *renderer; // Variable para Celda
  GtkWidget *view;           // Variable para la Vista
  GtkTreeModel *model;       // Variable para el Modelo

  // Crea el treeview
  view = gtk_tree_view_new();

  // Crea la Columna
  col = gtk_tree_view_column_new();

  // Establece el Nombre de la Columna y la Agrega al TreeView
  gtk_tree_view_column_set_title(col, "Lenguajes de Programación");
  gtk_tree_view_append_column(GTK_TREE_VIEW(view), col);

  // Crea la Celda
  renderer = gtk_cell_renderer_text_new();

  // Establece la Columna y su atributo
  gtk_tree_view_column_pack_start(col, renderer, TRUE);
  gtk_tree_view_column_add_attribute(col, renderer,"text", COLUMNA_NUM);

  // Crea el TreeView
  model = FnCreateTreeView();

  // Establece el Modelo en el treeview
  gtk_tree_view_set_model(GTK_TREE_VIEW(view), model);

  // Indica que se destruya con el Modelo
  g_object_unref(model);

  // Retorna el Control
  return view;

}


// Función Principal
int main(int argc, char *argv[])
{

  // Declaración de Variables
  GtkWidget *window;            // Ventana Principal
  GtkWidget *view;              // Para el treeview
  GtkTreeSelection *selection;  // Para controlar el treeview
  GtkWidget *vbox;              // El Contenedor
  GtkWidget *btnEliminar;       // Para el Botón de Eliminar
  GtkWidget *btnActualizar;     // Para el Botón de Actualizar


  // Inicializa la Librería
  gtk_init(&argc, &argv);

  // Configura la Ventana Principal
  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);
  gtk_window_set_title(GTK_WINDOW(window), "Clase 50 - TreeView III");
  gtk_widget_set_size_request(window, 350, 300);

  // Crea el Contenedor y lo agrega a la Ventana Principal
  vbox = gtk_vbox_new(FALSE, 2);
  gtk_container_add(GTK_CONTAINER(window), vbox);

  // Crea la Vista y Modelo
  view = FnCreaVistaModelo();

  // Obtine el Control sobre la Selección del TreeView
  selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(view));

  // Coloca los elementos en el contenedor
  gtk_box_pack_start(GTK_BOX(vbox), view, TRUE, TRUE, 1);

  // Crea lo botones y los agrega al contenedor
  btnEliminar = gtk_button_new_with_label ("Eliminar");
  gtk_box_pack_start(GTK_BOX(vbox), btnEliminar, FALSE, TRUE, 1);
  btnActualizar = gtk_button_new_with_label ("Actualizar");
  gtk_box_pack_start(GTK_BOX(vbox), btnActualizar, FALSE, TRUE, 1);

  // Captura la Señal de Click de los Botones
  g_signal_connect(btnEliminar, "clicked",G_CALLBACK(FnTreeViewEliminar), selection);
  g_signal_connect(btnActualizar, "clicked",G_CALLBACK(FnTreeViewActualizar), selection);

  // Captura la Señal de destrucción de la Ventana Principal
  g_signal_connect (G_OBJECT (window), "destroy",G_CALLBACK(gtk_main_quit), NULL);

  // Muestra todos los Widgets
  gtk_widget_show_all(window);

  // Ejecuta el Ciclo Principal
  gtk_main();

  // Finaliza Retornando 0
  return 0;

}
