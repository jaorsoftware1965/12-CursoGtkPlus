/*
Curso de Programación con Gtk+
Autor:JAOR
Derechos Reservados: JaorSoftware
www.jaorsoftware.com
www.jaorsoftware.cc.cu

Clase 06_Controlando_Ventana_III

A continuación seguiremos analizando funciones que tienen que
ver con el control de la Ventana.

// Estableciendo el tamaño mínimo de la Ventana
void gtk_widget_set_size_request (GtkWidget *widget,gint width,gint height);
Esta función establece un tamaño mínimo de la ventana, para que en
caso de que el usuario pretenda cambiar su tamaño, este no pueda ser menor
que el establecido

// Estableciendo que la Ventana no pueda ser dimensionable
void gtk_window_set_resizable(GtkWindow *window, gboolean resizable);
Esta función nos permite indicar que el usuario no pueda modificar el tamaño
de la Ventana o que si pueda modificar el tamao.
Cuando se establece; la ventana toma el tamaño mínimo indicado.

// Función para mover una ventana
void gtk_window_move(GtkWindow *window,gint x,gint y);
Esta función mueve una ventana a un lugar específico de la pantalla

// Función para ocultar la ventana
void gtk_widget_hide(GtkWidget *window);
Esta función oculta la ventana


// Función para destruir un Widget
void gtk_widget_destroy (GtkWidget *widget);
Esta función destruye directamente un Widget

// Función para obtener un icono desde el archivo
gboolean gtk_window_set_icon_from_file (GtkWindow *window,const gchar *filename,GError **err);
Esta función carga un icono para cuando la aplicación aparece en la barra
de Tareas. Es un método alterno al ya visto.

*/
// Se incluye la librería
#include <gtk/gtk.h>

// Funcion para controlar la Señal de Destrucción
static void SbMainExit(GtkWidget *window, gpointer data)
{
    // Mensaje de que la ventana se ha destruido
    printf("Destroy Signal \n");

    // Llama a la función de la Librería que sale del Ciclo Main
    gtk_main_quit ();
}

// Función para controlar el Cierre de una Ventana
static gboolean FngBoolDeleteEvent(GtkWidget *window, GdkEvent *event)
{
    // Mensaje
    printf("Delete Event\n");

    // Valor de Retorno
    return FALSE;
}

// Función Principal
int main( int argc, char *argv[])
{

  // Objeto para el Widget
  GtkWidget *window;

  // Inicializa la Librería
  gtk_init (&argc, &argv);

  // Crea el Widget con el Objeto declarado
  window = gtk_window_new (GTK_WINDOW_TOPLEVEL);

  // Coloca el Título
  gtk_window_set_title (GTK_WINDOW (window), "06_Controlando la Ventana III----");

  // Controla la Señal de Destrucción del Objeto
  g_signal_connect(G_OBJECT(window), "destroy",G_CALLBACK(SbMainExit), NULL);

  // Controla la Señal del evento "delete_event" de la Ventana-Widget
  g_signal_connect (G_OBJECT (window), "delete_event", G_CALLBACK (FngBoolDeleteEvent), NULL);

  // Establece el Tamaño Mínimo de la Ventana
  gtk_widget_set_size_request(window,400,400);

  // Maximizamos la Ventana
  gtk_window_maximize(GTK_WINDOW(window));

  // Evitamos que sea redimensionable
  gtk_window_set_resizable(GTK_WINDOW(window),FALSE);



  // Maximizamos la Ventana
  gtk_window_maximize(GTK_WINDOW(window));

  // Ubicamos la Ventana
  gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);


  // Muestra la Ventana
  gtk_widget_show(window);

  // Movemos a la esquina Superior
  gtk_window_move (GTK_WINDOW(window),0,0);

  // La Oculta
  gtk_widget_hide(window);

  // Muestra la Ventana
  gtk_widget_show(window);


  GError *myError;
  gtk_window_set_icon_from_file(GTK_WINDOW(window),"js92.jpg",&myError);

  // Ejecuta el Ciclo Principal de la Aplicación
  gtk_main ();

  // Destruyendo el Widget directamente
  //gtk_widget_destroy(window);

  // Finaliza la Aplicación
  return 0;

}

