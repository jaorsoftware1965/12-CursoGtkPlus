/*
---------------------------------
Curso de Programación con Gtk+
Clase 01_Primer Programa
Derechos Reservados JaorSoftware
www.jaorsoftware.com
www.jaorsoftware.cc.cu
---------------------------------

Antes de realizar nuestro primer programa, deberemos de entender
algunos conceptos fundamentales al respecto.

WIDGET.
La palabra widget proviene de una contracción de la lengua inglesa:
“Window Gadget 6”, que se utiliza para referir a los diferentes elementos
de una Interfaz Gráfica de Usuario (GUI).

Un widget de GTK+ es un componente de interfaz gráfica de usuario; es un
objeto.

Ejemplos de widgets son las ventanas, casillas de verificación, botones y
campos editables.

Los widgets (no importando de que tipo sean), siempre se definen como
punteros a una estructura GtkWidget.

Esta estructura es un tipo de dato genérico utilizado por todos los widgets
y ventanas en GTK+.

La librería GTK+ sigue un modelo de programación orientada a objetos(POO).
La jerarquía de objetos comienza en GObject de la librería Glib del que
hereda GtkObject.

Todos los widgets heredan de la clase de objetos GtkWidget, que a su vez
hereda directamente de GtkObject.

GRAFICAMENTE

 ----------
| GObject  |
 ----------
      |
 ------------------
| GInitiallyUnowned |
 ------------------
      |
 -----------
| GtkObject |
 -----------
      |
 -----------
| GtkWidget |
 -----------
      |
 --------------
| GtkContainer |
 --------------
      |
 --------
| GtkBin |
 --------
      |
 -----------
| GtkWindow |
 -----------

La clase GtkWidget contiene las propiedades comunes a todos los widgets;
y cada widget particular le añade sus propias propiedades.

Para realizar nuestra primera aplicación haremos uso de los siguientes
tipos de datos y funciones:

GtkWidget.
Es la clase correspondiente para poder crear los Widgets.

void gtk_init (int *argc,char ***argv);
Es la función con la cual activaremos la Librería

GtkWidget * gtk_widget_new (GType type,const gchar *first_property_name,...);
Función para crear un Widget y establecer sus propiedades al momento de su creación

void gtk_widget_show (GtkWidget *widget);
Muestra la Ventana-Widget

void gtk_window_set_title (GtkWindow *window,const gchar *title);
Establece el Título de la Ventana

void gtk_main (void);
Ejecuta un ciclo principal para la aplicación, hasta que se ejecute
gtk_main_quit.


Instrucción para Compilar desde la Terminal
gcc -o 01_Primer_Programa 01_Primer_Programa.c `pkg-config --libs --cflags gtk+-2.0`

*/
#include <gtk/gtk.h>

int main_01(int argc, char *argv[])
{
  // Definimos una variable de Tipo GtkWidget
  GtkWidget *window;

  // Iniciamos la Libreria Gtk
  gtk_init(&argc, &argv);

  // Creamos una ventana utilizando la Variable del Tipo GtkWidget
  // Llamando a la función gtk_window_new
  // El Tamaño default es 200 x 200
  // Solo toma otro parámetro: GTK_WINDOW_POPUP
  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);

  // Mostramos la Ventana con la función gtk_widget_show
  gtk_widget_show(window);

  // Coloca el Título de la Ventana
  gtk_window_set_title(GTK_WINDOW (window), "01_Primer Aplicación");


  // Coloca a la Ventana en un ciclo en donde intercepta eventos
  gtk_main();


  return 0;
}
