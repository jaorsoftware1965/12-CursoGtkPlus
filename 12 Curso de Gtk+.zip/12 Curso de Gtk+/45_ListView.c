/*

Autor    : JAOR
Company  : JaorSoftware
Curso    : Library Gtk+

En esta clase iniciaremos el aprendizaje del GtkTreeView
widget.

Este control nos permite desplegar elementos ya conocidos
en otros lenguajes de programación como lo son las listas
y los treeview.

En esta primer clase veremos como generar el uso mas simple
de GtkTreeView y que es el conocido elemento ListView.

*/

// Incluimos la librería
#include <gtk/gtk.h>

// Función para iniciar la Lista
void SbListaInicializa(GtkWidget *list)
{

  // Elementos necesarios
  GtkCellRenderer   *renderer;
  GtkTreeViewColumn *column;
  GtkListStore      *store;

  // Creamos un elemento celda
  renderer = gtk_cell_renderer_text_new ();

  // Creamos un elemento columna utilizando la celda creada
  column = gtk_tree_view_column_new_with_attributes("LENGUAJES", // Texto Columna
                                                       renderer, // Celda
                                                         "text", // Tipo de Celda
                                                              0, // Columna
                                                          NULL); // Indicar Fin de Atributo

  // Añadimos la Columna al Elemento
  gtk_tree_view_append_column(GTK_TREE_VIEW(list), column);

  // Creamos el Modelo con una Columna
  store = gtk_list_store_new(1, G_TYPE_STRING);

  // Establecemos el Modelo en la Lista
  gtk_tree_view_set_model(GTK_TREE_VIEW(list),GTK_TREE_MODEL(store));

  // Indicamos que el Modelo sea eliminado con la Vista
  g_object_unref(store);

}


// Función para Agregar un Elemento a la Lista
void SbListaInserta(GtkWidget *list, const gchar *str)
{

  // Variables necesarias
  GtkListStore *store;  // Modelo
  GtkTreeIter iter;     // Item

  // Obtiene el Modelo
  store = GTK_LIST_STORE(gtk_tree_view_get_model(GTK_TREE_VIEW(list)));

  // Añade un elemento vació a la lista utilizando el Modelo
  gtk_list_store_append(store, // Modelo
                        &iter);// Item

  // Establece el dato en la lista
  gtk_list_store_set(store, // Modelo
                     &iter, // Item
                         0, // Columna
                       str, // Texto
                        -1);// Indicar finalización

}


// Función para obtener el Elemento de la Lista Seleccionado
void SbListaCambia(GtkWidget *widget, gpointer label)
{

  // Variables a utilizar
  GtkTreeIter  iter;     // Item de la lista
  GtkTreeModel *model;  // Modelo
  gchar *value;         // Contenido del Elemento

  // Verifica que esté seleccionado
  if (gtk_tree_selection_get_selected(GTK_TREE_SELECTION(widget), &model, &iter))
  {
      // Obtiene el Valor del Item
      gtk_tree_model_get(model, &iter, 0, &value,  -1);

      // Establece el Valor obtenido en la Etiqueta
      gtk_label_set_text(GTK_LABEL(label), value);

      // Libera la Memoria
      g_free(value);
  }
}


// Función Principal
int main(int argc, char *argv[])
{

  // Variables de la Aplicación
  GtkWidget *window;   // Ventana
  GtkWidget *list;     // Lista

  GtkWidget *vbox;     // Contenedor
  GtkWidget *label;    // Etiqueta
  GtkTreeSelection *selection;  // Selección

  // Inicializa la librería
  gtk_init(&argc, &argv);

  // Configuramos la Ventana Principal
  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title(GTK_WINDOW(window), "Clase 45 - List view");
  gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);
  gtk_container_set_border_width(GTK_CONTAINER(window), 10);
  gtk_window_set_default_size(GTK_WINDOW(window), 270, 250);

  // Creamos la Lista
  list = gtk_tree_view_new();

  // Establecemos que los encabezados estén ocultos
  gtk_tree_view_set_headers_visible(GTK_TREE_VIEW(list), FALSE);

  // Creamos el Contenedor y agregamos la Lista
  vbox = gtk_vbox_new(FALSE, 0);
  gtk_box_pack_start(GTK_BOX(vbox), list, TRUE, TRUE, 5);

  // Creamos la Etiqueta y la añadimos al COntenedor
  label = gtk_label_new("");
  gtk_box_pack_start(GTK_BOX(vbox), label, FALSE, FALSE, 5);

  // Agregamos el Contenedor a la Ventana
  gtk_container_add(GTK_CONTAINER(window), vbox);

  // Inicializa la Lista
  SbListaInicializa(list);

  // Añadimos Elementos a la Lista
  SbListaInserta(list, "Python");
  SbListaInserta(list, "Ruby");
  SbListaInserta(list, "Basic");
  SbListaInserta(list, "Java");
  SbListaInserta(list, "C");

  // Obtiene la referencia a la Selección de la Lista
  selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(list));

  // Conecta la Lista-Seleccion a la Señal changed
  g_signal_connect(selection, "changed", G_CALLBACK(SbListaCambia), label);

  // Conecta la Señal de destrucción de la Ventana Principal
  g_signal_connect(G_OBJECT (window), "destroy",G_CALLBACK(gtk_main_quit), NULL);

  // Muestra todos los Objetos
  gtk_widget_show_all(window);

  // El Ciclo Principal
  gtk_main();

  // Finaliza Retornando 0
  return 0;

}
