/*

Autor    : JAOR
Curso    : Library Gtk+
Clase 57 : TextView V

En esta clase veremos como establecer formato al texto
dentro del TextView, veremos como usar el ComboBox para
la versión  3.0; y otras cosas interesantes

*/

// Incluimos la librería
#include <gtk/gtk.h>

// Estructura con Información de la Fuente
typedef struct
{
   gchar *strFontDsc;
   double douFontSize;
} SizeInfo;


// Constante para las opciones del Combo
const SizeInfo Fuentes[] =
{
    { "Quarter Sized", (double) 0.25 },
    { "Double Extra Small", PANGO_SCALE_XX_SMALL},
    { "Extra Small", PANGO_SCALE_X_SMALL},
    { "Small", PANGO_SCALE_SMALL },
    { "Medium", PANGO_SCALE_MEDIUM },
    { "Large", PANGO_SCALE_LARGE},
    { "Extra Large", PANGO_SCALE_X_LARGE},
    { "Double Extra Large", PANGO_SCALE_XX_LARGE},
    { "Double Sized", (double) 2.0 },
    { NULL, 0 }
};

// Aplica el Formato al Texto basado en el TAG
static void SbTextoFormatea (GtkWidget *widget,GtkTextView *textview)
{
    // Variables para encontrar el Inicio y Final del Texto Seleccionado
    GtkTextIter start, end;

    // El Buffer del Texto
    GtkTextBuffer *buffer;

    // El Nombre del Tag
    gchar *tagname;

    // Obtiene el nombre del Tag
    tagname = (gchar*) g_object_get_data (G_OBJECT (widget), "tag");
    g_print("tagname:%s\n",tagname);

    // Obtiene el Buffer
    buffer = gtk_text_view_get_buffer (textview);

    // Obtiene el Inicio y el Final
    gtk_text_buffer_get_selection_bounds (buffer, &start, &end);

    // Aplica el Tag al texto
    gtk_text_buffer_apply_tag_by_name (buffer, tagname, &start, &end);

}

// Aplica el tamaño seleccionado en el combo
static void SbEscalaSeleccionada (GtkComboBox *combo,GtkTextView *textview)
{
   // Variable para obtener el texto
   const gchar *text;

   // Verifica que el Combo esté seleccionado
   if (gtk_combo_box_get_active (combo) == -1)
      return;

   // Obtiene el Texto
   text = gtk_combo_box_text_get_active_text (combo);

   // Coloca el dato del Tag
   g_object_set_data (G_OBJECT (combo), "tag", (gpointer) text);

   // Formatea el Texto
   SbTextoFormatea (GTK_WIDGET (combo), textview);

   // Desselecciona el ComboBox
   gtk_combo_box_set_active (combo, -1);

}

/* Remove all of the tags from the selected text. */
static void SbTextoEliminaFormato (GtkButton *button, GtkTextView *textview)
{
   // Declaración de Variables para el Texto Seleccionado
   GtkTextIter start, end;

   // El Buffer del Texto
   GtkTextBuffer *buffer;

   // Obtiene el Buffer
   buffer = gtk_text_view_get_buffer (textview);

   // Obtiene el Texto Seleccionado
   gtk_text_buffer_get_selection_bounds (buffer, &start, &end);

   // Remueve los tags del texto seleccionado
   gtk_text_buffer_remove_all_tags (buffer, &start, &end);

}


// Función Principal
int main (int argc,char *argv[])
{
    // Declaración de Variables
    GtkWidget *window,  // Ventana Principal
        *scrolled_win,  // Scroll
            *textview,  // TextView
                *hbox,  // Contenedores
                *vbox,  // Contenedor
                *bold,  // Boton
              *italic,  // Boton
           *underline,  // Boton
              *strike,  // Boton
               *color,  // Color
               *scale,  // ComboBox
               *clear;  // Botón

    // El Buffer del Texto
    GtkTextBuffer *buffer;

    // Contador
    gint i = 0;

    // Inicializa la librería
    gtk_init (&argc, &argv);

    // Crea y da formato a la Ventana Principal
    window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title (GTK_WINDOW (window), "Clase 57 - TextView V");
    gtk_container_set_border_width (GTK_CONTAINER (window), 10);
    gtk_widget_set_size_request (window, 500, -1);

    // Crea el Teto
    textview = gtk_text_view_new ();

    // Obtiene el Bufer del TextView
    buffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (textview));

    // Crea los tag's para dar formato al Texto
    g_print("%d\n",PANGO_WEIGHT_BOLD);
    g_print("%d\n",PANGO_STYLE_ITALIC);
    g_print("%d\n",PANGO_UNDERLINE_SINGLE);
    gtk_text_buffer_create_tag(buffer, "bold", "weight", PANGO_WEIGHT_BOLD, NULL);
    gtk_text_buffer_create_tag(buffer, "italic", "style", PANGO_STYLE_ITALIC, NULL);
    gtk_text_buffer_create_tag(buffer, "strike", "strikethrough", TRUE, NULL);
    gtk_text_buffer_create_tag(buffer, "underline", "underline",PANGO_UNDERLINE_SINGLE, NULL);
    gtk_text_buffer_create_tag(buffer, "foreground", "foreground","white","background","blue","style", PANGO_STYLE_ITALIC,NULL);


    // Crea los Botones
    bold = gtk_button_new_from_stock (GTK_STOCK_BOLD);
    italic = gtk_button_new_from_stock (GTK_STOCK_ITALIC);
    underline = gtk_button_new_from_stock (GTK_STOCK_UNDERLINE);
    strike = gtk_button_new_from_stock (GTK_STOCK_STRIKETHROUGH);
    clear = gtk_button_new_from_stock (GTK_STOCK_CLEAR);
    color = gtk_button_new_with_label ("Azul");

    // Crea el Combo para la Escala de la Fuente
    scale = gtk_combo_box_text_new();

    // Añade las Escalas al ComboBox
    for (i = 0; Fuentes[i].strFontDsc != NULL; i++)
    {
        // Añade la opción al Combo
        gtk_combo_box_text_append (GTK_COMBO_BOX (scale),NULL, Fuentes[i].strFontDsc);
        gtk_text_buffer_create_tag (buffer, Fuentes[i].strFontDsc, "scale",Fuentes[i].douFontSize, NULL );
    }

    // Añade el nombre del tag como parametro del objeto
    g_object_set_data (G_OBJECT(bold), "tag", "bold");
    g_object_set_data (G_OBJECT(italic), "tag", "italic");
    g_object_set_data (G_OBJECT(underline), "tag", "underline");
    g_object_set_data (G_OBJECT(strike), "tag", "strike");
    g_object_set_data (G_OBJECT(color), "tag", "foreground");

    // Conecta las Señales de los Botones y el ComboBox
    g_signal_connect (G_OBJECT (bold), "clicked",G_CALLBACK (SbTextoFormatea), (gpointer) textview);
    g_signal_connect (G_OBJECT (italic), "clicked",G_CALLBACK (SbTextoFormatea), (gpointer) textview);
    g_signal_connect (G_OBJECT (underline), "clicked",G_CALLBACK (SbTextoFormatea), (gpointer) textview);
    g_signal_connect (G_OBJECT (strike), "clicked",G_CALLBACK (SbTextoFormatea), (gpointer) textview);
    g_signal_connect (G_OBJECT (color), "clicked",G_CALLBACK (SbTextoFormatea), (gpointer) textview);
    g_signal_connect (G_OBJECT (scale), "changed",G_CALLBACK (SbEscalaSeleccionada),(gpointer) textview);
    g_signal_connect (G_OBJECT (clear), "clicked",G_CALLBACK (SbTextoEliminaFormato),(gpointer) textview);

    // Crea el Contenedor Vertical y agrega los botones y el combobox
    vbox = gtk_vbox_new (TRUE, 5);
    gtk_box_pack_start (GTK_BOX (vbox),bold, FALSE, FALSE, 0);
    gtk_box_pack_start (GTK_BOX (vbox),italic, FALSE, FALSE, 0);
    gtk_box_pack_start (GTK_BOX (vbox),underline, FALSE, FALSE, 0);
    gtk_box_pack_start (GTK_BOX (vbox),strike, FALSE, FALSE, 0);
    gtk_box_pack_start (GTK_BOX (vbox),color, FALSE, FALSE, 0);
    gtk_box_pack_start (GTK_BOX (vbox),scale, FALSE, FALSE, 0);
    gtk_box_pack_start (GTK_BOX (vbox),clear, FALSE, FALSE, 0);

    // Crea el Scroll para el Texto y lo configura
    scrolled_win = gtk_scrolled_window_new (NULL, NULL);
    gtk_container_add (GTK_CONTAINER (scrolled_win), textview);
    gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolled_win),GTK_POLICY_AUTOMATIC, GTK_POLICY_ALWAYS);

    // Crea el Contenedor Horizontal y agrega el Scroll
    hbox = gtk_hbox_new (FALSE, 5);
    gtk_box_pack_start (GTK_BOX (hbox), scrolled_win, TRUE, TRUE, 0);

    // Agrega el Contenedor Vertical al Horizontal
    gtk_box_pack_start (GTK_BOX (hbox), vbox, FALSE, TRUE, 0);

    // Agrega el Contenedor Horizontal a la Ventana Principal
    gtk_container_add (GTK_CONTAINER (window), hbox);

    // Muestra todos los objetos e inicializa el Ciclo Principal
    gtk_widget_show_all (window);
    gtk_main();

    // Finaliza Retornando 0
    return 0;
}

