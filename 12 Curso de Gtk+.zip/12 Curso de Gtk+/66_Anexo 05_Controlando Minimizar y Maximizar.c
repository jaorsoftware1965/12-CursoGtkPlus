/*
Curso de Programación con Gtk+
Autor:JAOR

Clase 66 Anexo 05 Controlando Minimizar y Maximizar

*/
// Se incluye la librería
#include <gtk/gtk.h>

// Funcion para controlar la Señal de Destrucción
static void SbMainExit(GtkWidget *window, gpointer data)
{
    // Mensaje de que la ventana se ha destruido
    printf("Destroy Signal \n");

    // Llama a la función de la Librería que sale del Ciclo Main
    gtk_main_quit ();
}

// Función para controlar el Cierre de una Ventana
static gboolean FngBoolDeleteEvent(GtkWidget *window, GdkEvent *event)
{
    // Mensaje
    printf("Delete Event\n");

    // Valor de Retorno
    return FALSE;
}


//gboolean callback_func(GtkWidget *widget,GdkEventWindowState *event,gpointer user_data)
// Funcion para controlar Minimizar y Maximizar
static gboolean FnBoolControlMaxMin(GtkWidget *window,GdkEventWindowState *event,gpointer user_data)
{

    g_print("Window State: %d \n",event->new_window_state);
    //Minimized window check
    if (event->new_window_state & GDK_WINDOW_STATE_ICONIFIED)
    {
       // No trabaja en este momento
       gtk_window_deiconify (window);
       g_print("Minimizar \n");
       return TRUE;
    }
    else if (event->new_window_state & GDK_WINDOW_STATE_MAXIMIZED)
         {
            gtk_window_unmaximize (window);
            g_print("Maximizar \n");
            return TRUE;
         }
}

// Función Principal
int main( int argc, char *argv[])
{

  // Objeto para el Widget
  GtkWidget *window;

  // Inicializa la Librería
  gtk_init (&argc, &argv);

  // Crea el Widget con el Objeto declarado
  window = gtk_window_new (GTK_WINDOW_TOPLEVEL);

  // Coloca el Título
  gtk_window_set_title (GTK_WINDOW (window), "66_Anexo 05_Controlando Maximizar y Minimizar");

  // Establece el Tamaño Mínimo de la Ventana
  gtk_widget_set_size_request(window,400,400);

  gtk_window_iconify(window);
  //gtk_window_deiconify (window);

  // Maximizamos la Ventana
  gtk_window_maximize(GTK_WINDOW(window));

  // Muestra la Ventana
  gtk_widget_show(window);

  // Controla la Señal de Destrucción del Objeto
  g_signal_connect(G_OBJECT(window), "destroy",G_CALLBACK(SbMainExit), NULL);

  // Controla la Señal del evento "delete_event" de la Ventana-Widget
  g_signal_connect (G_OBJECT (window), "delete_event", G_CALLBACK (FngBoolDeleteEvent), NULL);

  // Controlamos el Evento de Cambio de Estado
  g_signal_connect (G_OBJECT(window), "window-state-event",G_CALLBACK(FnBoolControlMaxMin),NULL);
  //g_signal_connect (G_OBJECT(window), "window-state-event", G_CALLBACK(callback_func), userDataPointer);

  // Ejecuta el Ciclo Principal de la Aplicación
  gtk_main ();

  // Finaliza la Aplicación
  return 0;

}
