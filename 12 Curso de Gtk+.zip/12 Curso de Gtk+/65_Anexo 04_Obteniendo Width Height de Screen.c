/*
Curso de Programación con Gtk+
Autor:JAOR

Clase 65 Anexo 04 Obteniendo Width Heigth de Screen

*/
// Se incluye la librería
#include <gtk/gtk.h>

// Funcion para controlar la Señal de Destrucción
static void SbMainExit(GtkWidget *window, gpointer data)
{
    // Mensaje de que la ventana se ha destruido
    printf("Destroy Signal \n");

    // Llama a la función de la Librería que sale del Ciclo Main
    gtk_main_quit ();
}

// Función para controlar el Cierre de una Ventana
static gboolean FngBoolDeleteEvent(GtkWidget *window, GdkEvent *event)
{
    // Mensaje
    printf("Delete Event\n");

    // Valor de Retorno
    return FALSE;
}

// Función Principal
int main( int argc, char *argv[])
{

  // Objeto para el Widget
  GtkWidget *window;

  // Para obtener la referencia hacia el Screen de la Ventana
  GdkScreen *xScreen;

  // Para el Ancho y Alto
  gint giWidth, giHeight;

  // Inicializa la Librería
  gtk_init (&argc, &argv);

  // Crea el Widget con el Objeto declarado
  window = gtk_window_new (GTK_WINDOW_TOPLEVEL);

  // Coloca el Título
  gtk_window_set_title (GTK_WINDOW (window), "65_Anexo 04_Obteniendo Width Height de Screen");

  // Controla la Señal de Destrucción del Objeto
  g_signal_connect(G_OBJECT(window), "destroy",G_CALLBACK(SbMainExit), NULL);

  // Controla la Señal del evento "delete_event" de la Ventana-Widget
  g_signal_connect (G_OBJECT (window), "delete_event", G_CALLBACK (FngBoolDeleteEvent), NULL);

  // Establece el Tamaño Mínimo de la Ventana
  gtk_widget_set_size_request(window,400,400);

  // Obtengo el Width y el Height directo de la ventana
  gtk_window_get_size(GTK_WINDOW(window),&giWidth,&giHeight);

  // La imprimimos
  g_print("Dimensiones de la Ventana despues de 400,400 Width:%d Height:%d \n",giWidth,giHeight);

  // Obtenemos el Screen que maneja la Ventana
  xScreen = gtk_window_get_screen (GTK_WINDOW(window));

  // Obtenemos el Width y el Height
  giWidth  = gdk_screen_get_width  (xScreen);
  giHeight = gdk_screen_get_height (xScreen);

  // Desplegamos la información
  g_print("Dimensiones del Screen Width:%d Height:%d \n",giWidth,giHeight);

  // Establece el Tamaño Mínimo de la Ventana
  //gtk_widget_set_size_request(window,giWidth,giHeight);
  gtk_window_set_default_size(GTK_WINDOW(window),giWidth,giHeight);

  // Obtengo el Width y el Height directo de la ventana
  gtk_window_get_size(GTK_WINDOW(GTK_WINDOW(window)),&giWidth,&giHeight);

  // La imprimimos
  g_print("Dimensiones de la Ventana despues de request y default Width:%d Height:%d \n",giWidth,giHeight);

  // Maximizamos la Ventana
  //gtk_window_maximize(GTK_WINDOW(window));

  // Obtengo el Width y el Height directo de la ventana
  gtk_window_get_size(GTK_WINDOW(window),&giWidth,&giHeight);

  // La imprimimos
  g_print("Dimensiones de la Ventana despues de Maximizar Width:%d Height:%d \n",giWidth,giHeight);

  // La hace aparecer como una ventana de dialogo (DESCENTRA LA VENTANA)
  gtk_window_set_type_hint(GTK_WINDOW(window),GDK_WINDOW_TYPE_HINT_MENU);

  // Muestra la Ventana
  gtk_widget_show(window);

  // Ejecuta el Ciclo Principal de la Aplicación
  gtk_main ();

  // Finaliza la Aplicación
  return 0;

}
