/*

Curso de Programación con Gtk+
Autor:JAOR
Derechos Reservados: JaorSoftware
www.jaorsoftware.cc.cu

Clase 20_SubMenus

Los SubMenus son indispensables cuando es necesario clasificar
la Navegación de una aplicación a mas de un Nivel.
Para crear un SubMenú, simplemente debe de crearse otro Menu
y este debe agregarse al Menu anterior como una opción mas; aunque
con alguna particularidad en esta operación.

Para realizar lo anterior, se hace uso de la siguiente función
void gtk_menu_item_set_submenu (GtkMenuItem *menuitem,GtkWidget *submenu);

Esta función lo que hace, es mostrar el SubMenú y agregar un icono
como una >,para indicar que esa opción tiene SubOpciones.


*/

// Incluimos la Librería
#include <gtk/gtk.h>

// Función Principal
int main_20(int argc, char *argv[])
{
  // Variables para los objetos
  GtkWidget *window;         // La ventana principal
  GtkWidget *vbox;           // El Contenedor
  GtkWidget *menuBarra;      // El Contenedor del Menu
  GtkWidget *menuSistema;    // El Contenedor del Menu Sistema
  GtkWidget *menuCatalogos;  // El Contenedor del Menu Catálogos
  GtkWidget *opcSistema;     // La Opción-Menu de Sistema
  //GtkWidget *opcConfigurar;  // La Opcion Configurar
  GtkWidget *opcSalir;       // La Opcion Salir
  GtkWidget *opcCatalogos;   // La Opcion-Menu de Catalogos
  GtkWidget *opcProveedores; // La Opcion-Proveedores
  GtkWidget *opcClientes;    // La Opción-Cliente

  // SubMenu
  GtkWidget *menuConfigurar; // Para el Menu de Configurar
  GtkWidget *opcConfigurar2; // La Opcion Configurar
  GtkWidget *opcImpresora;   // Subopcion;
  GtkWidget *opcMoneda;      // Subopcion

  // Iniciamos la Librería
  gtk_init(&argc, &argv);

  // Creamos la Ventana
  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);

  // Establecemos las posición
  gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);

  // Establecemos el Tamaño
  gtk_window_set_default_size(GTK_WINDOW(window), 250, 200);

  // Colocamos el Título
  gtk_window_set_title(GTK_WINDOW(window), "menu");

  // Creamos el Contenedor
  vbox = gtk_vbox_new(FALSE, 0);

  // Añadimos el Contenedor a la Ventana Principal
  gtk_container_add(GTK_CONTAINER(window), vbox);

  // Creamos la Barra de Menu
  menuBarra = gtk_menu_bar_new();

  // Creamos Las Opciones Principales
  menuSistema   = gtk_menu_new();
  menuCatalogos = gtk_menu_new();

  // Creamos las Opciones de Sistema
  opcSistema    = gtk_menu_item_new_with_label("Sistema");
  //opcConfigurar = gtk_menu_item_new_with_label("Configurar");
  opcSalir      = gtk_menu_item_new_with_label("Salir");


  // Creamos las Opciones de Catalogos
  opcCatalogos   = gtk_menu_item_new_with_label("Catálogos");
  opcProveedores = gtk_menu_item_new_with_label("Proveedores");
  opcClientes    = gtk_menu_item_new_with_label("Clientes");

  // Establecemos la opción item File como SubMenu
  gtk_menu_item_set_submenu(GTK_MENU_ITEM(opcSistema), menuSistema);

   // Establecemos la opción configurar como una opción del Menu
  //gtk_menu_shell_append(GTK_MENU_SHELL(menuSistema), opcConfigurar);


  // Establecemos la opción Quit como una opción del Menu
  gtk_menu_shell_append(GTK_MENU_SHELL(menuSistema), opcSalir);

  // Establecemos el Item File como una opción de la Barra de Menu
  gtk_menu_shell_append(GTK_MENU_SHELL(menuBarra), opcSistema);


  //Submenu
  menuConfigurar = gtk_menu_new();
  opcConfigurar2 = gtk_menu_item_new_with_label("Configurar");
  opcImpresora = gtk_menu_item_new_with_label("Impresora");
  opcMoneda = gtk_menu_item_new_with_label("Moneda");
  gtk_menu_item_set_submenu(GTK_MENU_ITEM(opcConfigurar2), menuConfigurar);
  gtk_menu_shell_append(GTK_MENU_SHELL(menuConfigurar), opcImpresora);
  gtk_menu_shell_append(GTK_MENU_SHELL(menuConfigurar), opcMoneda);

  // Establecemos la opción configurar como una opción del Menu
  gtk_menu_shell_append(GTK_MENU_SHELL(menuSistema), opcConfigurar2);


  // Menu de Catálogos
  gtk_menu_item_set_submenu(GTK_MENU_ITEM(opcCatalogos), menuCatalogos);

   // Establecemos la opción Quit como una opción del Menu
  gtk_menu_shell_append(GTK_MENU_SHELL(menuCatalogos), opcProveedores);

  // Establecemos la opción Quit como una opción del Menu
  gtk_menu_shell_append(GTK_MENU_SHELL(menuCatalogos), opcClientes);

  // Establecemos el Item File como una opción de la Barra de Menu
  gtk_menu_shell_append(GTK_MENU_SHELL(menuBarra), opcCatalogos);


  // void gtk_box_pack_start(GtkBox *box,GtkWidget *child,gboolean expand,gboolean fill,guint padding)
  gtk_box_pack_start(GTK_BOX(vbox), menuBarra, FALSE, FALSE, 3);

  // Captura la Señal para destruir el Objeto
  g_signal_connect_swapped(G_OBJECT(window), "destroy",G_CALLBACK(gtk_main_quit), NULL);

  // Establece que el Item quit ejecute la salida de la Ventana
  g_signal_connect(G_OBJECT(opcSalir), "activate",G_CALLBACK(gtk_main_quit), NULL);

  // Mostramos los objetos de la Ventana
  gtk_widget_show_all(window);

  // Ejecutamos el Loop Principal
  gtk_main();

  // Retornamos 0
  return 0;

}
