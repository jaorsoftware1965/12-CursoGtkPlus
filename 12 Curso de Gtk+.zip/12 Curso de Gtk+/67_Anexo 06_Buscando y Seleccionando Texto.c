/*

Autor    : JAOR
Curso    : Library Gtk+
Clase 67 : Anexo 06 Buscando y Seleccionando Texto

*/

// Inclusión de librerías
#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>

// Función para controlar el evento de Tecla Presionada
gboolean FnTeclaPresionada(GtkWidget     *window,     // Ventana
                           GdkEventKey   *event,      // Evento
                           GtkTextBuffer *buffer)     // El Buffer
{

  // Declaración de Variables
  GtkTextIter start_sel, end_sel;       // Para el inicio y final de Selección
  GtkTextIter start_find, end_find;     // Para inicio y final de palabra encontrada
  GtkTextIter start_match, end_match;   // Para inicio y final de Match
  gboolean selected;                    // Seleccionado
  gchar *text;                          // Para el texto

  // Verifica si se ha presionado una tecla
  if ((event->type == GDK_KEY_PRESS) &&
     (event->state & GDK_CONTROL_MASK))
  {

     // Verifica cual tecla se ha presionado
     switch (event->keyval)
     {

         case GDK_KEY_m : // Control - m
         case GDK_KEY_M : // Control - M

           // Obtiene el Texto Seleccionado
           selected = gtk_text_buffer_get_selection_bounds(buffer,&start_sel, &end_sel);

           // Verifica si hay texto seleccionado
           if (selected)
           {
              // Obtiene los iter al inicio y fin del Texto en el buffer
              gtk_text_buffer_get_start_iter(buffer, &start_find);
              gtk_text_buffer_get_end_iter(buffer, &end_find);

              // Remueve el Tag si existe en el texto
              gtk_text_buffer_remove_tag_by_name(buffer, "green_bg",&start_find, &end_find);

              // Obtiene el texto Seleccionado
              text = (gchar *) gtk_text_buffer_get_text(buffer, &start_sel,&end_sel, FALSE);

              // Ciclo para ir seleccionando el texto en todo el contenido del buffer
              // Busca text desde start_find, y obtiene su inicio y final en start_match y end_match
              while (gtk_text_iter_forward_search(&start_find, text,
                                                   GTK_TEXT_SEARCH_TEXT_ONLY |
                                                   GTK_TEXT_SEARCH_VISIBLE_ONLY |
                                                   GTK_TEXT_SEARCH_CASE_INSENSITIVE,
                                                  &start_match, &end_match, NULL))
              {
                  // Aplica el Tag al buffer, en donde encotré el texto; start_match y end_match
                  gtk_text_buffer_apply_tag_by_name(buffer, "green_bg",&start_match, &end_match);

                  // Obtiene el desplazamiento alel final del match
                  gint offset = gtk_text_iter_get_offset(&end_match);

                  // Obtiene el nuevo start_find, a partir del offset
                  gtk_text_buffer_get_iter_at_offset(buffer,&start_find, offset);
              }

              // Libera la variable del texto
              g_free(text);
           }
           break;

         case GDK_KEY_n: // Control - N
         case GDK_KEY_N:

           // Obtiene el Inicio y Final del Buffer
           gtk_text_buffer_get_start_iter(buffer, &start_find);
           gtk_text_buffer_get_end_iter(buffer, &end_find);

           // Remueve el Tag del Buffer
           gtk_text_buffer_remove_tag_by_name(buffer, "green_bg",&start_find, &end_find);
           break;
     }
  }

  // Finaliza el Proceso Returnando False
  return FALSE;
}

// Función Principal
int main(int argc, gchar *argv[])
{

  // Declaracioń de Variables
  GtkWidget *window;  // Ventana Principal
  GtkWidget *view;    // El TextView
  GtkWidget *vbox;    // El Contenedor

  GtkTextBuffer *buffer;  // El Buffer
  GtkTextIter start, end; // Iter para Inicio y Final
  GtkTextIter iter;       // Iter

  // Inicializa la Librería
  gtk_init(&argc, &argv);

  // Crea la Nueva Ventana y le da formato
  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);
  gtk_window_set_default_size(GTK_WINDOW(window), 350, 300);
  gtk_window_set_title(GTK_WINDOW(window), "Clase 67 Anexo 06 Buscando y Seleccionado Texto");

  // Crea el Contenedor
  vbox = gtk_vbox_new(FALSE, 0);

  // Crea la Vista
  view = gtk_text_view_new();

  // Añade el Control de Eventos al TextView
  //gtk_widget_add_events(view, GDK_BUTTON_PRESS_MASK);

  // Agrega la Vista al Contenedor
  gtk_box_pack_start(GTK_BOX(vbox), view, TRUE, TRUE, 0);

  // Obtiene el Buffer del TextView
  buffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(view));

  // Agrega el Tag para poder dar formato al texto
  gtk_text_buffer_create_tag(buffer, "green_bg","background", "green", NULL);

  // Agrega el Contenedor a la Ventana
  gtk_container_add(GTK_CONTAINER(window), vbox);

  // Captura la Señal de Salida de la Ventana
  g_signal_connect(G_OBJECT(window), "destroy",G_CALLBACK(gtk_main_quit), NULL);

  // Captura la Señal de Tecla Presionada
  g_signal_connect(G_OBJECT(window), "key-press-event",G_CALLBACK(FnTeclaPresionada), buffer);

  // Muestra todos los objetos de la Ventana
  gtk_widget_show_all(window);

  // Ejecuta el Ciclo Principal
  gtk_main();

  // Finaliza con 0
  return 0;
}
