/*

Curso de Programación con Gtk+
Autor:JAOR
Derechos Reservados: JaorSoftware
www.jaorsoftware.com
www.jaorsoftware.cc.cu

Clase 03_Eventos

EVENTOS.
Un Evento es una Señal que es generada por el Usuario al interactuar
con la Interfaz Gráfica de Gtk+.

En GTK+ las Señales y Eventos se administran casi de la misma manera,
la distinción entre estos dos grupos se debe a que las Señales son provocadas
por el Sistema de objetos de Glib / GTK+ y los Eventos son una corriente
de mensajes que llegan desde el Subsistema gráfico.

Desde una perspectiva del programador resulta sencillo pensar en los eventos
como cualquier señal causada por la interacción del usuario con el programa.
Con lo anterior concluimos que un Evento es una Señal generada por la interacción
con el usuario.

Existe un conjunto de eventos que reflejan el mecanismo de eventos
del subsistema gráfico del sistema operativo (En UNIX será X-window).
Es posible capturar estos eventos con funciones callback.

Los Eventos son:

event                   button_press_event      button_release_event    scroll_event
motion_notify_event     delete_event            destroy_event           expose_event
key_press_event         key_release_event       enter_notify_event      leave_notify_event
configure_event         focus_in_event          focus_out_event         map_event
unmap_event             property_notify_event   selection_clear_event   selection_request_event
selection_notify_event  proximity_in_event      proximity_ouLevent      visibility_notify_event
client_event            no_expose_event         window_state_event

Para poder conectar una función callback a alguno de estos eventos, se usará la función
g_signal_connect() , tal y como se ha descrito usando alguno de los nombres que se dan
como el parámetro señal. La función callback para eventos es un poco diferente a la que se usa
para las señales:

gint funcion_callback(GtkWidget *widget,GdkEvent *event,gpointer datos_extra );

Para poder conectar una función callback a alguno de estos eventos,
se usará de igual forma la función g_signal_connect() , tal y como se
ha descrito anteriormente, usando alguno de los nombres de eventos que
se muestran, como el parámetro señal de la función callback.

En esta declaración podemos distinguir el Tipo GdkEvent, el cual es un unión,
de la cual su tipo dependerá de cual de los eventos mostrados arriba se han
producido y esta construido mediante diferentes máscaras de eventos.

Para poder decirnos que tipo de evento ha ocurrido, cada una de las posibles
alternativas tiene un miembro type que muestra que evento ocurrió. Los otros
elementos de la estructura dependerán de que tipo de evento se generó.

Las máscaras de los tipos posibles de eventos son:

GDK_NOTHING             GDK_DELETE              GDK_DESTROY
GDK_EXPOSE              GDK_MOTION_NOTIFY       GDK_BUTTON_PRESS
GDK_2BUTTON_PRESS       GDK_3BUTTON_PRESS       GDK_BUTTON_RELEASE
GDK_KEY_PRESS           GDK_KEY_RELEASE         GDK_ENTER_NOTIFY
GDK_LEAVE_NOTIFY        GDK_FOCUS_CHANGE        GDK_CONFIGURE
GDK_MAP                 GDK_UNMAP               GDK_PROPERTY_NOTIFY
GDK_SELECION_REQUEST    GDK_SELECTION_NOTIFY    GDK_PROXIMITY_IN
GDK_PROXIMITY_OUT       GDK_DRAG_ENTER          GDK_DRAG_LEAVE
GDK_DRAG_MOTION         GDK_DRAG_STATUS         GDK_DROP_START
GDK_DROP_FINISHED       GDK_CLIENTE_EVENT       GDK_VISIBILITY_NOTIFY
GDK_NO_EXPOSE           GDK_SCROLL              GDK_WINDOW_STATE
GDK_SETTING

Ejemplo:

g_signal_connect ( G_OBJECT (button),"button_press_event",G_CALLBACK (button_press_callback),NULL);

En la anterior declaración, se asume que button es un widget. Cuando el
ratón esté sobre el botón y el botón sea presionado, se llamará a la función
button_press_callback(), la cual puede ser declarada como sigue:

static gint button_press_callback( GtkWidget *widget, GdkEventButton *event, gpointer data );

En este ejemplo, podemos distinguir que el segundo argumento se ha declarado
del Tipo GdkEventButton, ya que en este caso, se conoce cual es el evento
que ocurrirá para que esta función sea invocada. El valor regresado por esta
función indica si el evento se deberá propagar más allá por el
mecanismo de manejo de señales de GTK+.

Regresar FALSE indica que el evento ya ha sido tratado correctamente y ya no
se debe propagar.

Instrucción para Compilar desde la Terminal
gcc -o 03_Eventos 03_Eventos.c `pkg-config --libs --cflags gtk+-2.0`

*/
// Se incluye la librería
#include <gtk/gtk.h>


// Detiene el Ciclo Principal iniciado por gtk_main cuando la ventana es destruida
static void SbMainExit(GtkWidget *window, gpointer data)
{
    // Mensaje de que la ventana se ha destruido
    printf("Destroy Signal \n");

    // Llama a la función de la Librería que sale del Ciclo Main
    gtk_main_quit ();
}

// Función para controlar el Cierre de una Ventana
// Si se retorna FALSE se cerrará y posteriormente se destruirá la ventana
// Si se retorna TRUE, se cancela el cierre.
// Esta función puede utilizarse para confirmar el cierre de una Ventana
// y Salir de una Aplicación
static gboolean FngBoolDeleteEvent(GtkWidget *window, GdkEvent *event)
{
    printf("Delete Event\n");
    if (event->type == GDK_DELETE)
       return TRUE;
    else
       // Valor de Retorno
       return FALSE;
}



// Función Principal
int main_03( int argc, char *argv[])
{
  int x=10;

  // Objeto para el Widget
  GtkWidget *window;

  // Inicializa la Librería
  gtk_init (&argc, &argv);

  // Crea el Widget con el Objeto declarado
  window = gtk_window_new (GTK_WINDOW_TOPLEVEL);

  // Coloca el Título
  gtk_window_set_title (GTK_WINDOW (window), "03_Eventos");

  // Mostramos la Ventana con la función gtk_widget_show
  gtk_widget_show(window);

  // Controla la Señal "destroy" de la Ventana-Widget
  g_signal_connect (G_OBJECT (window), "destroy",G_CALLBACK (SbMainExit), NULL);

  // Controla la Señal del evento "delete_event" de la Ventana-Widget
  g_signal_connect (G_OBJECT (window), "delete_event", G_CALLBACK (FngBoolDeleteEvent), NULL);

  // Ejecuta el Ciclo Principal de la Aplicación
  gtk_main ();

  // Finaliza la Aplicación
  return 0;
}
