/*
---------------------------------
Curso de Programación con Gtk+
Clase 02_Señales y Funciones CallBack
Derechos Reservados JaorSoftware
www.jaorsoftware.com
www.jaorsoftware.cc.cu
---------------------------------

La Libreria Gtk+; como todas las librerías que trabajan en
Sistemas Operativos Gŕaficos Multiusuario; es una librería
que trabaja en base a Señales.

Como vimos en la clase anterior, cuando ejecutamos la función
"gtk_main"; esta ejecutará el ciclo principal de la aplicación,
hasta que una Señal ocurra y entonces la aplicación
ejecute el código correspondiente.

Cuando deseamos atender a la escucha de una Señal; debemos de
asociar una función callback a un widget.

Las Señales(Signals), son el medio por el cual Gtk+ interactua
con su ambiente operativo a través de su interfaz gráfica la cual
detecta estas señales a través de los objetos de su interfaz.

Si el usuario mueve el ratón, presiona un botón, escribe un texto
o cierra una ventana, una función callback se ejecutará
y esta realizará las acciones que se hayan establecido en la función.

En una aplicación, se están generando Señales constantemente, y es
responsabilidad del programador atender a estas a través de funciones
callback; obviamente; aquellas señales que sean de su interés.

Dos de las señales básicas en GTK+ son "delete_event" y "destroy".
La Señal "delete_event" generalmente se envía a una ventana cuando
el usuario trata de cerrarla. Por su parte, la señal "destroy"
se manda a un objeto cuando su método de destrucción debe ser invocado.

FUNCIONES CALLBACK
Una función callback es una función en C como cualquier otra, la
cual está orientada a una Señal y a un Objeto en específico.

Dependiendo de la Señal es como se declarará el tipo dato de
regreso y los parámetros. Una vez escrita adecuadamente, se registra esta rutina
ante GTK+ usando la macro g_signal_connect().

#define g_signal_connect(instance, detailed_signal, c_handler, data)

donde:

instance.
Es la referencia al widget u objeto del que queremos escuchar señales y
eventos. Este puntero debe estar moldeado al tipo GObject ya que GtkWidget
es un derivado de éste. Para esto deberemos usar la macro G_OBJECT().

detailed_signal.
Es una cadena que especifica la señal o evento a escuchar.

c_handler.
El puntero de la función retrollamada. Este puntero debe estar
moldeado mediante la macro G_CALLBACK() al tipo de puntero GCallback.
El prototipo de cada función retrollamada se determina por el contexto en el que será
usada; visto de otra manera: el prototipo de cada función se determina por el tipo de
señal a la que será conectada.

data.
Este último argumento permite adjuntar algún dato extra a la retrollamada, de
tal manera que se evite el uso de variables globales y en su lugar se pasen estructuras o
valores directamente a la función retrollamada cuando ésta sea invocada.

Es obvio, que la función callback cambia dependiendo de la señal que se desea
escuchar, pero existe una definición prototipo que se usa como base para todas:

Veamos el siguiente ejemplo:

g_signal_connect (G_OBJECT (window), "destroy",G_CALLBACK (gtk_main_quit), NULL);

El Anterior ejemplo está controlando la Señal "destroy" que se genera cuando
un Widget es destruido, y lo que hace es llamar a la función "gtk_main_quit"
cuando la señal sucede. La función "gtk_main_quit" es parte de las funciones
de Gtk+ y lo que hace es salir del Ciclo principal generado por "gtk_main".

Ahora veremos como definir una función callback propia para controlar la señal.

static void destroy(GtkWidget *window, gpointer data)

Es posible saber como definir una función callback para cada Señal, en la
Documentación del API de Gtk+.

Instrucción para Compilar desde la Terminal
gcc -o 02_Señales_Funciones_Callback 02_Señales_Funciones_Callback.c `pkg-config --libs --cflags gtk+-2.0`

*/
// Se incluye la librería
#include <gtk/gtk.h>


// Detiene el Ciclo Principal iniciado por gtk_main cuando la ventana es destruida
static void SbMainExit(GtkWidget *window, gpointer data)
{
    // Llama a la función de la Librería que sale del Ciclo Main
    gtk_main_quit();
}

int main_02( int argc, char *argv[])
{
  // Objeto para el Widget
  GtkWidget *window;

  // Inicializa la Librería
  gtk_init (&argc, &argv);

  // Crea el Widget con el Objeto declarado
  window = gtk_window_new (GTK_WINDOW_TOPLEVEL);

  // Coloca el Título
  gtk_window_set_title (GTK_WINDOW (window), "02_Señales_CallBack");

  // Mostramos la Ventana con la función gtk_widget_show
  gtk_widget_show(window);

  // Controla la Señal "destroy" de la Ventana-Widget
  //g_signal_connect (G_OBJECT (window), "destroy",G_CALLBACK (gtk_main_quit), NULL);
  g_signal_connect (G_OBJECT (window), "destroy",G_CALLBACK (SbMainExit), NULL);

  // Ejecuta el Ciclo Principal de la Aplicación
  gtk_main ();

  // Finaliza la Aplicación
  return 0;
}
