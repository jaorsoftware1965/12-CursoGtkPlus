/*

Autor    : JAOR
Curso    : Library Gtk+
Clase 59 : TextView VII

En esta clase veremos como realizar búsquedas en el
textview

*/

// Incluye la librería
#include <gtk/gtk.h>

// Estructura para la Entrada y TextView
typedef struct
{
   GtkWidget *entry,
          *textview;
} Widgets;


// Función que busca el Texto en el TetView
static void SbTextoBusca (GtkButton *button, Widgets *w)
{
    // Declaración de Variables
    const gchar *find;         // Texto a Buscar
          gchar *output;       // Texto de Salida
    GtkWidget *dialog;         // Ventana de Dialogo
    GtkTextBuffer *buffer;     // Buffer del Texto
    GtkTextIter start,         // Desde donde buscar
                inicio,        // Inicio de la Coincidencia
                final;         // Final de la Coincidencia
    gboolean bEncontro=TRUE;   // Variable para Resultados
    gint i = 0;                // Variable para Contar las Coincidencias

    // Obtiene el Texto a Buscar
    find = gtk_entry_get_text (GTK_ENTRY (w->entry));

    // Obtiene el Buffer del Texto
    buffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (w->textview));

     // Obtiene el apuntador al inicio del texto en el buffer
    gtk_text_buffer_get_start_iter (buffer, &start);

    // Ciclo para ir buscando las coincidencias mientras haya encontrado
    while (bEncontro)
    {

        // Realiza la búsqueda en el texto restante
        bEncontro = gtk_text_iter_forward_search (&start, (gchar*) find, 0,&inicio, &final, NULL);

        // Verifica si lo encontró
        if (bEncontro)
        {
            // recorre el start hacia el final
            start = final;

            // Incrementa el Contador de coincidencias
            i++;

        }

    }

    // Prepara el Mensaje de Salida
    output = g_strdup_printf ("El Texto '%s' se encontró %i coincidencia(s)!", find, i);

    // Prepara el diálogo a mostrar
    dialog = gtk_message_dialog_new (NULL, GTK_DIALOG_MODAL,
                                           GTK_MESSAGE_INFO,
                                           GTK_BUTTONS_OK,
                                           output, NULL);
    // Ejecuta el Diálogo
    gtk_dialog_run (GTK_DIALOG (dialog));

    // Destruye el diálogo
    gtk_widget_destroy (dialog);

    // Libera el Texto de Salida
    g_free (output);

}

// Función Principal
int main (int argc,char *argv[])
{
    // Declaración de Variables
    GtkWidget *window, // Ventana Principal
        *scrolled_win, // El Scroll
                *vbox, // Contenedor Vertical
                *hbox, // Contenedor Horizontal
                *find; // Botón de Búsqueda

    // Crea la Variable basada en la estructura
    Widgets *w = g_slice_new (Widgets);

    // Inicializa la librería
    gtk_init (&argc, &argv);

    // Crea la Ventana Principal y la Configura
    window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title (GTK_WINDOW (window), "Clase 59 - TextView VII");
    gtk_container_set_border_width (GTK_CONTAINER (window), 10);
    w->textview = gtk_text_view_new ();
    w->entry = gtk_entry_new ();

    // Coloca el Mensaje de Texto a Buscar
    gtk_entry_set_text (GTK_ENTRY (w->entry), "jaor");


    // Crea el Botón de buscar desde el Stock
    find = gtk_button_new_from_stock (GTK_STOCK_FIND);

    // Controla la Señal
    g_signal_connect (G_OBJECT (find), "clicked",G_CALLBACK (SbTextoBusca),(gpointer) w);

    // Crea el Scroll y agrega el TextView
    scrolled_win = gtk_scrolled_window_new (NULL, NULL);
    gtk_widget_set_size_request (scrolled_win, 250, 200);
    gtk_container_add (GTK_CONTAINER (scrolled_win), w->textview);

    // Crea el Contenedor Horizontal
    hbox = gtk_hbox_new (FALSE, 5);
    gtk_box_pack_start (GTK_BOX (hbox), w->entry, TRUE, TRUE, 0);
    gtk_box_pack_start (GTK_BOX (hbox), find, FALSE, TRUE, 0);

    // Crea el Contenedor y le agrega los datos
    vbox = gtk_vbox_new (FALSE, 5);
    gtk_box_pack_start (GTK_BOX (vbox), scrolled_win, TRUE, TRUE, 0);
    gtk_box_pack_start (GTK_BOX (vbox), hbox, FALSE, TRUE, 0);
    gtk_container_add (GTK_CONTAINER (window), vbox);

    // Muestra todos los objetos de la Ventana
    gtk_widget_show_all (window);

    // Inicializa el Ciclo Principal
    gtk_main();

    // Finaliza Retornando 0
    return 0;
}
