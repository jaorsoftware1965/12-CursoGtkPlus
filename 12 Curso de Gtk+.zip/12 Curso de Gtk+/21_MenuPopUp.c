/*
Curso de Programación con Gtk+
Autor:JAOR
Derechos Reservados: JaorSoftware


Clase 21 - Menu PopUp

En esta clase veremos como mostrar un Menu PopUp o Contextual, para lo
cual se utiliza la función:

void
gtk_menu_popup (GtkMenu *menu,
                GtkWidget *parent_menu_shell,
                GtkWidget *parent_menu_item,
                GtkMenuPositionFunc func,
                gpointer data,
                guint button,
                guint32 activate_time);

Esta función se utiliza para desplegar Menus Contextuales; y normalmente
se utilizará el valor de NULL para el parent_menu_shell , parent_menu_item ,
func and data parameters.

La posición por default del menú, será la posición del Apuntador del Mouse.

El parámetro button, deberá ser el botón del Mouse presionado, para mostrar
el Menú.

El parámetro activate_time, es utilizado para resolver conflictos  entre
requerimientos del teclado y el mouse. Para que esto funcione apropiadamente,
necesita ser proporcionado el timestamp del evento del usuario.

Esta es la definición del Función para controlar la posición del Despliegue
del Menu.

void (*GtkMenuPositionFunc) (GtkMenu *menu,
                             gint *x,
                             gint *y,
                             gboolean *push_in,
                             gpointer user_data);


El parámetro menu, es el menu a desplegar.
Los parámetros x,y son la posición del Menu.
El parámetro push_in, controla como manejar los menus cuando estos se ubican
fuera de la pantalla. Si es TRUE, el menu se obligará a entrar a el área visible
de la Ventana
El user_data, es un parametro de referencia del objeto que se utilice para
desplegar el menu.

*/

// Se incluye la librería
#include <gtk/gtk.h>

// Función para controlar la posición
static void SbSetPosition(GtkMenu *menu, gint *x, gint *y, gboolean *push_in, gpointer user_data)
{
  // No Funciona
  *push_in=TRUE;

  // Lo desplazo;
  *x -=200;
  *y -=200;
}

// Función para Mostrar el Menu PopUp
int FnIntShowMenuPopup(GtkWidget *widget, GdkEvent *event)
{

  // Constante para el Botón Derecho
  const int RIGHT_BUTTON = 3;
  const int LEFT_BUTTON = 1;

  // Verifica el Evento
  if (event->type == GDK_BUTTON_PRESS)
  {

      // Declara una Variable del Tipo GdkEventButton y le asigna el Evento
      GdkEventButton *bevent = (GdkEventButton *) event;

      // Verifica si es el botón derecho
      if (bevent->button == RIGHT_BUTTON) {

          // Si es así lo Muestra
          //gtk_menu_popup(GTK_MENU(widget), NULL, NULL, NULL, NULL,bevent->button, bevent->time);
          gtk_menu_popup(GTK_MENU(widget), NULL, NULL, (GtkMenuPositionFunc) SbSetPosition, NULL,bevent->button, bevent->time);
      }
      // Devuelve True
      return TRUE;
  }

  return FALSE;
}

// Función Principal
int main_21(int argc, char *argv[]) {

  // Declaración de Variables
  GtkWidget *window;
  GtkWidget *ebox;
  GtkWidget *mnuPopUp;
  GtkWidget *opcMinimizar;
  GtkWidget *opcSalir;

  // Inicializa la Librería
  gtk_init(&argc, &argv);

  // Crea la Ventana, la Ubica, le da el Tamaño y Título
  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);
  gtk_window_set_default_size(GTK_WINDOW(window), 300, 200);
  gtk_window_set_title(GTK_WINDOW(window), "Clase 21 - Popup menu");

  // Crea un Controlador de Eventos
  ebox = gtk_event_box_new();

  // Lo añade a la Ventana
  gtk_container_add(GTK_CONTAINER(window), ebox);

  // Crea el Menu con sus opciones
  mnuPopUp = gtk_menu_new();
  opcMinimizar = gtk_menu_item_new_with_label("Minimizar");
  gtk_widget_show(opcMinimizar);
  gtk_menu_shell_append(GTK_MENU_SHELL(mnuPopUp), opcMinimizar);
  opcSalir = gtk_menu_item_new_with_label("Salir");
  gtk_widget_show(opcSalir);
  gtk_menu_shell_append(GTK_MENU_SHELL(mnuPopUp), opcSalir);

  // Controlamos las Señales de las opciones del Menu
  g_signal_connect_swapped(G_OBJECT(opcMinimizar), "activate",
      G_CALLBACK(gtk_window_iconify), GTK_WINDOW(window));

  g_signal_connect_swapped(G_OBJECT(opcSalir), "activate",
      G_CALLBACK(gtk_main_quit), NULL);

  g_signal_connect_swapped(G_OBJECT(window), "destroy",
      G_CALLBACK(gtk_main_quit), NULL);

  g_signal_connect_swapped(G_OBJECT(ebox), "button-press-event",
      G_CALLBACK(FnIntShowMenuPopup), mnuPopUp);

  // Muestra todos los Objetos
  gtk_widget_show_all(window);

  // Ciclo principal
  gtk_main();

  // Retorna 0
  return 0;

}
