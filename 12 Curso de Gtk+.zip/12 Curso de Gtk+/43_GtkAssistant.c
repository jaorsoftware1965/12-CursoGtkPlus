/*

Autor:JAOR
Derechos Reservados: JaorSoftware

Curso de Librería Gtk+
Clase 43 - GtkAssistant

En la Clase de hoy veremos un Diálogo que es muy particular
de la Librería, y que al menos en mi experiencia personal,
no existe en ningún otro lenguaje de programación; aunque
por supuesto que puede implementarse; y que es el GtkAssistant
Page.

Un GtkAssistantPage es un diálogo que maneja multiples páginas;
y aunque es un diálogo; no se deriva de la Clase GtkDialog.

Lo interesante del Diálogo, es que se puede navegar hacia
adelante y hacia atrás, respetando el orden en que las paginas
se encuentran definidas dentro de el.

Cada una de las páginas del Diálogo, tiene sus propias propiedades
de las cuales se enuncian las siguientes:

Título de la Página. Cada Página tiene su propio título

Imagen de Cabecera. Es posible desplegar una imagen en el tope de
cada página.

Imagen Lateral. Es posible desplegar una imagen lateral en cada página

Tipo de Página. Cada página puede ser de un tipo diferente; y la primera
página debe ser siempre GTK_ASSISTANT_PAGE_INTRO. La última página
siempre debe ser GTK_ASSISTANT_PAGE_CONFIRM o GTK_ASSISTANT_PAGE_SUMMARY.

Si el Diálogo no termina con uno de esos dos tipos de páginas,
no funcionará correctamente.

A continuación los tipos de páginas disponibles:

• GTK_ASSISTANT_PAGE_CONTENT: Este tipo de página tiene contenido general,
lo que significa que se puede utilizar para casi todas las páginas en el
asistente. Nunca se debe utilizar para la última página de un asistente.

• GTK_ASSISTANT_PAGE_INTRO: Este tipo de página tiene información introductoria
para el usuario. Esto sólo se debe establecer para la primera página en el asistente.
Aunque no es necesario, páginas introductorias dan la dirección de usuario y deben
ser utilizados en la mayoría de los asistentes.

• GTK_ASSISTANT_PAGE_CONFIRM: La página permite al usuario confirmar o negar un
conjunto de cambios. Esto se utiliza generalmente para los cambios que no se
pueden deshacer o puedan causar algún error si no está correctamente configurado.
Esto sólo se debe establecer para la última página del asistente.

• GTK_ASSISTANT_PAGE_SUMMARY: La página ofrece un resumen de los cambios que se
han producido. Esto sólo se debe establecer para la última página del asistente.

• GTK_ASSISTANT_PAGE_PROGRESS: Cuando una tarea tarda mucho tiempo para completar,
esto bloqueará el asistente hasta que la página se marca como completa.
La diferencia entre esta página y una página de contenido normal es que todos
los botones están desactivados y el usuario se impide cerrar el asistente.

*/

// Librerías
#include <gtk/gtk.h>
#include <string.h>

// Funciones que se utilizarán
static void entry_changed (GtkEditable*, GtkAssistant*);
static void button_toggled (GtkCheckButton*, GtkAssistant*);
static void button_clicked (GtkButton*, GtkAssistant*);
static void assistant_cancel (GtkAssistant*, gpointer);
static void assistant_close (GtkAssistant*, gpointer);

// Estructura que se utilizará
typedef struct
{
    GtkWidget *widget;
    gint index;
    const gchar *title;
    GtkAssistantPageType type;
    gboolean complete;
} PageInfo;

// Función Principal
int main (int argc,char *argv[])
{
    // Definición de Variables para las páginas
    GtkWidget *assistant,  // Variable para el Asistente
              *entry,      // Variable para entrada de texto
              *label,      // Variable para la etiqueta
              *button,     // Botón para la barra de progreso
              *progress,   // Variable para la barra de progeso
              *hbox;       // Variable para el Contenedor

    // Variable para el índice
    guint i;

    // Define la Estructura para usar por el Asistente
    PageInfo page[5] =
    {
        { NULL, -1, "Introducción",GTK_ASSISTANT_PAGE_INTRO, TRUE},
        { NULL, -1, NULL,GTK_ASSISTANT_PAGE_CONTENT, FALSE},
        { NULL, -1, "Click en el Check Button", GTK_ASSISTANT_PAGE_CONTENT, FALSE},
        { NULL, -1, "Click en el Botón",GTK_ASSISTANT_PAGE_PROGRESS, FALSE},
        { NULL, -1, "Confirmación",GTK_ASSISTANT_PAGE_CONFIRM, TRUE},
    };

    // Inicializa la Librería
    gtk_init (&argc, &argv);

    // Crea un asistente sin páginas
    assistant = gtk_assistant_new ();

    // Establece el tamaño de la Ventana del Asistente
    gtk_widget_set_size_request (assistant, 450, 300);

    // Coloca el Título de la Ventana del Asistenten
    gtk_window_set_title (GTK_WINDOW (assistant), "Clase 43 - GtkAssistant");

    // Conecta la Señal de Finalización de la aplicación
    g_signal_connect (G_OBJECT (assistant), "destroy",G_CALLBACK (gtk_main_quit), NULL);

    // Coloca el Texto de una etiqueta para la primera página
    page[0].widget = gtk_label_new ("Ejemplo de un GtkAssistant. \n\n"\
    "Dando Click al botón de continuar, puedes seguir adelante \n"\
    "a la siguiente sección.\n\n"\
    "Cancelar en caso de que desees finaliza el Asistente.");

    // Coloca un hbox para la página 1
    page[1].widget = gtk_hbox_new (FALSE, 5);

    // Establece un CheckButton con etiqueta para la página 2
    page[2].widget = gtk_check_button_new_with_label ("Click sobre mi para  continuar!");

    // Establace un alineamiento para la página 3
    page[3].widget = gtk_alignment_new (0.5, 0.5, 0.0, 0.0);

    // Coloca de nuevo una etiqueta para la página final
    page[4].widget = gtk_label_new ("Has llegado al Final del Asistente.\n"\
    "Si la información capturada es correcta presiona Aplicar para finalizar.\n"\
    "Los Cambios se realizarán.");

    // Crea la etiqueta y la entrada de texto para la segunda página
    label = gtk_label_new ("Captura el Nombre: ");
    entry = gtk_entry_new ();

    // Los agrega al hbox de la primera página
    gtk_box_pack_start (GTK_BOX (page[1].widget), label, FALSE, FALSE, 5);
    gtk_box_pack_start (GTK_BOX (page[1].widget), entry, FALSE, FALSE, 5);

    // Crea el botón y la barra de progreso que se utilizarán en la 4ta página
    button = gtk_button_new_with_label ("Click sobre mi!");
    progress = gtk_progress_bar_new ();
    hbox = gtk_hbox_new (FALSE, 5);
    gtk_box_pack_start (GTK_BOX (hbox), progress, TRUE, FALSE, 5);
    gtk_box_pack_start (GTK_BOX (hbox), button, FALSE, FALSE, 5);
    gtk_container_add (GTK_CONTAINER (page[3].widget), hbox);
    g_object_set_data (G_OBJECT (page[3].widget), "pbar", (gpointer) progress);

    // Añade las 5 páginas al Asistente
    for (i = 0; i < 5; i++)
    {
        // Coloca el índice
        page[i].index = gtk_assistant_append_page (GTK_ASSISTANT (assistant),page[i].widget);
        gtk_assistant_set_page_title (GTK_ASSISTANT (assistant),page[i].widget, page[i].title);
        gtk_assistant_set_page_type (GTK_ASSISTANT (assistant),page[i].widget, page[i].type);

        // Indica si la pagina está completada o no
        gtk_assistant_set_page_complete (GTK_ASSISTANT (assistant),page[i].widget, page[i].complete);
    }

    // Establece el control de las Señales de los Objetos
    g_signal_connect (G_OBJECT (entry), "changed",G_CALLBACK (entry_changed), (gpointer) assistant);
    g_signal_connect (G_OBJECT (page[2].widget), "toggled",G_CALLBACK (button_toggled), (gpointer) assistant);
    g_signal_connect (G_OBJECT (button), "clicked",G_CALLBACK (button_clicked), (gpointer) assistant);
    g_signal_connect (G_OBJECT (assistant), "cancel",G_CALLBACK (assistant_cancel), NULL);
    g_signal_connect (G_OBJECT (assistant), "close",G_CALLBACK (assistant_close), NULL);

    // Muestra todos los objetos del Asistente
    gtk_widget_show_all (assistant);

    // Ejecuta el Ciclo Principal
    gtk_main ();

    // Finaliza Retornando 0
    return 0;

}

// Esta función verifica si hay texto en el GtkEntry y si es así
// coloca como completada la página; de otra forma no se habilita
// el que el usuario pueda ir a la siguiente página
static void entry_changed (GtkEditable *entry,GtkAssistant *assistant)
{
    // Obtiene el texto del GtkEntry
    const gchar *text = gtk_entry_get_text (GTK_ENTRY (entry));

    // Obtiene el ńumero de página del asistente
    gint num = gtk_assistant_get_current_page (assistant);

    // Obtiene la referencia a la página del Asistente
    GtkWidget *page = gtk_assistant_get_nth_page (assistant, num);

    // Establece completada o no la página de acuerdo al texto
    gtk_assistant_set_page_complete (assistant, page, (strlen (text) > 0));
}

// Verifica si el Check Button está seleccionado para establecer que la
// página esta completa;
static void button_toggled (GtkCheckButton *toggle,GtkAssistant *assistant)
{
    // Obtiene el estado del Botón
    gboolean active = gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON (toggle));

    // Establece si está completada o no la página
    gtk_assistant_set_page_complete (assistant, GTK_WIDGET (toggle), active);
}

// Llena la Barra de Progreso, 10% cada segundo; cuando el botón es presionado
// La página se establece como completa, cuando la barra de progreso se ha
// llenado.
static void button_clicked (GtkButton *button,GtkAssistant *assistant)
{
    GtkProgressBar *progress;
    GtkWidget *page;
    gdouble percent = 0.0;
    gtk_widget_set_sensitive (GTK_WIDGET (button), FALSE);
    page = gtk_assistant_get_nth_page (assistant, 3);
    progress = GTK_PROGRESS_BAR (g_object_get_data (G_OBJECT (page), "pbar"));

    // Ciclo mientras que no se llegue a 100
    while (percent <= 100.0)
    {
        // Crea el Mensaje con el Porcentaje de llenado
        gchar *message = g_strdup_printf ("%.0f%% Complete", percent);

        g_printf("%s \n",message);

        // Actualiza la barra de progeso en base al porcentaje
        gtk_progress_bar_set_fraction (progress, percent / 100.0);

        // Coloca el texto en la barra
        gtk_progress_bar_set_text (progress, message);

        // Se asegura de que no haya eventos pendientes
        while (gtk_events_pending ())

        // Verifica la iteración de la página principal
        gtk_main_iteration ();

        // Espera 5 milisegundos
        g_usleep (500000);

        // Incrementa el porcentaje
        percent += 5.0;
    }

    // Establece que está completa la página cuando se llega a 100
    gtk_assistant_set_page_complete (assistant, page, TRUE);
}


// Función para eliminar el Asistente de la Memoria
static void assistant_cancel (GtkAssistant *assistant,gpointer data)
{
    // Se ha cancelado el Asistente
    g_print ("! Se ha cancelado el Asistente !\n");

    // Destruye el Diálogo del Asistente
    gtk_widget_destroy (GTK_WIDGET (assistant));
}

//Función que controla cuando el asistente es finalizado y el que destruye el diálogo
static void assistant_close (GtkAssistant *assistant, gpointer data)
{
    // Despliega el mensaje
    g_print ("! Los Cambios se aplicarán ahora !\n");

    // Destruye el asistente
    gtk_widget_destroy (GTK_WIDGET (assistant));
}
