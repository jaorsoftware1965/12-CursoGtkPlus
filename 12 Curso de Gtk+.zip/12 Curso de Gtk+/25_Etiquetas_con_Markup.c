/*

Curso de Programación con Gtk+
Autor:JAOR
Derechos Reservados: JaorSoftware
www.jaorsoftware.com

Clase 24 - Etiquetas con Markup

Las Etiquetas con Markup, son una característica muy particular
de esta librería; ya que no existe en los  lenguajes tradicionales
de programación.

Una etiqueta con Markup, permite dar formato a texto, de una
forma similar a como se le da formato en HTML.

El formato para las etiquetas es llamado:
Pango Text Attribute Markup Language
el cual tiene características similares al Html.

El siguiente enlace muestra información con respecto
a este formateo de texto.
https://developer.gnome.org/pango/stable/PangoMarkupFormat.html

Para dar formato a una etiqueta utilizando Pango, se debe
utilizar la función:

gtk_label_set_markup(etiqueta,cadena_formato)

*/

// Incluye la librería
#include <gtk/gtk.h>

// Función principal
int main_25(int argc, char *argv[]) {

  // Variables para los objetos
  GtkWidget *window;    // La ventana principal
  GtkWidget *label;     // La etiqueta

  // Iniciamos la librería
  gtk_init(&argc, &argv);

  // Creamos la Ventana
  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);

  // La colocamos
  gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);

  // Establecemos su tamaño
  gtk_window_set_default_size(GTK_WINDOW(window), 300, 100);

  // Establecemos el Título de la Ventana
  gtk_window_set_title(GTK_WINDOW(window), "Clase 24 - Etiquetas con Markup");


  // Creamos una variable de cadena con el texto formateado
  //gchar *str = "<b>Texto en Bold</b>, Texto Normal";
  //gchar *str = "<i>Texto en Italica</i>, Texto Normal";
  gchar *str = "<span foreground='blue' size='x-large'>Texto en Azul </span>Normal <i>Itálica !</i>";

  // Creamos la etiqueta
  label = gtk_label_new(NULL);

  // Establecemos el texto con el formato
  gtk_label_set_markup(GTK_LABEL(label), str);

  // Agregamos la etiqueta a la Ventana
  gtk_container_add(GTK_CONTAINER(window), label);

  // Mostramos la etiqueta
  gtk_widget_show(label);

  // Conectamos el evento destroy a la función para salir de la librería
  g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);

  // Mostramos la ventana
  gtk_widget_show(window);

  // Loop Principal
  gtk_main();

  // Finalizamos la Aplicación
  return 0;
}
