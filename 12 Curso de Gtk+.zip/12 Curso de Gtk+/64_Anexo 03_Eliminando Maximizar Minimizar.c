/*

Curso de Programación con Gtk+
Autor:JAOR

Clase 64 Anexo 03 Eliminando Maximizar Minimizar

*/
// Se incluye la librería
#include <gtk/gtk.h>

// Funcion para controlar la Señal de Destrucción
static void SbMainExit(GtkWidget *window, gpointer data)
{
    // Mensaje de que la ventana se ha destruido
    printf("Destroy Signal \n");

    // Llama a la función de la Librería que sale del Ciclo Main
    gtk_main_quit ();
}

// Función para controlar el Cierre de una Ventana
static gboolean FngBoolDeleteEvent(GtkWidget *window, GdkEvent *event)
{
    // Mensaje
    printf("Delete Event\n");

    // Valor de Retorno
    return FALSE;
}

// Función Principal
int main( int argc, char *argv[])
{

  // Objeto para el Widget
  GtkWidget *window;

  // Inicializa la Librería
  gtk_init (&argc, &argv);

  // Crea el Widget con el Objeto declarado
  window = gtk_window_new (GTK_WINDOW_TOPLEVEL);

  // Coloca el Título
  gtk_window_set_title (GTK_WINDOW (window), "64_Anexo 03 Eliminando Maximizar Minimizar");

  // Controla la Señal de Destrucción del Objeto
  g_signal_connect(G_OBJECT(window), "destroy",G_CALLBACK(SbMainExit), NULL);

  // Controla la Señal del evento "delete_event" de la Ventana-Widget
  g_signal_connect (G_OBJECT (window), "delete_event", G_CALLBACK (FngBoolDeleteEvent), NULL);


  // Establece el Tamaño Mínimo de la Ventana
  gtk_widget_set_size_request(window,400,400);


  // Ubicamos la Ventana
  //gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);

  // Maximizamos la Ventana
  gtk_window_maximize(GTK_WINDOW(window));

  // Evitamos que sea redimensionable
  //gtk_window_set_resizable(GTK_WINDOW(window),FALSE);

  // La hace aparecer como una ventana de dialogo (DESCENTRA LA VENTANA)
  gtk_window_set_type_hint(GTK_WINDOW(window),GDK_WINDOW_TYPE_HINT_MENU);

  // Maximizamos la Ventana
  gtk_window_maximize(GTK_WINDOW(window));

  // Muestra la Ventana
  gtk_widget_show(window);

  // Ejecuta el Ciclo Principal de la Aplicación
  gtk_main ();

  // Finaliza la Aplicación
  return 0;

}

