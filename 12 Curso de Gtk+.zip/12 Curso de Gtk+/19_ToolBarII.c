/*

Curso de Programación con Gtk+
Autor:JAOR
Derechos Reservados: JaorSoftware
www.jaorsoftware.cc.cu

Clase 19_ToolBarII

En esta clase veremos como capturar la Señal cuando se presiona
algún botón de la barra de Herramientas; para lo cual tendremos
que cambiar algunas cosas realizadas en la clase previa.

Veremos como podemos agregar nuestra propia imagen a uno de los
botones de la barra de herramientas.


*/

// Incluimos la Librería
#include <gtk/gtk.h>

// Función para controlar la accción del MenuChekItem y Ocultar/Visualizar la Barra de Estado
void SbAbrir(GtkWidget *widget,gpointer BarraEstado)
{
   // Mensaj
   printf("Abrir de la barra de herramientas\n");
}

void SbCancelar(GtkWidget *widget,gpointer BarraEstado)
{
   // Mensaj
   printf("Cerrar de la barra de herramientas\n");
}

// Función Principal
int main(int argc, char *argv[])
{
  // Variables para los objetos
  GtkWidget     *window;             // La ventana principal
  GtkWidget     *vbox;               // El Contenedor
  GtkWidget     *menuBarra;          // El Contenedor del Menu
  GtkWidget     *menuSistema;        // El Contenedor del Menu Sistema
  GtkWidget     *menuCatalogos;      // El Contenedor del Menu Catálogos
  GtkWidget     *opcSistema;         // La Opción-Menu de Sistema
  GtkWidget     *opcConfigurar;      // La Opcion Configurar
  GtkWidget     *opcSalir;           // La Opcion Salir
  GtkWidget     *opcCatalogos;       // La Opcion-Menu de Catalogos
  GtkWidget     *opcProveedores;     // La Opcion-Proveedores
  GtkWidget     *opcClientes;        // La Opción-Cliente
  GtkWidget     *separador;          // Separador
  GtkWidget     *opcBarraEstado;     // Agregamos opción para MenuCheckItem
  GtkAccelGroup *accel_group = NULL; // Acelerador
  GtkWidget     *boxJaor;            // Contenedor
  GtkWidget     *iconJaor;           // Para la imagen
  GtkWidget     *lblJaor;            // Para el texto
  GtkWidget     *opcJaor;            // Para la opción con icono
  // Status bar
  GtkWidget     *statusbar;
  gint          contextId;

  // ToolBar
  GtkWidget     *opcBarraHerramientas;// Agregamos opción para MenuCheckItem BarraHerramientas
  GtkWidget     *toolbarBox;          // Contenedor de la Barra de Herramientas
  GtkWidget     *toolbar;             // Manejador de la Barra de Herramientas

  // ToolBarII
  GtkToolItem   *abrir, *cancelar;


  // Iniciamos la Librería
  gtk_init(&argc, &argv);


  // Creamos el Contenedor para colocar la Imagen y el Texto;
  boxJaor = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 6);

  // Cargamos la imagen que deseamos
  iconJaor = gtk_image_new_from_file ("js.jpg");

  // Creamos la etiqueta
  lblJaor  = gtk_label_new ("JAOR");

  // Creamos la opción del Menu
  opcJaor  = gtk_menu_item_new ();

  // Agregamos al contenedor la Imagen y el Texto
  gtk_container_add (GTK_CONTAINER (boxJaor), iconJaor);
  gtk_container_add (GTK_CONTAINER (boxJaor), lblJaor);

  // Agregamos el Contenedor al Menu Item
  gtk_container_add (GTK_CONTAINER (opcJaor), boxJaor);

  // Creamos la Ventana
  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);


  // Establecemos las posición
  gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);

  // Establecemos el Tamaño
  gtk_window_set_default_size(GTK_WINDOW(window), 250, 200);

  // Colocamos el Título
  gtk_window_set_title(GTK_WINDOW(window), "19_ToolBarII");

  // Creamos el Contenedor
  vbox = gtk_vbox_new(FALSE, 0);

  // Añadimos el Contenedor a la Ventana Principal
  gtk_container_add(GTK_CONTAINER(window), vbox);

  // Creamos la Barra de Menu
  menuBarra = gtk_menu_bar_new();

  // Creamos Las Opciones Principales
  menuSistema   = gtk_menu_new();
  menuCatalogos = gtk_menu_new();

  // Creamos las Opciones de Sistema
  //opcSistema    = gtk_menu_item_new_with_label("Sistema");
  opcSistema    = gtk_menu_item_new_with_mnemonic("_Sistema");
  opcConfigurar = gtk_menu_item_new_with_label("Configurar");
  separador     = gtk_separator_menu_item_new();
  opcSalir      = gtk_menu_item_new_with_label("Salir");
  //gtk_image_menu_item_set_image (opcSalir,iconImage);

  // Crea el Menu Item con Check
  opcBarraEstado = gtk_check_menu_item_new_with_label("Barra de Estado");

  // Activa el Check Item
  gtk_check_menu_item_set_active(GTK_CHECK_MENU_ITEM(opcBarraEstado), TRUE);

  // Crea el Menu Item con Check
  opcBarraHerramientas = gtk_check_menu_item_new_with_label("Barra de Herramientas");

  // Activa el Check Item
  gtk_check_menu_item_set_active(GTK_CHECK_MENU_ITEM(opcBarraHerramientas), TRUE);


  // Creamos las Opciones de Catalogos
  opcCatalogos   = gtk_menu_item_new_with_label("Catálogos");
  opcProveedores = gtk_menu_item_new_with_label("Proveedores");
  opcClientes    = gtk_menu_item_new_with_label("Clientes");

  // Establecemos la opción item File como SubMenu
  gtk_menu_item_set_submenu(GTK_MENU_ITEM(opcSistema), menuSistema);

  // Establecemos la opción Quit como una opción del Menu
  gtk_menu_shell_append(GTK_MENU_SHELL(menuSistema), opcConfigurar);

  // Agregamos la opción con el Icono al Menu
  gtk_menu_shell_append(GTK_MENU_SHELL(menuSistema), opcJaor);

  // Agregamos la opción con el Menu CheckItem
  gtk_menu_shell_append(GTK_MENU_SHELL(menuSistema), opcBarraEstado);
  // Agregamos la opción con el Menu CheckItem
  gtk_menu_shell_append(GTK_MENU_SHELL(menuSistema), opcBarraHerramientas);

  // Agregamos un Separador
  gtk_menu_shell_append(GTK_MENU_SHELL(menuSistema), separador);

  // Establecemos la opción Quit como una opción del Menu
  gtk_menu_shell_append(GTK_MENU_SHELL(menuSistema), opcSalir);

  // Establecemos el Item File como una opción de la Barra de Menu
  gtk_menu_shell_append(GTK_MENU_SHELL(menuBarra), opcSistema);

  // Crea el Acelerador
  accel_group = gtk_accel_group_new();
  gtk_window_add_accel_group(GTK_WINDOW(window), accel_group);

  // Agregamos un Acelerador a la Salida
  gtk_widget_add_accelerator(opcSalir, "activate", accel_group, GDK_KEY_B, GDK_CONTROL_MASK, GTK_ACCEL_VISIBLE);


  // Menu de Catálogos
  gtk_menu_item_set_submenu(GTK_MENU_ITEM(opcCatalogos), menuCatalogos);

   // Establecemos la opción Quit como una opción del Menu
  gtk_menu_shell_append(GTK_MENU_SHELL(menuCatalogos), opcProveedores);

  // Establecemos la opción Quit como una opción del Menu
  gtk_menu_shell_append(GTK_MENU_SHELL(menuCatalogos), opcClientes);

  // Establecemos el Item File como una opción de la Barra de Menu
  gtk_menu_shell_append(GTK_MENU_SHELL(menuBarra), opcCatalogos);


  // void gtk_box_pack_start                  (GtkBox *box,
  //                                           GtkWidget *child,
  //                                           gboolean expand,
  //                                           gboolean fill,
  //                                           guint padding)
  gtk_box_pack_start(GTK_BOX(vbox), menuBarra, FALSE, FALSE, 3);

  //TOOLBAR
  toolbar = gtk_toolbar_new();

  // ToolBar II
  // Creamos los ToolItem hacia una variable para poder referenciarlos posteriormente
  //abrir = gtk_tool_button_new_from_stock (GTK_STOCK_OPEN);

  // Cargamos la imagen que deseamos
  iconJaor = gtk_image_new_from_file ("js.jpg");
  abrir = gtk_tool_button_new(iconJaor,"Abrir");
  cancelar = gtk_tool_button_new_from_stock (GTK_STOCK_SAVE_AS);

  //abrir=createToolItem(GTK_STOCK_OPEN, "Abrir");
  //cancelar=createToolItem(GTK_STOCK_CANCEL,"Cancelar");



  // Cambiamos las siguientes 2 lineas
  //gtk_toolbar_insert(GTK_TOOLBAR(toolbar),createToolItem(GTK_STOCK_OPEN, "Abrir"), 0);
  //gtk_toolbar_insert(GTK_TOOLBAR(toolbar),createToolItem(GTK_STOCK_CANCEL, "Cancelar"), 1);
  gtk_toolbar_insert(GTK_TOOLBAR(toolbar),abrir, 0);
  gtk_toolbar_insert(GTK_TOOLBAR(toolbar),cancelar, 1);

  //toolbarBox = gtk_handle_box_new();
  toolbarBox = gtk_box_new(GTK_ORIENTATION_VERTICAL,0);

  gtk_container_add(GTK_CONTAINER(toolbarBox), toolbar);
  gtk_box_pack_start(GTK_BOX(vbox), toolbarBox, FALSE, FALSE, 0);
  gtk_box_pack_start(GTK_BOX(vbox), gtk_text_view_new(), TRUE, TRUE, 0);

  // Variable para el Color
  GdkRGBA font_color;

  // Establece el Color
  font_color.red =   0.5;   // Valores de 0.0-1.0
  font_color.green = 1.0;
  font_color.blue =  0.0;
  font_color.alpha = 1.0;   // The opacidad del color: 0.0 para completamente transparente

  // Modifica el Color de Fondo del eventbox
  gtk_widget_override_background_color(toolbar, GTK_STATE_FLAG_NORMAL, &font_color);

  // ---------------------------------

  // Statusbar------------------------
  // Creamos el  Objeto
  statusbar = gtk_statusbar_new();

  // Creamos un identificador para la Barra de Estado con una descripción
  contextId = gtk_statusbar_get_context_id(GTK_STATUSBAR(statusbar), "Mensajes del Sistema");

  // Agregamos un Mensaje
  gtk_statusbar_push(GTK_STATUSBAR(statusbar),contextId, "Sistema Listo");
  gtk_box_pack_end(GTK_BOX(vbox), statusbar, FALSE, FALSE, 0);

  // ---------------------------------

  // Captura la Señal para destruir el Objeto
  g_signal_connect_swapped(G_OBJECT(window), "destroy",G_CALLBACK(gtk_main_quit), NULL);

  // Establece que el Item quit ejecute la salida de la Ventana
  g_signal_connect(G_OBJECT(opcSalir), "activate",G_CALLBACK(gtk_main_quit), NULL);

  // Señales para la Barra de Herramientas
  g_signal_connect_swapped (G_OBJECT (abrir), "clicked",G_CALLBACK(SbAbrir), NULL);
  g_signal_connect_swapped (G_OBJECT (cancelar), "clicked",G_CALLBACK(SbCancelar), NULL);

  // Mostramos los objetos de la Ventana
  gtk_widget_show_all(window);

  // Ejecutamos el Loop Principal
  gtk_main();

  // Retornamos 0
  return 0;

}
