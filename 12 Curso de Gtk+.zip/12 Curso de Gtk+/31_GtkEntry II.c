/*

Curso de Programación con Gtk+
Autor:JAOR
Derechos Reservados: JaorSoftware
www.jaorsoftware.com

Clase 31 - GtkEntry II

En esta clase veremos como hacer que un objeto GtkEntry
sea capturado como un password, es decir; desplegando
*'s en lugar de los caracteres capturados y de esta
forma ocultar lo que se escribe.

Para establecer que un GtkEntry sea oculto, utilizamos
la función gtk_entry_set_visibility.

Utilizamos la función  gtk_entry_set_invisible_char para
establecer cual es el caracter a desplegar en el despliegue
del password, para que no sea necesariamente un "."

Con la función gtk_editable_set_editable, indicaremos si es
editable o no el objeto y con la función gtk_entry_set_max_length
establecemos la longitud de captura

Tambien veremos una función que nos permite obtener cual es el
usuario con el cual hemos accedido al Sistema Operativo.

*/

// Incluímos la Librería
#include <gtk/gtk.h>

// Función Principal
int main_31(int argc,char *argv[])
{

    // Define las variables para los objetos
    GtkWidget *window,
              *vbox,
              *hbox,
              *lblPregunta,
              *lblMensaje,
              *entPassword;

    // Inicializa la librería
    gtk_init (&argc, &argv);

    // Crea la Ventana
    window = gtk_window_new (GTK_WINDOW_TOPLEVEL);

    // Establece el Título de la Ventana
    gtk_window_set_title (GTK_WINDOW (window), "Clase 31 - GtkEntry II");

    // Establece el Borde
    gtk_container_set_border_width (GTK_CONTAINER (window), 10);

    // Crea la cadena para la pregunta del Password
    gchar *str = g_strconcat ("Captura el Password de Acceso para:", g_get_user_name(), "?", NULL);

    // Crea la Etiqueta
    lblPregunta = gtk_label_new (str);

    // Crea la etiqueta para el Password
    lblMensaje = gtk_label_new ("Password:");

    /* Creamos el GtkEntry */
    entPassword = gtk_entry_new ();
    gtk_entry_set_visibility (GTK_ENTRY (entPassword), FALSE);
    gtk_entry_set_invisible_char (GTK_ENTRY (entPassword), '?');

    // Establecemos que sea editable
    //gtk_editable_set_editable (GTK_ENTRY (entPassword), FALSE);

    // Establecemos la longitud de captura
    gtk_entry_set_max_length (GTK_ENTRY (entPassword),10);

    // Crea el hbox
    hbox = gtk_hbox_new (FALSE, 5);

    // Agrega la etiqueta y el entry al Contenedor
    gtk_box_pack_start (GTK_BOX (hbox), lblMensaje, FALSE,FALSE,0);
    gtk_box_pack_start (GTK_BOX (hbox), entPassword, FALSE,FALSE,0);

    // Crea el vbox
    vbox = gtk_vbox_new (FALSE, 5);

    // Agrega los Objetos al Contenedor vbox
    gtk_box_pack_start (GTK_BOX (vbox), lblPregunta, FALSE,FALSE,0);
    gtk_box_pack_start (GTK_BOX (vbox), hbox, FALSE,FALSE,0);

    // Agrega el vbox a la ventana
    gtk_container_add (GTK_CONTAINER (window), vbox);

    // Asocia el evento destroy de la ventana principal */
    g_signal_connect( G_OBJECT( window ), "destroy", G_CALLBACK( gtk_main_quit ), NULL );

    // Muestra los Objetos
    gtk_widget_show_all (window);

    // El Ciclo Principal
    gtk_main ();

    // Finaliza Retornando 0
    return 0;
}
