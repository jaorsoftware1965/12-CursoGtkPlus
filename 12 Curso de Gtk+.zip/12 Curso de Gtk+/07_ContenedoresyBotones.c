/*
Curso de Programación con Gtk+
Autor:JAOR
Derechos Reservados: JaorSoftware
www.jaorsoftware.com
www.jaorsoftware.cc.cu

Clase 07 - Contenedores y Botones

CONTENEDORES
En la clase de hoy, veremos un tema fundamental en la programación
de Interfaces Gráficas y que son los Contenedores.

Un Contenedor es un objeto que puede contener a otros objetos; así
de simple.

En todos los Sistemas Gráficos que se fundamentan en la operación de
Ventanas; existen estos objetos, los cuales son fundamentales para
poder construir adecuadamente una Interfaz Gráfica.

A continuación se presenta el diagráma jerarquico de los objetos en
Gtk+.

                        GtkWidget
                            |
                      GtkContainer
                            |
                          GtkBin
                            |
   -----------------------------------------------------
   |                        |                           |
GtkScroolledWindow      GtkWindow                    GtkButton
                            |
            ---------------------------------
            |                               |
        GtkDialog                       GtkPlug

Como observamos en la Gráfica, los objetos GtkWindow son contenenedores.

En esta Clase veremos como hacer que una ventana contenga a otro objeto;
un Botón el cual al darle click cerrará la aplicación.

BOTONES.
Un botón es tambien un objeto contenedor; ya que contiene una etiqueta que
es la que despliega el texto del Botón; y tambien puede contener
a otros objetos como son las imágenes.

En el código del ejemplo, veremos como capturar la señal de "clicked" en el
botón, para que cierre la ventana; para lo cual usaremos una función de la
librería de Gtk+; "gtk_widget_destroy".


*/
// Se incluye la librería
#include <gtk/gtk.h>

// Funcion para controlar la Señal de Destrucción
static void SbMainExit(GtkWidget *window, gpointer data)
{
    // Mensaje de que la ventana se ha destruido
    printf("Destroy Signal \n");

    // Llama a la función de la Librería que sale del Ciclo Main
    gtk_main_quit ();
}

// Función para controlar el Cierre de una Ventana
static gboolean FngBoolDeleteEvent(GtkWidget *window, GdkEvent *event)
{
    // Mensaje
    printf("Delete Event\n");

    // Valor de Retorno
    return FALSE;
}

// Función Principal
int main( int argc, char *argv[])
{

  // Objeto para el Widget
  GtkWidget *window,*button;

  // Inicializa la Librería
  gtk_init (&argc, &argv);

  // Crea el Widget con el Objeto declarado
  window = gtk_window_new (GTK_WINDOW_TOPLEVEL);

  // Coloca el Título
  gtk_window_set_title (GTK_WINDOW (window), "07_Contenedores y Botones");

  // Establece el Tamaño por Default
  gtk_window_set_default_size(GTK_WINDOW(window), 400, 400);

  // Establece el Ancho del Borde del Contenedor
  gtk_container_set_border_width (GTK_CONTAINER (window), 50);

  // Controla la Señal de Destrucción del Objeto
  g_signal_connect(G_OBJECT(window), "destroy",G_CALLBACK(SbMainExit), NULL);

  // Controla la Señal del evento "delete_event" de la Ventana-Widget
  g_signal_connect (G_OBJECT (window), "delete_event", G_CALLBACK (FngBoolDeleteEvent), NULL);

  // Crea un botón con su texto
  button = gtk_button_new_with_label("Cerrar");

  // Establece que no use relieve en el borde del Botón
  gtk_button_set_relief (GTK_BUTTON (button), GTK_RELIEF_NONE);

  // Captura la señal del Botón del Click y destruye la Ventana
  //g_signal_connect(G_OBJECT (button), "clicked",G_CALLBACK (gtk_widget_destroy),NULL);
  g_signal_connect_swapped(G_OBJECT (button), "clicked",G_CALLBACK (gtk_widget_destroy),(gpointer) window);

  // Agregamos el Botón al Contenedor
  gtk_container_add (GTK_CONTAINER (window), button);

  // Mostramos el Botón Individualmente
  //gtk_widget_show(button);

  // Mostramos todos los objetos
  gtk_widget_show_all (window);

  // Muestra la Ventana
  gtk_widget_show(window);

  // Ejecuta el Ciclo Principal de la Aplicación
  gtk_main ();

  // Finaliza la Aplicación
  return 0;

}
