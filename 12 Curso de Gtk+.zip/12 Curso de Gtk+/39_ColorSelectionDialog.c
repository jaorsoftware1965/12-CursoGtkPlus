/*

Autor:JAOR
Derechos Reservados: JaorSoftware
http://jaorsoftware.cu.cc/

Curso de Librería Gtk+
Clase 39 - ColorSelectionDialog

En esta clase veremos otro de los diálogos imprescindibles
en un Sistema Operativo Gráfico y que es el que se utiliza
para Seleccionar Color.

La función que se utiliza para mostrar este diálogo es la siguiente:
gtk_color_chooser_dialog_new; la función gtk_color_selection_dialog_new
ya se encuentra descontinuada para esta versión.

*/

// Incluimos la librería
#include <gtk/gtk.h>

// Función CallBack
void SbSelectColor(GtkWidget *widget, gpointer label)
{

  // Variable para el resultado
  GtkResponseType result;

  // Variable para el Color
  GtkColorChooser *colorsel;

  // Crea el Diálogo
  GtkWidget *dialog = gtk_color_chooser_dialog_new("Font Seleccion",NULL);


  // Obtiene el Resultado al ejecutar el diálogo
  result = gtk_dialog_run(GTK_DIALOG(dialog));

  // Verifica la respuesta
  if (result == GTK_RESPONSE_OK)
  {

    // Variable para el Color
    GdkRGBA color;

    // Obtiene el Color desde el diálogo
    colorsel = GTK_COLOR_CHOOSER_DIALOG(GTK_COLOR_CHOOSER_DIALOG(dialog));

    // Coloca el color obtenido en variable GdkColor
    gtk_color_chooser_get_rgba(colorsel,&color);

    // Modifica el Color
    gtk_widget_override_color(GTK_WIDGET(label),GTK_STATE_NORMAL,&color);

  }

  // Destruye el dialogo
  gtk_widget_destroy(dialog);

}


// Función Principal
int main(int argc, char *argv[])
{

  // Crea las variables para los objetos
  GtkWidget *window;
  GtkWidget *widget;
  GtkWidget *label;
  GtkWidget *vbox;
  GtkWidget *toolbar;
  GtkToolItem *btncolor;

  // Inicializa la Librería
  gtk_init(&argc, &argv);

  // Crea la ventana principal y sus características
  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);
  gtk_window_set_default_size(GTK_WINDOW(window), 280, 200);
  gtk_window_set_title(GTK_WINDOW(window), "Clase 39 - Color Selection Dialog");

  // Crea el Contenedor y lo agrega a la Ventana Principal
  vbox = gtk_vbox_new(FALSE, 0);
  gtk_container_add(GTK_CONTAINER(window), vbox);

  // Crea la Barra de Herramientas y define sus características
  toolbar = gtk_toolbar_new();
  gtk_toolbar_set_style(GTK_TOOLBAR(toolbar), GTK_TOOLBAR_ICONS);
  gtk_container_set_border_width(GTK_CONTAINER(toolbar), 2);

  // Crea el Botón para la Barra de Herramientas y lo inserta
  btncolor = gtk_tool_button_new_from_stock(GTK_STOCK_SELECT_COLOR);
  gtk_toolbar_insert(GTK_TOOLBAR(toolbar), btncolor, -1);
  gtk_box_pack_start(GTK_BOX(vbox), toolbar, FALSE, FALSE, 5);

  // Crea la Etiqueta, define sus características y la Inserta
  label = gtk_label_new("JAORSOFTWARE");
  gtk_label_set_justify(GTK_LABEL(label), GTK_JUSTIFY_CENTER);
  gtk_box_pack_start(GTK_BOX(vbox), label, TRUE, FALSE, 5);

  // Asigna la función CallBack al Evento
  g_signal_connect(G_OBJECT(btncolor), "clicked",G_CALLBACK(SbSelectColor), label);

  // Control de al Salida del Programa
  g_signal_connect(G_OBJECT(window), "destroy",G_CALLBACK(gtk_main_quit), NULL);

  // Muestra los objetos
  gtk_widget_show_all(window);

  // Ejecuta el Loop Principal
  gtk_main();

  // Finaliza con 0
  return 0;

}
