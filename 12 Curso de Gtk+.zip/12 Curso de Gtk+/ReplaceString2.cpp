#include <algorithm>
#include <iostream>
#include <string>

using namespace std;

// Función que busca una cadena en otra para reemplazarla
const char *FnStrReplace(const char *source,
                    const char *fromStr,
                    const char *toStr,
                    int   offset,
                    bool  bExacto)
{
  int total = 0;
  string::size_type pos = offset;
  string strSource = source;
  string strFrom   = fromStr;
  string strTo     = toStr;
  string auxSource = source;
  string auxtoStr  = toStr;

  if (bExacto)
  {
     // Ciclo para buscar y reemplazar
     while ( ( (pos = strSource.find(strFrom, pos)) < string::npos) )
     {
          strSource.replace(pos, strFrom.length(), strTo);
          pos+=strTo.size();
     }
     return strSource.c_str();

  }

  else
  {

     // Convierte a mayúscuas
     std::transform(strSource.begin(), strSource.end(),strSource.begin(), ::toupper);
     std::transform(strFrom.begin(), strFrom.end(),strFrom.begin(), ::toupper);
     std::transform(strTo.begin(), strTo.end(),strTo.begin(), ::toupper);

     // Ciclo para buscar y reemplazar
     while ( ( (pos = strSource.find(strFrom, pos)) < string::npos) )
     {
          strSource.replace(pos, strFrom.length(), strTo);
          auxSource.replace(pos, strFrom.length(), auxtoStr);
          pos+=strTo.size();
     }
     return auxSource.c_str();

  }

}

int main()
{
  cout << "Cadena resultante: "<< FnStrReplace("Me voy a dormir, que todos sabemos que dormir es bueno y dormir ayuda a regenerar neuronas. ¡Ay! A partir de las 12 de la noche es hora de dormir.",
          "DORMIR",
          "", 0,false)<<endl;

  return 0;
}
