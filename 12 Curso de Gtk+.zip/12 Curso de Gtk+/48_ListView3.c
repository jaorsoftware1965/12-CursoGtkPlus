/*

Autor    : JAOR
Curso    : Library Gtk+
Clase 48 : ListView III

En esta Clase Veremos un ListView que utiliza mas
de una Columna.

*/

// Se incluye la librería
#include <gtk/gtk.h>

// Enumerado para definir las Columnas
enum
{
    COL_COMPRAR = 0,   // Columna para indicar si se compra el Producto
    COL_CANTIDAD,      // Columna para indicar la Cantidad a comprar
    COL_PRODUCTO,      // Columna con el Nombre del Producto
    COL_MAXIMO         // Número Máximo de Columnas
};


// Estructura para la lista de Compras
typedef struct
{
    gboolean bComprar;    // Si se compra o no
    gint     iCantidad;   // Cantidad a Comprar
    gchar   *sProducto;   // El Nombre del Producto
} ProductosLista;


// Lista de Productos a Comprar
const ProductosLista list[] =
{
    // Comprar, Cantidad, Producto
    {  TRUE   , 1       , "Papel Higiénico" },
    {  TRUE   , 2       , "Pasta Dental" },
    {  FALSE  , 1       , "Sopas de Fideo" },
    {  TRUE   , 1       , "Lata de Frijoles" },
    {  FALSE  , 3       , "Puré de Papa" },
    {  TRUE   , 4       , "Agua Mineral" },
    {  FALSE  , 0       , NULL }
};


// Función para Inicializar el TreeView
static void FnTreeViewInicializa(GtkWidget*);

// Declaración de la Función Principal
int main (int argc, char *argv[])
{
    // Declaración de Variables
    GtkWidget *window,         // Ventana Principal
              *treeview,       // El ListView
              *scrolled_win;   // Para el Scroll
    GtkListStore *store;       // Para la lista de Datos
    GtkTreeIter  iter;         // Item de la Lista
    guint iCuenta = 0;         // Contador

    // Inicializa la librería
    gtk_init (&argc, &argv);

    // Crea una nueva ventana y la configura
    window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title (GTK_WINDOW (window), "Clase 48 - ListView III");
    gtk_container_set_border_width (GTK_CONTAINER (window), 10);
    gtk_widget_set_size_request (window, 250, 175);

    // Crea el treeview
    treeview = gtk_tree_view_new ();

    // Inicializa el treeview
    FnTreeViewInicializa(treeview);

    // Crea el Modelo de Datos con las 3 columnas y sus tipos
    store = gtk_list_store_new (COL_MAXIMO, G_TYPE_BOOLEAN, G_TYPE_INT, G_TYPE_STRING);

    // Añade los Productos a la Lista
    while (list[iCuenta].sProducto != NULL)
    {
        // Añade los datos al ListView
        gtk_list_store_append (store, &iter);
        gtk_list_store_set (store, &iter, COL_COMPRAR , list[iCuenta].bComprar,
                                          COL_CANTIDAD, list[iCuenta].iCantidad,
                                          COL_PRODUCTO, list[iCuenta].sProducto, -1);
        // Incrementa el Contador
        iCuenta++;
    }

    // Añade el modelo al treeview y lo desreferencia
    // para que sean destruidos con el treeview
    gtk_tree_view_set_model (GTK_TREE_VIEW (treeview), GTK_TREE_MODEL (store));
    g_object_unref (store);

    // Crea el Scroll para el TreeView y el establece las reglas de las barras de control
    scrolled_win = gtk_scrolled_window_new (NULL, NULL);
    gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolled_win),GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);

    // Añade el treeview al scrolll
    gtk_container_add (GTK_CONTAINER (scrolled_win), treeview);

    // Añade el scroll a la Ventana
    gtk_container_add (GTK_CONTAINER (window), scrolled_win);

    // Captura la Señal de destrucción de la Ventana Principal
    g_signal_connect (G_OBJECT (window), "destroy",G_CALLBACK(gtk_main_quit), NULL);

    // Muestra todos los elementos de la Ventana
    gtk_widget_show_all (window);

    // Ejecuta el Ciclo Principal
    gtk_main ();

    // Finaliza Retornando 0
    return 0;

}

// Añade las 3 columnas a el GtkTreeView que serán desplegadas como texto
static void FnTreeViewInicializa(GtkWidget *treeview)
{
    // Declaración de las Variables
    GtkCellRenderer   *renderer;
    GtkTreeViewColumn *column;

    // Crea la celda y Crea la columna y la agrega
    renderer = gtk_cell_renderer_text_new ();

    column = gtk_tree_view_column_new_with_attributes ("Comprar", renderer, "text", COL_COMPRAR, NULL);
    gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);

    // Crea la Celda y Crea la columna y la agrega
    renderer = gtk_cell_renderer_text_new ();
    column = gtk_tree_view_column_new_with_attributes("Cantidad", renderer, "text", COL_CANTIDAD, NULL);
    gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);

    // Crea la Celda y Crea la columna y la agrega
    renderer = gtk_cell_renderer_text_new ();
    column = gtk_tree_view_column_new_with_attributes("Producto", renderer, "text", COL_PRODUCTO, NULL);
    gtk_tree_view_append_column (GTK_TREE_VIEW (treeview), column);

}
