/*
Instrucción para Compilar desde la Terminal
g++ testGtk.cpp -I/mingw64/include/gtk-3.0 -I/mingw64/include/glib-2.0
                -I/mingw64/lib/glib-2.0/include -I/mingw64/include/pango-1.0
                -I/mingw64/include/cairo
                -I/mingw64/include/gdk-pixbuf-2.0 -I/mingw64/include/atk-1.0
                `pkg-config --cflags --libs  gtk+-3.0`
g++ testGtk.cpp -Ic:/msys64/mingw64/include/gtk-3.0 
				-Ic:/msys64/mingw64/include/glib-2.0 
				-Ic:/msys64/mingw64/lib/glib-2.0/include 
				-Ic:/msys64/mingw64/include/pango-1.0 
				-Ic:/msys64/mingw64/include/cairo 
				-Ic:/msys64/mingw64/include/gdk-pixbuf-2.0 
				-Ic:/msys64/mingw64/include/atk-1.0 
				`c:/msys64/mingw64/bin/pkg-config --cflags --libs  gtk+-3.0`
				
				
g++ testGtk.cpp -I/mingw64/include/gtk-3.0 -Imingw64/include/glib-2.0 -I/mingw64/lib/glib-2.0/include -I/mingw64/include/pango-1.0 -I/mingw64/include/cairo -I/mingw64/include/gdk-pixbuf-2.0 -I/mingw64/include/atk-1.0 `pkg-config --cflags --libs  gtk+-3.0`
*/
#include "stdio.h"
#include "gtk/gtk.h"

int main(int argc, char *argv[])
{
  // Definimos una variable de Tipo GtkWidget
  GtkWidget *window;

  // Iniciamos la Libreria Gtk
  gtk_init(&argc, &argv);

  // Creamos una ventana utilizando la Variable del Tipo GtkWidget
  // Llamando a la función gtk_window_new
  // El Tamaño default es 200 x 200
  // Solo toma otro parámetro: GTK_WINDOW_POPUP
  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);

  // Mostramos la Ventana con la función gtk_widget_show
  gtk_widget_show(window);

  // Coloca el Título de la Ventana
  gtk_window_set_title(GTK_WINDOW (window), "01_Primer Aplicación");


  // Coloca a la Ventana en un ciclo en donde intercepta eventos
  gtk_main();


  return 0;
}
