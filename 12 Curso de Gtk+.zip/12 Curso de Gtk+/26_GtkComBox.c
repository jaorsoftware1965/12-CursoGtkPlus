/*

Curso de Programación con Gtk+
Autor:JAOR
Derechos Reservados: JaorSoftware
www.jaorsoftware.com

Clase 26 - ComboBox

El ComboBox es uno de los Controles Básicos por Excelencia
de cualquiera Interfaz Gráfica.

Presenta un conjunto de opciones, de las cuales permite seleccionar
una de ellas.

La función para crear el objeto es la siguiente:

gtk_combo_box_text_new()

Una vez que el objeto es creado, es posible agregarle elementos
utilizando las siguientes funciones:

gtk_combo_box_text_append. Añade el Elemento al Final.
gtk_combo_box_text_prepend_text. Añade el Elemento al Inicio.
gtk_combo_box_text_insert_text. Añade en la posición que se indique.

Para seleccionar una de las opciones del ComboBox se utiliza:
gtk_combo_box_set_active

Para obtener el elemento Seleccionado se utiliza la función:
gtk_combo_box_get_active

Para obtener el texto del elemento activo se utiliza:
gtk_combo_box_text_get_active_text

Para eliminar un elemento del Combo, se utiliza la función:
gtk_combo_box_text_remove

*/

// Incluye la Librería
#include <gtk/gtk.h>

/* Función para cuando se selecciona un Elemento del Combo */
static void SbComboCambio( GtkComboBoxText *combo )
{
    /* Obtiene el Texto de la opción seleccionada */
    gchar *string = gtk_combo_box_text_get_active_text( combo );

    /* Imprime a la Consola el elemento Seleccionado */
    g_print( "Has Seleccionado la opción: >> %s <<\n", ( string ? string : "NULL" ) );

    /* Libera la Cadena */
    g_free( string );
}

/* Funcion que elimina el Elemento Seleccionado */
static void SbComboEliminarElemento( GtkButton   *button, GtkComboBox *combo )
{
    // Variable para obtener el índice del  Elemento
    gint index;

    /* Obtiene el Elemento Seleccionado */
    index = gtk_combo_box_get_active( combo );

    // Verifica que sea mayor que 0
    if (index>=0)
       /* Elimino el Elemento correspondiente al Indice */
       gtk_combo_box_text_remove( combo, index );
    else
       g_print("Debe Seleccionar el Elemento a borrar");
}

// Función principal
int main_26( int    argc,char **argv )
{
    /*Declaración de variables */
    GtkWidget *window;
    GtkWidget *vbox;
    GtkWidget *frame;
    GtkWidget *combo;
    GtkWidget *button;

    /* Inicializa la Librería */
    gtk_init( &argc, &argv );

    /* Crea la Ventana Principal */
    window = gtk_window_new( GTK_WINDOW_TOPLEVEL );

    // Asocia el evento destroy de la ventana principal */
    g_signal_connect( G_OBJECT( window ), "destroy", G_CALLBACK( gtk_main_quit ), NULL );

    // Establece el borde de la ventana
    gtk_container_set_border_width( GTK_CONTAINER( window ), 10 );

    /* Crea un vbox */
    vbox = gtk_vbox_new( FALSE, 6 );

    // Lo agrega a la ventana principal */
    gtk_container_add( GTK_CONTAINER( window ), vbox );

    /* Crea el frame */
    frame = gtk_frame_new( "Seleccione:" );

    // Lo agrega al vbox
    gtk_box_pack_start( GTK_BOX( vbox ), frame, FALSE, FALSE, 0 );

    /* Creat el combo box */
    combo = gtk_combo_box_text_new();

    // Agrega el combo al Frame
    gtk_container_add( GTK_CONTAINER( frame ), combo );

    // Agrega elementos al Combo
    gtk_combo_box_text_append(GTK_COMBO_BOX( combo ),NULL, "Opcion 1 con Append" );
    gtk_combo_box_text_append(GTK_COMBO_BOX( combo ),NULL, "Opcion 2 con Append" );
    gtk_combo_box_text_prepend_text( GTK_COMBO_BOX( combo ), "Opcion 3 con Prepend" );
    gtk_combo_box_text_insert_text( GTK_COMBO_BOX( combo ), 2, "Opcion 4 con Insert" );
    gtk_combo_box_text_prepend_text( GTK_COMBO_BOX( combo ), "Opcion 5 con Prepend" );

    // Selecciona un elemento del Combo
    gtk_combo_box_set_active(GTK_COMBO_BOX( combo ),2);//-1 para No seleccionar
    gtk_combo_box_set_active(GTK_COMBO_BOX( combo ),-1);//-1 para No seleccionar

    /* Conecta la señal changed del Combo */
    g_signal_connect( G_OBJECT( combo ), "changed",G_CALLBACK(SbComboCambio), NULL );

    /* Agregamos un Botón para Eliminar la Selección */
    button = gtk_button_new_with_mnemonic( "_Eliminar el Item Seleccionado" );

    // Agregamos el Botón al BOX
    gtk_box_pack_start( GTK_BOX( vbox ), button, FALSE, FALSE, 0 );

    // Asociamos la señal de Click del Combo a la Función CallBack
    g_signal_connect( G_OBJECT( button ), "clicked",G_CALLBACK(SbComboEliminarElemento ), GTK_COMBO_BOX( combo ) );

    /* Se muestran los objetos dentro de la Ventana */
    gtk_widget_show_all( window );

    // Ejecuta el Loop Principal
    gtk_main();

    // Finaliza la Aplicación
    return( 0 );

}
