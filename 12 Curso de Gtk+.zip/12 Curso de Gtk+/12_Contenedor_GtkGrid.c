/*

Curso de Programación con Gtk+
Autor:JAOR
Derechos Reservados: JaorSoftware
www.jaorsoftware.cc.cu

Clase 12_Contenedor GtkGrid

El Contenedor GtkGrid es un Contenedor similar a GtkTable,
con el cual se pueden obtener los mismos resultados; solo
que la lógica para agregar a los elementos es distinta.

Inicialmente, no se establece cuantos renglones o columnas
tendrá; y esto se va estableciendo al momento en que se
van agregando elementos.

*/

// Incluimos la Librería
#include <gtk/gtk.h>

// Función Principal
int main(int argc, char *argv[])
{

  GtkWidget *wgtAplicacion;     // El Objeto de la Ventana Principal
  GtkWidget *gtkgrdContenedor;  // Contenedor GtkGrid
  GtkWidget *butTecla1;         // Teclas
  GtkWidget *butTecla2;         // Teclas
  GtkWidget *butTecla3;         // Teclas
  GtkWidget *butTecla4;         // Teclas
  GtkWidget *butTecla5;         // Teclas
  GtkWidget *butTecla6;         // Teclas

  // Inicializa la Aplicación
  gtk_init(&argc, &argv);

  // Crea la Ventana Principal
  wgtAplicacion = gtk_window_new(GTK_WINDOW_TOPLEVEL);

  // Centra la Ventana
  gtk_window_set_position(GTK_WINDOW(wgtAplicacion), GTK_WIN_POS_CENTER);

  // Define su tamaño
  gtk_window_set_default_size(GTK_WINDOW(wgtAplicacion), 350, 350);

  // Establece el Título
  gtk_window_set_title(GTK_WINDOW(wgtAplicacion), "Clase 12_Contenedor GtkGrid");

  // Establece un Borde
  gtk_container_set_border_width(GTK_CONTAINER(wgtAplicacion), 5);

  // Crea el Botón para las teclas
  butTecla1 = gtk_button_new_with_label("Botón1");

  // Crea el Botón para las teclas
  butTecla2 = gtk_button_new_with_label("Botón2");

  // Crea el Botón para las teclas
  butTecla3 = gtk_button_new_with_label("Botón3");

  // Crea el Botón para las teclas
  butTecla4 = gtk_button_new_with_label("Botón4");

  // Crea el Botón para las teclas
  butTecla5 = gtk_button_new_with_label("Botón5");

  // Crea el Botón para las teclas
  butTecla6 = gtk_button_new_with_label("Botón6");

  // Crea el Contenedor Grid
  gtkgrdContenedor = gtk_grid_new();
  //-----------
  GdkRGBA font_color; //A2

  // Establece el Color A2
  font_color.red = 1;
  font_color.green = 1;
  font_color.blue = 0;
  font_color.alpha = 1;
  gtk_widget_override_background_color(gtkgrdContenedor, GTK_STATE_FLAG_NORMAL, &font_color);


  //------------------
  // Establece que los botones sean del mismo tamaño y que se ajusten a su contenedor
  gtk_grid_set_column_homogeneous (gtkgrdContenedor,TRUE);
  gtk_grid_set_row_homogeneous (gtkgrdContenedor,TRUE);

   // 0        1         2         3
  // ------------------------------   0
  // |        |         |         |
  // ------------------------------   1
  // |        |         |         |
  // ------------------------------   2
  // |        |         |         |
  // ------------------------------   3

  //void gtk_grid_attach (GtkGrid *grid, GtkWidget *child, gint left, gint top, gint width, gint height);
  //void gtk_grid_attach_next_to (GtkGrid *grid, GtkWidget *child, GtkWidget *sibling, GtkPositionType side,gint width,gint height);

  // Agrega los Botones
  gtk_container_add(GTK_CONTAINER(gtkgrdContenedor),butTecla1);
  gtk_grid_attach(GTK_GRID(gtkgrdContenedor), butTecla2, 1, 0, 2, 1);
  gtk_grid_attach_next_to(GTK_GRID(gtkgrdContenedor),butTecla3,butTecla1,GTK_POS_BOTTOM,1,2);
  gtk_grid_attach_next_to(GTK_GRID(gtkgrdContenedor),butTecla4,butTecla3,GTK_POS_RIGHT,2,1);
  gtk_grid_attach(GTK_GRID(gtkgrdContenedor), butTecla5, 1, 2, 1, 1);
  gtk_grid_attach_next_to(GTK_GRID(gtkgrdContenedor),butTecla6,butTecla5,GTK_POS_RIGHT,2,2);

  // Añade el Contenedor a la Ventana Principal
  gtk_container_add(GTK_CONTAINER(wgtAplicacion), gtkgrdContenedor);

  // Captura la Señal para destruir el Objeto
  g_signal_connect_swapped(G_OBJECT(wgtAplicacion), "destroy",G_CALLBACK(gtk_main_quit), G_OBJECT(wgtAplicacion));

  // Muestra todos los objetos de la Aplicación
  gtk_widget_show_all(wgtAplicacion);

  // Ciclo Principal
  gtk_main();

  return 0;
}



