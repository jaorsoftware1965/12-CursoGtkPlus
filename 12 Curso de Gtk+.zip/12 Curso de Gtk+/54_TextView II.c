/*

Autor    : JAOR
Curso    : Library Gtk+
Clase 54 : TextView II

En esta clase continuaremos viendo el uso
del TextView.

Veremos como establecer la fuente, el espacio
entre líneas, márgenes, y demás.

*/

// Incluímos la librería
#include <gtk/gtk.h>

// Función Principal
int main (int argc,char *argv[])
{
   // Declaración de Variables
   GtkWidget *window,          // Ventana Principal
             *scrolled_win,    // Scroll
             *textview;        // El TextView
   GtkTextBuffer *buffer;      // El Buffer para el TextView
   PangoFontDescription *font; // Para controlar la Fuente

   // Iniciamos la librería
   gtk_init (&argc, &argv);

   // Creamos y Configuramos la Librería
   window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
   gtk_window_set_title (GTK_WINDOW (window), "Clase 54 - TextView II");
   gtk_container_set_border_width (GTK_CONTAINER (window), 10);
   gtk_widget_set_size_request (window, 250, 150);

   // Establecemos la Fuente
   font = pango_font_description_from_string ("Monospace Bold 10");

   // Creamos el TextView
   textview = gtk_text_view_new ();

   // Modificamos la Fuente
   gtk_widget_modify_font (textview, font);

   // Establecemos el wrap
   gtk_text_view_set_wrap_mode (GTK_TEXT_VIEW (textview), GTK_WRAP_WORD);

   // Se indica la justificación del Texto
   gtk_text_view_set_justification (GTK_TEXT_VIEW (textview), GTK_JUSTIFY_RIGHT);

   // Se indica si es editable o no
   gtk_text_view_set_editable (GTK_TEXT_VIEW (textview), TRUE);

   // Se indica si es visible el cursor
   gtk_text_view_set_cursor_visible (GTK_TEXT_VIEW (textview), TRUE);

   // El espacio en pixeles del Margen Superior
   gtk_text_view_set_pixels_above_lines (GTK_TEXT_VIEW (textview), 5);

   // El espacio despues del Enter
   gtk_text_view_set_pixels_below_lines (GTK_TEXT_VIEW (textview), 0);
   gtk_text_view_set_pixels_above_lines (GTK_TEXT_VIEW (textview), 0);

   // El espacio cuando realiza el cambio de linea porque ya no hay espacio
   gtk_text_view_set_pixels_inside_wrap (GTK_TEXT_VIEW (textview), 5);

   // El Margen Izquierdo
   gtk_text_view_set_left_margin (GTK_TEXT_VIEW (textview), 10);

   // El Margen Derecho
   gtk_text_view_set_right_margin (GTK_TEXT_VIEW (textview), 10);

   // Obtener la referencia del Buffer del TextView
   buffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (textview));

   // Insertamos el Text
   gtk_text_buffer_set_text (buffer, "En un lugar de Youtube \ndel Cual no puedo acordarme\nhabía un ingenioso ...", -1);

   // Creamos el Scroll y establecemos como se controlará las barras de desplazamiento
   scrolled_win = gtk_scrolled_window_new (NULL, NULL);
   gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolled_win),GTK_POLICY_AUTOMATIC, GTK_POLICY_ALWAYS);
   gtk_container_add (GTK_CONTAINER (scrolled_win), textview);

   // Agregamos el Scroll al contenedor
   gtk_container_add (GTK_CONTAINER (window), scrolled_win);

   // Mostramos todos los objetos de la Ventana
   gtk_widget_show_all (window);

   // Iniciamos el Ciclo Principal
   gtk_main();

   // Finalizamos Retornando 0
   return 0;
}
