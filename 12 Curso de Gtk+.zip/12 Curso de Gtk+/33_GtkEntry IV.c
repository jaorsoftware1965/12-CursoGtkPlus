/*

Curso de Programación con Gtk+
Autor:JAOR
Derechos Reservados: JaorSoftware
www.jaorsoftware.com

Clase 33 - GtkEntry IV

En esta clase, veremos como insertar un texto en un objeto
entry, utilizando la siguiente función: gtk_entry_set_text

Tambien veremos como eliminar texto del objeto entry, utilizando
la función: gtk_editable_delete_text

Y por ultimo, veremos como seleccionar texto del objeto entry,
utilizando la función: gtk_editable_select_region

*/

// Incluímos la Librería
#include <gtk/gtk.h>

// Función para Ejecutar cuando se Presiona enter en el GtkEntry */
static void SbEntryKeyPress (GtkEntry *entry)
{
    // Variable para la longitud del texto
    gint16 giLongitud;

    // Variable para obtener el texto
    gchar *gstrTexto;

    // Mensaje de que se ha presiona el Enter
    g_print( "Has presionado Enter \n" );

    // Obtiene la Longitud del Mensaje
    giLongitud = gtk_entry_get_text_length(entry);

    // Mensaje de que se ha presiona el Enter
    g_print( "La longitud es: %d \n",giLongitud );

    // Obtiene el texto del Password
    gstrTexto = gtk_entry_get_text (entry);

    // Mensaje con el contenido del Password
    g_print( "El Password es: %s \n",gstrTexto);

    // Selecciona una parte del Texto
    gtk_editable_select_region(GTK_ENTRY (entry),2,6);

}

// Función Principal
int main_33 (int argc,char *argv[])
{

    // Define las variables para los objetos
    GtkWidget *window,
              *vbox,
              *hbox,
              *lblPregunta,
              *lblMensaje,
              *entPassword;

    // Inicializa la librería
    gtk_init (&argc, &argv);

    // Crea la Ventana
    window = gtk_window_new (GTK_WINDOW_TOPLEVEL);

    // Establece el Título de la Ventana
    gtk_window_set_title (GTK_WINDOW (window), "Clase 33 - GtkEntry IV");

    // Establece el Borde
    gtk_container_set_border_width (GTK_CONTAINER (window), 10);

    // Crea la cadena para la pregunta del Password
    gchar *str = g_strconcat ("Capture el Password y Presione Enter", NULL);

    // Crea la Etiqueta
    lblPregunta = gtk_label_new (str);

    // Crea la etiqueta para el Password
    lblMensaje = gtk_label_new ("Password:");

    /* Creamos el GtkEntry */
    entPassword = gtk_entry_new ();
    gtk_entry_set_visibility (GTK_ENTRY (entPassword), FALSE);
    gtk_entry_set_invisible_char (GTK_ENTRY (entPassword), '?');

    // Escribe un Texto determinado
    gtk_entry_set_text(GTK_ENTRY (entPassword),"otrotexto");

    // Elimina
    gtk_editable_delete_text(GTK_ENTRY (entPassword),1,3);

    // Crea el hbox
    hbox = gtk_hbox_new (FALSE, 5);

    // Agrega la etiqueta y el entry al Contenedor
    gtk_box_pack_start (GTK_BOX (hbox), lblMensaje, FALSE,FALSE,0);
    gtk_box_pack_start (GTK_BOX (hbox), entPassword, FALSE,FALSE,0);

    // Crea el vbox
    vbox = gtk_vbox_new (FALSE, 5);

    // Agrega los Objetos al Contenedor vbox
    gtk_box_pack_start (GTK_BOX (vbox), lblPregunta, FALSE,FALSE,0);
    gtk_box_pack_start (GTK_BOX (vbox), hbox, FALSE,FALSE,0);

    // Agrega el vbox a la ventana
    gtk_container_add (GTK_CONTAINER (window), vbox);

    // Asocia la Señal "activate" a la Función SbEntryKeyPress
    g_signal_connect (G_OBJECT (entPassword), "activate",G_CALLBACK (SbEntryKeyPress),NULL);

    // Asocia el evento destroy de la ventana principal */
    g_signal_connect( G_OBJECT( window ), "destroy", G_CALLBACK( gtk_main_quit ), NULL );

    // Muestra los Objetos
    gtk_widget_show_all (window);

    // El Ciclo Principal
    gtk_main ();

    // Finaliza Retornando 0
    return 0;
}


