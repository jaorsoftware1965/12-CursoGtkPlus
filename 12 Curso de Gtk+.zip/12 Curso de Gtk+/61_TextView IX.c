/*

Autor    : JAOR
Curso    : Library Gtk+
Clase 61 : TextView IX - Clase Final

Insertando una Imagen en el TextView

*/

// Incluimos la Librería
#include <gtk/gtk.h>

// Define 2 constantes
#define IMAGE_UNDO "bin/undo.png"
#define IMAGE_REDO "bin/redo.png"

// Función Principal
int main (int argc,char *argv[])
{
    // Definición de Variables
    GtkWidget     *window,
            *scrolled_win,
                *textview;
    GdkPixbuf       *undo,
                    *redo;
    GtkTextIter      line;
    GtkTextBuffer *buffer;

    // Inicializa la Librería
    gtk_init (&argc, &argv);

    // Crea la Ventana Principal
    window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title (GTK_WINDOW (window), "Clase 61 - TextView IX");
    gtk_container_set_border_width (GTK_CONTAINER (window), 10);
    gtk_widget_set_size_request (window, 200, 150);

    // Crea el TextView
    textview = gtk_text_view_new ();
    buffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (textview));
    gtk_text_buffer_set_text (buffer, "Undo\n\n\n Redo", -1);

    // Creamos la Imagen del Undo
    undo = gdk_pixbuf_new_from_file (IMAGE_UNDO, NULL);
    // Creamos un Iter en la linea deseada y lo insertamos
    gtk_text_buffer_get_iter_at_line (buffer, &line, 0);
    gtk_text_buffer_insert_pixbuf (buffer, &line, undo);

    // Creamos la Imagen del Undo
    redo = gdk_pixbuf_new_from_file (IMAGE_REDO, NULL);
    // Creamos un Iter en la linea deseada y lo insertamos
    gtk_text_buffer_get_iter_at_line (buffer, &line, 3);
    gtk_text_buffer_insert_pixbuf (buffer, &line, redo);

    // Creamos el Scroll
    scrolled_win = gtk_scrolled_window_new (NULL, NULL);

    // Agregamos el TextView al Scroll
    gtk_container_add (GTK_CONTAINER (scrolled_win), textview);

    // Agregamos el Scroll a la Ventana Principal
    gtk_container_add (GTK_CONTAINER (window), scrolled_win);

    // Mostramos todos los objetos
    gtk_widget_show_all (window);

    // Ejecutamos el Ciclo Principal
    gtk_main();

    // Finalizamos Retornando 0
    return 0;

}
