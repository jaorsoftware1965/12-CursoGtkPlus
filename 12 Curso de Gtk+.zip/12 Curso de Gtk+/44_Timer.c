/*

Autor:JAOR
Derechos Reservados: JaorSoftware

Curso de Librería Gtk+
Clase 44 - Timer

En la Clase de hoy veremos un recurso que es muy importante
en el desarrollo de aplicaciones y que son los timer.

Un objeto timer permite controlar el tiempo que
ha transcurrido entre 2 tiempos.

Para crear un objeto timer, haremos uso de la Clase
GTimer; y de la función g_timer_new.

Para calcular e iniciar el timer, haremos uso de la
función g_timer_elapsed

*/

// Incluimos la Librería
#include <gtk/gtk.h>

// Se declara función CallBack que se ejecuta al
// presionar el Botón
static void SbBotonPresionado(GtkButton*, GTimer*);

// Función Principal
int main (int argc,char *argv[])
{
    // Variables para la Ventana y el Botón
    GtkWidget *window, *button;

    // Variable para el timer
    GTimer *timer;

    // Inicializa la librería
    gtk_init (&argc, &argv);

    // Crea la Ventana Nueva y define característica
    window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title (GTK_WINDOW (window), "Clase 44 - Timer");
    gtk_container_set_border_width (GTK_CONTAINER (window), 10);
    gtk_widget_set_size_request (window, 250, 75);

    // Inicializa el Timer
    timer = g_timer_new ();

    // Crea un butón
    button = gtk_button_new_with_label ("Iniciar el Timer");

    // Define la Captura de la Señal del Botón
    g_signal_connect (G_OBJECT (button), "clicked",G_CALLBACK (SbBotonPresionado),(gpointer) timer);

    // Añade el Botón al Contenedor Principal que es la Ventana
    gtk_container_add (GTK_CONTAINER (window), button);

    // Muestra todas las Ventanas
    gtk_widget_show_all (window);

    // Ejecuta el Ciclo Principal
    gtk_main ();

    // Finaliza con 0
    return 0;

}

// Función que Cuenta la cantidad de tiempo transcurrido
// entre la presión de 2 botones
static void SbBotonPresionado(GtkButton *button,GTimer *timer)
{
    // Variables para el Conteo del Tiempo
    static gdouble tiempo_inicial = 0.0;
    static gdouble tiempo_final   = 0.0;

    // Variable para saber si se está ejecutando ya el timer
    static gboolean bTimerEnEjecucion = FALSE;

    // Verifica si el timer No está en ejecución
    if (!bTimerEnEjecucion)
    {
        // Si No está en ejecución obtiene el timer inicial
        tiempo_inicial = g_timer_elapsed (timer, NULL);

        // Cambia la etiqueta
        gtk_button_set_label (button, "Detener el Timer");
    }
    else
    {
        // Si está en ejecución obtiene el timer final
        tiempo_final = g_timer_elapsed (timer, NULL);

        // Cambia la etiqueta para indicar que se Inicie el Timer
        gtk_button_set_label (button, "Iniciar el Timer");

        // Despliega el tiempo transcurrido
        g_print ("Tiempo Transcurrido: %.2f\n", tiempo_final - tiempo_inicial);
    }

    // Cambia el Estado de la Variable de Ejecución
    bTimerEnEjecucion = !bTimerEnEjecucion;
}
