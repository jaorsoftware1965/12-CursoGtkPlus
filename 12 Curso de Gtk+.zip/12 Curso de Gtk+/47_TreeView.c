/*

Autor    : JAOR
Company  : JaorSoftware
Curso    : Library Gtk+
Clase 47 : TreeView


En esta clase veremos ya un uso de la Clase GtkTreeView,
orientada a mostrar un objeto como tal y como el nombre de la
clase lo indica.

*/

// Incluye la librería
#include <gtk/gtk.h>

enum {
  COLUMNA_NUM = 0,
  COLUMNA_MAX = 1
};

// Función para Cuando cambia la Selección
void FnTreeViewChanged(GtkWidget *widget, gpointer statusbar)
{

  // Declaración de Variables
  GtkTreeIter iter;    // Item
  GtkTreeModel *model; // Modelo de Datos
  gchar *value;        // Para el Valor Seleccionado


  // Verifica que esté seleccionado un Elemento
  if (gtk_tree_selection_get_selected(GTK_TREE_SELECTION(widget), &model, &iter))
  {

    // Obtiene el valor
    gtk_tree_model_get(model, &iter, COLUMNA_NUM, &value,  -1);

    // Coloca el Valor Obtenido
    gtk_statusbar_push(GTK_STATUSBAR(statusbar),
                       gtk_statusbar_get_context_id(GTK_STATUSBAR(statusbar),value),
                       value);

    // Remueve el Item Seleccionado
    //gtk_tree_store_remove (GTK_TREE_STORE(model),&iter);

    // Libera la Memoria
    g_free(value);
  }


}


// Función que crea el TreeView
GtkTreeModel *FnCreateTreeView(void)
{

  // Variables
  GtkTreeStore *treestore;     // Para colocar los datos
  GtkTreeIter toplevel, child; // Para items

  // Crea un nuevo elemento
  treestore = gtk_tree_store_new(COLUMNA_MAX,G_TYPE_STRING);

  // Agrega un elemento vacío
  gtk_tree_store_append(treestore, &toplevel, NULL);

  // Coloca el Dato en el elemento
  gtk_tree_store_set(treestore, &toplevel,COLUMNA_NUM, "Web",-1);

  // Añade el un hijo al toplevel
  gtk_tree_store_append(treestore, &child, &toplevel);

  // Establece el Valor del Child
  gtk_tree_store_set(treestore, &child,COLUMNA_NUM, "Python",-1);

  // Agrega como hijo del toplevel
  gtk_tree_store_append(treestore, &child, &toplevel);
  // Establece otro valor y lo agrega
  gtk_tree_store_set(treestore, &child,COLUMNA_NUM, "Perl",-1);

  // Agrega otro elemento
  gtk_tree_store_append(treestore, &child, &toplevel);
  // Establece otro valor
  gtk_tree_store_set(treestore, &child,COLUMNA_NUM, "PHP",-1);

  // Lo Agrega
  gtk_tree_store_append(treestore, &toplevel, NULL);

  // Establece otro primer nivel y lo añade
  gtk_tree_store_set(treestore, &toplevel,COLUMNA_NUM, "Desktop",-1);

  // Establece otro valor y lo agrega
  gtk_tree_store_append(treestore, &child, &toplevel);

  // Agrega un Hijo
  gtk_tree_store_set(treestore, &child,COLUMNA_NUM, "C",-1);

  // Establece otro valor y lo agrega
  gtk_tree_store_append(treestore, &child, &toplevel);
  gtk_tree_store_set(treestore, &child,COLUMNA_NUM, "C++",-1);

  // Establece otro valor y lo agrega
  gtk_tree_store_append(treestore, &child, &toplevel);
  gtk_tree_store_set(treestore, &child,COLUMNA_NUM, "Java",-1);

  // Retorna el TreeView
  return GTK_TREE_MODEL(treestore);

}


// Función para crear la Vista y el Modelo
GtkWidget *FnCreaVistaModelo(void)
{

  // Declara las variables a utilizar
  GtkTreeViewColumn *col;    // Variable para Columna
  GtkCellRenderer *renderer; // Variable para Celda
  GtkWidget *view;           // Variable para la Vista
  GtkTreeModel *model;       // Variable para el Modelo

  // Crea el treeview
  view = gtk_tree_view_new();

  // Crea la Columna
  col = gtk_tree_view_column_new();

  // Establece el Nombre de la Columna y la Agrega al TreeView
  gtk_tree_view_column_set_title(col, "Lenguajes de Programación");
  gtk_tree_view_append_column(GTK_TREE_VIEW(view), col);

  // Crea la Celda
  renderer = gtk_cell_renderer_text_new();

  // Establece la Columna y su atributo
  gtk_tree_view_column_pack_start(col, renderer, TRUE);
  gtk_tree_view_column_add_attribute(col, renderer,"text", COLUMNA_NUM);

  // Crea el TreeView
  model = FnCreateTreeView();

  // Establece el Modelo en el treeview
  gtk_tree_view_set_model(GTK_TREE_VIEW(view), model);

  // Indica que se destruya con el Modelo
  g_object_unref(model);

  // Retorna el Control
  return view;

}


// Función Principal
int main(int argc, char *argv[])
{

  // Declaración de Variables
  GtkWidget *window;            // Ventana Principal
  GtkWidget *view;              // Para el treeview
  GtkTreeSelection *selection;  // Para controlar el treeview
  GtkWidget *vbox;              // El Contenedor
  GtkWidget *statusbar;         // Para la Barra de Estado

  // Inicializa la Librería
  gtk_init(&argc, &argv);

  // Configura la Ventana Principal
  window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);
  gtk_window_set_title(GTK_WINDOW(window), "Clase 47 - Tree view");
  gtk_widget_set_size_request(window, 350, 300);

  // Crea el Contenedor y lo agrega a la Ventana Principal
  vbox = gtk_vbox_new(FALSE, 2);
  gtk_container_add(GTK_CONTAINER(window), vbox);

  // Crea la Vista y Modelo
  view = FnCreaVistaModelo();

  // Obtine el Control sobre la Selección del TreeView
  selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(view));

  // Coloca los elementos en el contenedor
  gtk_box_pack_start(GTK_BOX(vbox), view, TRUE, TRUE, 1);

  // Crea la Barra de Estado y la Agrega al Contenedor vbox
  statusbar = gtk_statusbar_new();
  gtk_box_pack_start(GTK_BOX(vbox), statusbar, FALSE, TRUE, 1);


  // Captura la Señal de Changed de la Selección del Treevieww
  g_signal_connect(selection, "changed",G_CALLBACK(FnTreeViewChanged), statusbar);

  // Captura la Señal de destrucción de la Ventana Principal
  g_signal_connect (G_OBJECT (window), "destroy",G_CALLBACK(gtk_main_quit), NULL);

  // Muestra todos los Widgets
  gtk_widget_show_all(window);

  // Ejecuta el Ciclo Principal
  gtk_main();

  // Finaliza Retornando 0
  return 0;

}
