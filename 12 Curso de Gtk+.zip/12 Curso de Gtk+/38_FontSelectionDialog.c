/*

Autor:JAOR
Derechos Reservados: JaorSoftware
http://jaorsoftware.cu.cc/

Curso de Librería Gtk+
Clase 38 - SelectionFontDialog


En esta clase veremos otro de los diálogos imprescindibles
en un Sistema Operativo Gráfico y que es el que se utiliza
para Seleccionar una Fuente del Sistema.

La función que se utiliza para activar el diálogo para la
selección de la fuente es: gtk_font_selection_dialog_new
la cual, en caso de que el usuario haya seleccionado una,
devuelve información con respecto a la fuente seleccionada.


*/

// Incluye la Librería
#include <gtk/gtk.h>

// Función para Seleccionar la Fuente
void SbFontSeleccion(GtkWidget *widget, gpointer label)
{

  // Variable para obtener la Respuesta
  GtkResponseType result;

  // Ejecuta la Seleccion del Dilogo de Fuente
  GtkWidget *dialog = gtk_font_selection_dialog_new("Seleciona la Fuente");

  // Ejecuta el Diálogo
  result = gtk_dialog_run(GTK_DIALOG(dialog));

  // Verifica lo que el usuario seleccionó
  if (result == GTK_RESPONSE_OK || result == GTK_RESPONSE_APPLY)
  {

     // Declara una variable del Tipo PangoFontDescription
     PangoFontDescription *font_desc;

     // Obtiene la Fuente Seleccionada por el Usuario
     gchar *fontname = gtk_font_selection_dialog_get_font_name(GTK_FONT_SELECTION_DIALOG(dialog));

     // Despliega la Fuente Seleccionada
     g_print("Fuente Seleccionada:%s \n",fontname);

     // Obtiene la Descripción de la Fuente
     font_desc = pango_font_description_from_string(fontname);

     // Modifica la Fuente de la Etiqueta
     gtk_widget_modify_font(GTK_WIDGET(label), font_desc);

     // Libera la Memoria
     g_free(fontname);

   }

   // Destruye la Memoria del Diálogo
   gtk_widget_destroy(dialog);

}

// Función Principal de la Aplicación
int main(int argc, char *argv[])
{

   // Declaración de las Variables para los Objetos
   GtkWidget   *window;
   GtkWidget   *label;
   GtkWidget   *vbox;
   GtkWidget   *toolbar;

   // Variable para la Fuente
   GtkToolItem *font;

   // Inicializa la Librería
   gtk_init(&argc, &argv);

   // Crea la Ventana de la Aplicación y define sus Características
   window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
   gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);
   gtk_window_set_default_size(GTK_WINDOW(window), 280, 200);
   gtk_window_set_title(GTK_WINDOW(window), "Clase 38 - Font Selection Dialog");

   // Crea el Contenedor y lo agrega a la Ventana Principal
   vbox = gtk_vbox_new(FALSE, 0);
   gtk_container_add(GTK_CONTAINER(window), vbox);

   // Crea una barra de herramientas
   toolbar = gtk_toolbar_new();

   // Establece el Estilo de la Barra
   gtk_toolbar_set_style(GTK_TOOLBAR(toolbar), GTK_TOOLBAR_ICONS);

   // Establece el Borde de la Barra de Herramientas
   gtk_container_set_border_width(GTK_CONTAINER(toolbar), 2);

   // Crea un botó nuevo desde el Stock
   font = gtk_tool_button_new_from_stock(GTK_STOCK_SELECT_FONT);

   // Inserta el Botón en la Barra de Herramientas
   gtk_toolbar_insert(GTK_TOOLBAR(toolbar), font, -1);

   // Inserta la Barra de Herramientas en el contenedor
   gtk_box_pack_start(GTK_BOX(vbox), toolbar, FALSE, FALSE, 5);

   // Crea la Etiqueta
   label = gtk_label_new("JaorSoftware");

   // Justifica la Etiqueta al Centro
   gtk_label_set_justify(GTK_LABEL(label), GTK_JUSTIFY_CENTER);

   // Agrega la Etiqueta al Contenedor
   gtk_box_pack_start(GTK_BOX(vbox), label, TRUE, FALSE, 5);

   // Captura la Señal clicked del Botón
   g_signal_connect(G_OBJECT(font), "clicked",G_CALLBACK(SbFontSeleccion), label);

   // Captura la Señal del Cierre de la Ventana
   g_signal_connect(G_OBJECT(window), "destroy",G_CALLBACK(gtk_main_quit), NULL);

   // Muestra todos los objetos
   gtk_widget_show_all(window);

   // Ejecuta el Ciclo Principal
   gtk_main();

   // Finaliza Retornando 0
   return 0;

}
