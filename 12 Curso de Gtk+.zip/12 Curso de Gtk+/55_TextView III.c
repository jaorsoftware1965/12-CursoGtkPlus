/*

Autor-Video : JAOR
Curso       : Library Gtk+
Clase 55    : TextView III

En esta clase, veremos como insertar texto en donde se encuentra el Cursor
y como obtener el texto seleccionado.

*/

// Se incluye la librería
#include <gtk/gtk.h>

// Definimos la Estructura para Widgets
typedef struct
{
   GtkWidget *txtEntrada,    // Entrada de Texto
             *tvEditor;      // TextView
} Widgets;


// Función para Insertar el Texto desde el GtkEntry al TextView
static void SbInsertaTexto (GtkButton *button, Widgets *w)
{
   // Variables
   GtkTextBuffer *buffer;     // Para el Buffer del TextView
   GtkTextMark   *mark;       // Para obtener la Marca del Texto
   GtkTextIter   iter;        // El Item de Texto
   const gchar   *text;       // Variable para el Texto

   // Obtiene el Buffer del TextView
   buffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (w->tvEditor));

   // Obtiene el Texto de la Entrada
   text = gtk_entry_get_text (GTK_ENTRY (w->txtEntrada));

   // Obtiene la Marca del Buffer del Texto donde se encuentra el Cursor
   mark = gtk_text_buffer_get_insert (buffer);

   // Prepara el Iter con la posición del Cursor
   gtk_text_buffer_get_iter_at_mark (buffer, &iter, mark);

   // Inserta el Texto
   gtk_text_buffer_insert (buffer, &iter, text, -1);

   g_print("%s \n",text);

}

// Función para obtener el texto Seleccionado del TextView y Desplegarlo al Usuario
static void SbObtenTexto (GtkButton *button, Widgets *w)
{
   // Variables
   GtkTextBuffer *buffer;     // El Buffer del TextView
   GtkTextIter   start, end;  // Iter de Inicio y Fin
   gchar *text;               // Variable para obtener el Texto

   // Obtiene el Buffer del TextView
   buffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (w->tvEditor));

   // Obtiene la referencia inicial y final del Texto Seleccionado
   gtk_text_buffer_get_selection_bounds (buffer, &start, &end);

   // Obtiene el Texto del Buffer usando el Inicio y el Final (FALSE-no incluye caracteres ocultos)
   text = gtk_text_buffer_get_text (buffer, &start, &end, FALSE);

   // Lo despliega
   g_print ("%s\n", text);
}

// Función Principal
int main (int argc,char *argv[])
{
   // Variables
   GtkWidget *window,       // Ventana Principal
             *scrolled_win, // El Scroll
             *hbox,         // Contenedor Horizontal
             *vbox,         // Contenedor Vertical
             *insert,       // Botón para Insertar Texto
             *retrieve;     // Botón para obtener el texto


   // Prepara memoria para el Objeto correspondiente a la estructura.
   Widgets *w = g_slice_new (Widgets);

   // Inicializa la librería
   gtk_init (&argc, &argv);

   // Crea y configura la Ventana Principal
   window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
   gtk_window_set_title (GTK_WINDOW (window), "Clase 55 - TextView III");
   gtk_container_set_border_width (GTK_CONTAINER (window), 10);
   gtk_widget_set_size_request (window, -1, 200);

   // Crea el TextView usando la variable de la estructura
   w->tvEditor = gtk_text_view_new ();

   // Crea la Entrada de Texto
   w->txtEntrada = gtk_entry_new ();

   // Crea el Botón para Insertar y Obtener Texto
   insert = gtk_button_new_with_label ("Insertar");
   retrieve = gtk_button_new_with_label ("Obtener");

   // Establece las Señales
   g_signal_connect (G_OBJECT (insert), "clicked",G_CALLBACK (SbInsertaTexto),(gpointer) w);
   g_signal_connect (G_OBJECT (retrieve), "clicked",G_CALLBACK (SbObtenTexto),(gpointer) w);

   // Crea el Scroll
   scrolled_win = gtk_scrolled_window_new (NULL, NULL);

   // Añade el TextView al Contenedor
   gtk_container_add (GTK_CONTAINER (scrolled_win), w->tvEditor);

   // Crea el Contenedor Horizontal
   hbox = gtk_hbox_new (FALSE,5);

   // Agrega la entrada y los botones al Contenedor
   gtk_box_pack_start(GTK_BOX (hbox), w->txtEntrada,TRUE,TRUE,5);
   gtk_box_pack_start(GTK_BOX (hbox), insert,TRUE,TRUE,5);
   gtk_box_pack_start(GTK_BOX (hbox), retrieve,TRUE,TRUE,5);

   // Crea el Contenedor Vertical
   vbox = gtk_vbox_new (FALSE, 5);

   // Agrega el Scroll al Contenedor
   gtk_box_pack_start (GTK_BOX (vbox), scrolled_win, TRUE, TRUE, 0);

   // Agrega el Contenedor Horizontal al Vertical
   gtk_box_pack_start (GTK_BOX (vbox), hbox, FALSE, TRUE, 0);

   // Agrega el Contenedor Vertical a la Ventana Principal
   gtk_container_add (GTK_CONTAINER (window), vbox);

   // Muestra todos los Objetos de la Ventana
   gtk_widget_show_all (window);

   // Ejecuta el Ciclo Principal
   gtk_main();

   // Finaliza Retornando 0
   return 0;

}
